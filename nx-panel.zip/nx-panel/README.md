# NX Panel

**NX Panel** is a lightweight, open-source Minecraft server hosting panel built for small VPS environments (as low as 2 GB RAM). It is built entirely on Fastify, better-sqlite3, and vanilla JavaScript — no Express, no React, no Vue, no Angular. NX Panel targets extremely low idle memory usage, fast startup, and a modern dark glass UI.

![NX Panel Dashboard](docs/screenshots/dashboard-placeholder.png)
*(Screenshot placeholder — replace with an actual dashboard screenshot)*

---

## Table of Contents

- [Features](#features)
- [Technology Stack](#technology-stack)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running in Production](#running-in-production)
- [Docker (Optional)](#docker-optional)
- [Default Admin Account](#default-admin-account)
- [Project Structure](#project-structure)
- [API Documentation](#api-documentation)
- [WebSocket Protocol](#websocket-protocol)
- [Security](#security)
- [Performance Notes](#performance-notes)
- [Screenshots](#screenshots)
- [License](#license)

---

## Features

### Dashboard
- Modern dark theme with glassmorphism ("glass UI") cards and subtle animations
- Fully responsive layout (desktop, tablet, mobile)
- Live host statistics: CPU, RAM, Disk, Uptime
- Per-server live statistics: TPS, MSPT-adjacent metrics, online players
- Recent activity feed and live notifications
- Quick action shortcuts

### Background Video Manager
- Admin can upload MP4 / WebM background videos
- Configurable loop, mute, blur, brightness, opacity, and overlay darkness
- Live preview — changes apply instantly to all connected users via WebSocket, no restart required

### Authentication
- Register / Login / Forgot Password / Reset Password
- JWT access tokens (short-lived) + rotating refresh tokens (HTTP-only cookie or bearer)
- "Remember Me" extends refresh token lifetime
- 2FA-ready schema (`totp_secret`, `totp_enabled` columns present for future TOTP integration)
- Session management via refresh token table (revocable, rotated on every refresh)
- bcrypt password hashing (configurable cost factor)
- Global rate limiting via `@fastify/rate-limit`

### User Panel
- One free Minecraft server per new account by default (3 GB RAM / 100% CPU / 10 GB Storage — configurable)
- Server lifecycle: Create, Delete, Rename, Start, Stop, Restart, Kill
- Live console with streaming logs over WebSocket and command input
- Full file manager: upload, download, rename, delete, ZIP, UNZIP, in-browser text file editing
- World & plugin upload via the file manager (drag a `.zip`/`.jar` into the appropriate folder)
- Software & version selection: Paper, Purpur, Fabric, Forge, Vanilla
- Manual and scheduled backups with retention (`keep_count`) enforcement

### Admin Panel
- Unlimited users and servers
- Suspend / unsuspend / delete users and servers
- Edit any server's RAM / CPU / disk allocation
- Broadcast messages and manage panel-wide announcements
- Maintenance mode toggle with custom message
- Full audit log and activity log viewers
- Theme & panel name settings
- Background video manager
- Coin manager (promo codes, shop items)
- Ad manager (banner, reward, popup, HTML, image, video ads with analytics)
- API key issuance overview

### Coin System
- Coins stored in SQLite, atomic transactions for all balance changes
- Daily login reward (24h cooldown, configurable amount)
- Referral rewards (credited to the referrer on successful signup)
- Promo codes (admin-created, usage-limited, optionally time-limited)
- Manual admin rewards/deductions with audit trail
- Full transaction history per user
- Global leaderboard

### Shop
- Upgrade RAM, CPU, Storage, or Server Slots using coins
- Admin-configurable item catalog (type, label, amount, price, enabled)
- Upgrades apply directly to a chosen server (RAM/CPU/Storage) or account (slots)

### Ad Manager
- Banner, Reward, Popup, HTML, Image, and Video ad types
- Frequency control per ad (minimum minutes between reward claims per user)
- Scheduling via `start_at` / `end_at` timestamps
- Impression, click, and reward-claim analytics
- Coin rewards for watching/interacting with reward ads
- User-facing close button (frontend-controlled) and admin upload interface

### REST API
- Fully versioned under `/api/v1`
- JSON request/response bodies with a consistent `{ success, message, data }` envelope
- Bearer JWT **or** API key (`x-api-key` header) authentication
- Per-user API key issuance with named keys and permission arrays
- Endpoints grouped as Server API, User API, Coin API, Admin API, Backup API, Console API, and Statistics API

### WebSocket
- Single `/ws` endpoint, authenticated via a JSON `auth` message carrying the JWT
- Live console streaming (subscribe per server)
- Live per-server statistics (TPS, MSPT, player count) every 3 seconds
- Live host statistics (CPU/RAM/Disk) every 3 seconds while a client is subscribed
- Live global notifications, broadcasts, and background-change events

### Security
- Helmet-equivalent security headers (CSP, X-Frame-Options, X-Content-Type-Options, HSTS on HTTPS, Referrer-Policy, Permissions-Policy) applied via a Fastify `onSend` hook — no extra dependency required
- Full input validation on every mutating endpoint (`utils/validate.js`)
- Parameterized SQL everywhere via `better-sqlite3` prepared statements — no string-concatenated queries anywhere in the codebase (SQL injection protection)
- Output escaping helpers and a strict Content-Security-Policy for XSS protection
- `sameSite: strict` HTTP-only refresh token cookies (CSRF mitigation) plus bearer-token-based API auth that is immune to CSRF by design
- Path traversal protection on every file manager operation (`resolveSafePath`)
- Full audit logging (`audit_logs` table) for all administrative and authentication actions
- Rate limiting on all routes by default

### Database
- SQLite via `better-sqlite3` (synchronous, extremely fast, zero network overhead, ideal for low-RAM VPS)
- WAL journal mode + tuned page cache for minimal memory usage
- Automatic schema migration on boot (`CREATE TABLE IF NOT EXISTS` — safe to run repeatedly)
- Automatic default admin account creation on first run

### Performance
- No Express, no heavyweight framework — Fastify was chosen specifically for its low overhead and high throughput
- Async I/O throughout; blocking work (SQLite) is inherently fast enough on this scale to avoid a worker-thread architecture, keeping the memory footprint minimal
- Response compression via `@fastify/compress`
- Efficient static file serving via `@fastify/static` with cache headers
- WebSocket broadcast loop only computes/sends stats to servers with active subscribers — no wasted CPU cycles when nobody is watching

---

## Technology Stack

**Backend:** Node.js (LTS), Fastify, better-sqlite3, `ws` (via `@fastify/websocket`), `jsonwebtoken`, `bcrypt`
**Frontend:** Vanilla HTML, vanilla CSS, vanilla JavaScript (no frameworks, no build step)
**Deployment:** Linux (Ubuntu/Debian), optional Docker, default port `3000`

---

## Requirements

- Node.js 18 LTS or newer
- Linux (Ubuntu 20.04+/Debian 11+ recommended) — also runs on other platforms for development
- A Java runtime installed on the host for any Minecraft version you intend to run (e.g. `apt install openjdk-21-jre-headless`)
- At least 2 GB RAM (panel itself typically uses well under 100 MB idle; the remainder is available for Minecraft server JVM processes)

---

## Installation

```bash
git clone https://github.com/your-org/nx-panel.git
cd nx-panel
npm install
npm start
```

The panel will be available at:

```
http://SERVER_IP:3000
```

On first boot, NX Panel automatically:
1. Creates the SQLite database file at `database/nxpanel.db`
2. Applies the full schema
3. Seeds default settings and shop items
4. Creates a default administrator account (see [Default Admin Account](#default-admin-account))

### Development mode

```bash
npm run dev
```

This uses Node's built-in `--watch` flag to restart the server automatically on file changes.

### Running migrations only

If you want to initialize/verify the database without starting the HTTP server:

```bash
npm run migrate
```

---

## Configuration

All panel configuration lives in `config.json` at the project root. Key fields:

```json
{
  "panel": { "port": 3000, "host": "0.0.0.0" },
  "security": {
    "jwtSecret": "CHANGE_THIS_JWT_SECRET_BEFORE_PRODUCTION_USE",
    "jwtRefreshSecret": "CHANGE_THIS_REFRESH_SECRET_BEFORE_PRODUCTION_USE",
    "bcryptRounds": 12
  },
  "admin": {
    "autoCreate": true,
    "username": "admin",
    "email": "admin@nxpanel.local",
    "password": "ChangeMe123!"
  },
  "defaults": {
    "freeServer": { "ramMb": 3072, "cpuPercent": 100, "diskMb": 10240 }
  }
}
```

> **Important:** Before deploying to production, change `security.jwtSecret`, `security.jwtRefreshSecret`, and the default admin password. You can change the admin password immediately after first login via the account settings, or edit `config.json` before the very first boot (the admin account is only auto-created if the `users` table is empty).

---

## Running in Production

A minimal `systemd` unit is a good way to keep NX Panel alive on a VPS:

```ini
[Unit]
Description=NX Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/nx-panel
ExecStart=/usr/bin/node server.js
Restart=on-failure
RestartSec=5
User=nxpanel
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now nx-panel
```

Place NX Panel behind a reverse proxy (nginx, Caddy) if you want TLS termination and a domain name. Because the panel already serves compressed responses and sets strict security headers, a simple reverse proxy passthrough is sufficient.

---

## Docker (Optional)

A minimal Dockerfile-based workflow (create your own `Dockerfile` similar to below, or run directly on the host — Docker is optional per the project goals):

```dockerfile
FROM node:20-slim
WORKDIR /app
COPY package*.json ./
RUN npm install --omit=dev
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
```

```bash
docker build -t nx-panel .
docker run -d -p 3000:3000 -v $(pwd)/database:/app/database -v $(pwd)/servers:/app/servers -v $(pwd)/backups:/app/backups nx-panel
```

Note: Minecraft server processes are spawned as child processes of the panel itself, so running in Docker requires the container to have Java installed and sufficient memory/CPU allocated to run both the panel and any hosted Minecraft servers.

---

## Default Admin Account

On first run, unless disabled in `config.json` (`admin.autoCreate: false`), NX Panel creates:

- **Username:** `admin` (configurable via `config.json`)
- **Email:** `admin@nxpanel.local`
- **Password:** `ChangeMe123!`

**Change this password immediately after your first login.**

---

## Project Structure

```
nx-panel/
├── server.js                 # Fastify bootstrap, plugin registration, schedulers
├── package.json
├── config.json                # Central runtime configuration
├── README.md
├── LICENSE
├── database/
│   ├── db.js                  # better-sqlite3 connection, schema, seeding
│   └── migrate.js             # Standalone migration entry point
├── public/                    # Vanilla HTML/CSS/JS frontend (served statically)
│   ├── css/style.css
│   ├── js/*.js
│   └── *.html
├── api/
│   └── v1/                    # Versioned REST API route modules
├── auth/                      # JWT helpers, auth service, Fastify auth middleware
├── websocket/
│   └── hub.js                 # WebSocket connection hub & broadcast logic
├── services/                  # Business logic: servers, backups, coins, ads, backgrounds, files, audit
├── utils/                     # Logger, validators, response helpers, system stats
├── uploads/                   # Scratch space for general uploads
├── backgrounds/               # Uploaded background video files
├── backups/                   # Per-server backup ZIP archives
├── servers/                   # Per-server Minecraft installation directories
└── logs/                      # Rotating daily log files
```

---

## API Documentation

All endpoints are prefixed with `/api/v1`. Responses follow this envelope:

```json
{ "success": true, "message": "OK", "data": { } }
```

or on failure:

```json
{ "success": false, "message": "Description of the error", "errors": null }
```

Authenticate with either:
- `Authorization: Bearer <accessToken>` (obtained from `/auth/login`), or
- `x-api-key: <apiKey>` (obtained from `/auth/api-keys`, user-scoped)

### Auth API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/auth/register` | Create a new account |
| POST | `/auth/login` | Log in, returns access + refresh tokens |
| POST | `/auth/refresh` | Rotate refresh token, returns new access token |
| POST | `/auth/logout` | Revoke the current refresh token |
| POST | `/auth/forgot-password` | Request a password reset token |
| POST | `/auth/reset-password` | Reset password using a valid token |
| GET | `/auth/me` | Get the current authenticated user |
| POST | `/auth/api-keys` | Create a new API key |
| GET | `/auth/api-keys` | List your API keys |
| DELETE | `/auth/api-keys/:id` | Revoke an API key |

### Server API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/servers` | List your servers |
| POST | `/servers` | Create a new server |
| GET | `/servers/:id` | Get server details |
| PATCH | `/servers/:id` | Rename a server |
| DELETE | `/servers/:id` | Delete a server |
| POST | `/servers/:id/start` | Start the server process |
| POST | `/servers/:id/stop` | Gracefully stop the server |
| POST | `/servers/:id/restart` | Restart the server |
| POST | `/servers/:id/kill` | Force-kill the server process |
| POST | `/servers/:id/command` | Send a console command |
| GET | `/servers/:id/console` | Get buffered recent console output |

### File Manager (Server API)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/servers/:id/files?path=` | List directory contents |
| GET | `/servers/:id/files/content?path=` | Read a text file |
| PUT | `/servers/:id/files/content` | Write a text file |
| DELETE | `/servers/:id/files?path=` | Delete a file or directory |
| POST | `/servers/:id/files/rename` | Rename a file or directory |
| POST | `/servers/:id/files/mkdir` | Create a directory |
| POST | `/servers/:id/files/upload` | Upload a file (multipart) |
| GET | `/servers/:id/files/download?path=` | Download a file |
| POST | `/servers/:id/files/zip` | Create a ZIP archive of a path |
| POST | `/servers/:id/files/unzip` | Extract a ZIP archive in place |

### Backup API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/servers/:id/backups` | List backups |
| POST | `/servers/:id/backups` | Create a manual backup |
| POST | `/servers/:id/backups/:backupId/restore` | Restore a backup |
| DELETE | `/servers/:id/backups/:backupId` | Delete a backup |
| GET | `/servers/:id/backups/schedules` | List backup schedules |
| POST | `/servers/:id/backups/schedules` | Create a backup schedule |
| DELETE | `/servers/:id/backups/schedules/:scheduleId` | Delete a schedule |

### User & Coin API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/user/notifications` | List your notifications |
| POST | `/user/notifications/:id/read` | Mark a notification read |
| GET | `/user/activity` | Your recent activity |
| GET | `/coins/balance` | Current coin balance |
| POST | `/coins/daily` | Claim daily reward |
| POST | `/coins/promo` | Redeem a promo code |
| GET | `/coins/transactions` | Transaction history |
| GET | `/coins/leaderboard` | Top coin holders |
| GET | `/shop/items` | List shop items |
| POST | `/shop/purchase/:itemId` | Purchase a shop item (slots) |
| POST | `/shop/apply-upgrade/:itemId` | Apply a RAM/CPU/storage upgrade to a server |

### Ad API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/ads/active` | List currently active ads |
| POST | `/ads/:id/impression` | Record an ad impression |
| POST | `/ads/:id/click` | Record an ad click |
| POST | `/ads/:id/claim` | Claim a reward ad's coin reward |

### Admin API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/admin/overview` | Panel-wide stats + host resource usage |
| GET | `/admin/users` | List all users |
| GET | `/admin/users/:id` | Get a user + their servers |
| POST | `/admin/users/:id/suspend` | Suspend a user |
| POST | `/admin/users/:id/unsuspend` | Unsuspend a user |
| DELETE | `/admin/users/:id` | Delete a user and their servers |
| PATCH | `/admin/users/:id` | Edit role/slots/coins |
| POST | `/admin/users/:id/reward` | Manually adjust a user's coin balance |
| GET | `/admin/servers` | List every server on the panel |
| PATCH | `/admin/servers/:id/resources` | Edit RAM/CPU/disk allocation |
| POST | `/admin/servers/:id/suspend` | Suspend a server |
| POST | `/admin/servers/:id/unsuspend` | Unsuspend a server |
| DELETE | `/admin/servers/:id` | Delete a server |
| POST | `/admin/broadcast` | Send a broadcast notification to all users |
| GET/POST/DELETE | `/admin/announcements` | Manage panel announcements |
| POST | `/admin/maintenance` | Toggle maintenance mode |
| GET/POST | `/admin/settings` | Read/update panel settings |
| GET | `/admin/logs/audit` | Audit log |
| GET | `/admin/logs/activity` | Activity log |
| GET/POST/DELETE | `/admin/promo-codes` | Manage promo codes |
| GET/POST/PATCH/DELETE | `/admin/shop-items` | Manage shop catalog |
| GET/POST/PATCH/DELETE | `/admin/ads` | Manage ads |
| GET | `/admin/ads/analytics` | Ad performance analytics |
| GET/POST/PATCH/DELETE | `/admin/backgrounds` | Manage background videos |

### Statistics API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/status` | Public panel status, announcements, active background |
| GET | `/stats/dashboard` | Authenticated dashboard summary |
| GET | `/stats/server/:id` | Live stats for one server |

---

## WebSocket Protocol

Connect to `ws(s)://SERVER_IP:3000/ws` and send a JSON auth message first:

```json
{ "type": "auth", "token": "<accessToken>" }
```

After receiving `{ "channel": "auth", "event": "success" }`, you may send:

```json
{ "type": "subscribe_global" }
{ "type": "subscribe_server", "serverId": "..." }
{ "type": "unsubscribe_server", "serverId": "..." }
{ "type": "console_command", "serverId": "...", "command": "say hello" }
```

Incoming message shape:

```json
{ "channel": "server", "serverId": "...", "event": "console", "data": { "line": "..." } }
{ "channel": "server", "serverId": "...", "event": "stats", "data": { "online": true, "tps": 20, "players": 3 } }
{ "channel": "global", "event": "host_stats", "data": { "cpu": 12.4, "memory": { }, "disk": { } } }
{ "channel": "global", "event": "notification", "data": { "title": "...", "message": "..." } }
```

---

## Security

See the [Security](#security) section above for a full breakdown. In short: parameterized SQL everywhere, strict CSP and security headers, path-traversal-safe file operations, bcrypt-hashed passwords, short-lived rotating JWTs, and a full audit trail.

If you discover a security vulnerability, please open a private security advisory rather than a public issue.

---

## Performance Notes

NX Panel was designed from the ground up for **2 GB RAM VPS instances**:

- The panel process itself (Fastify + better-sqlite3 + WebSocket hub) typically idles under 80–100 MB of resident memory.
- SQLite's WAL mode and a small 2 MB page cache keep database memory overhead minimal while still providing good write throughput for a single-node panel.
- The WebSocket broadcast loop is subscriber-aware: if nobody is viewing a server's console or the dashboard, no stats are computed or sent for it.
- No child process is spawned for the panel's own operation — only actual Minecraft server JVMs are spawned, and only when you start them.
- Static assets are served with `@fastify/static` and compressed with `@fastify/compress`, minimizing bandwidth and re-parse overhead on the client.

---

## Screenshots

> Replace these placeholders with real screenshots after deployment.

- `docs/screenshots/dashboard-placeholder.png` — Main dashboard
- `docs/screenshots/servers-placeholder.png` — Server list
- `docs/screenshots/console-placeholder.png` — Live console
- `docs/screenshots/admin-placeholder.png` — Admin overview
- `docs/screenshots/background-placeholder.png` — Background video manager

---

## License

NX Panel is released under the [MIT License](LICENSE).

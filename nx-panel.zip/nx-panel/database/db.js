'use strict';

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const bcrypt = require('bcrypt');
const { createLogger } = require('../utils/logger');

const log = createLogger('database');
const config = require(path.join(__dirname, '..', 'config.json'));

const dbPath = path.join(__dirname, '..', config.paths.database);
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new Database(dbPath);

// Performance & low-memory tuning for SQLite on small VPS instances.
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('foreign_keys = ON');
db.pragma('cache_size = -2000'); // ~2MB page cache, keeps RAM low
db.pragma('temp_store = MEMORY');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
  coins INTEGER NOT NULL DEFAULT 0,
  server_slots INTEGER NOT NULL DEFAULT 1,
  suspended INTEGER NOT NULL DEFAULT 0,
  totp_secret TEXT,
  totp_enabled INTEGER NOT NULL DEFAULT 0,
  reset_token TEXT,
  reset_token_expires INTEGER,
  last_daily_reward INTEGER,
  referral_code TEXT UNIQUE,
  referred_by INTEGER,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  remember INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS servers (
  id TEXT PRIMARY KEY,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  software TEXT NOT NULL DEFAULT 'paper' CHECK(software IN ('paper','purpur','fabric','forge','vanilla')),
  mc_version TEXT NOT NULL DEFAULT 'latest',
  java_version TEXT NOT NULL DEFAULT '21',
  ram_mb INTEGER NOT NULL DEFAULT 3072,
  cpu_percent INTEGER NOT NULL DEFAULT 100,
  disk_mb INTEGER NOT NULL DEFAULT 10240,
  port INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'installing' CHECK(status IN ('installing','offline','online','starting','stopping','crashed','suspended')),
  suspended INTEGER NOT NULL DEFAULT 0,
  pid INTEGER,
  auto_start INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS backups (
  id TEXT PRIMARY KEY,
  server_id TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  filename TEXT NOT NULL,
  size_mb REAL NOT NULL DEFAULT 0,
  type TEXT NOT NULL DEFAULT 'manual' CHECK(type IN ('manual','scheduled')),
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS backup_schedules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_id TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  cron_interval_minutes INTEGER NOT NULL DEFAULT 1440,
  keep_count INTEGER NOT NULL DEFAULT 5,
  enabled INTEGER NOT NULL DEFAULT 1,
  last_run_at INTEGER,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('daily','referral','promo','manual','purchase','ad_reward','refund')),
  description TEXT,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS promo_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  amount INTEGER NOT NULL,
  max_uses INTEGER NOT NULL DEFAULT 1,
  used_count INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS promo_redemptions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  promo_id INTEGER NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  redeemed_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  UNIQUE(promo_id, user_id)
);

CREATE TABLE IF NOT EXISTS shop_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL CHECK(type IN ('ram','cpu','storage','slot')),
  label TEXT NOT NULL,
  amount INTEGER NOT NULL,
  price INTEGER NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS ads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('banner','reward','popup','html','image','video')),
  content TEXT NOT NULL,
  link_url TEXT,
  coin_reward INTEGER NOT NULL DEFAULT 0,
  frequency_minutes INTEGER NOT NULL DEFAULT 60,
  start_at INTEGER,
  end_at INTEGER,
  enabled INTEGER NOT NULL DEFAULT 1,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  rewards_claimed INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS ad_views (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ad_id INTEGER NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  viewed_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
  rewarded INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS api_keys (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  key_hash TEXT NOT NULL,
  key_prefix TEXT NOT NULL,
  permissions TEXT NOT NULL DEFAULT '[]',
  last_used_at INTEGER,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS backgrounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 0,
  loop INTEGER NOT NULL DEFAULT 1,
  muted INTEGER NOT NULL DEFAULT 1,
  overlay_opacity REAL NOT NULL DEFAULT 0.4,
  blur_px INTEGER NOT NULL DEFAULT 0,
  brightness_percent INTEGER NOT NULL DEFAULT 100,
  opacity_percent INTEGER NOT NULL DEFAULT 100,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS announcements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info' CHECK(severity IN ('info','warning','critical')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  details TEXT,
  ip_address TEXT,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE IF NOT EXISTS activity_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  server_id TEXT,
  action TEXT NOT NULL,
  created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE INDEX IF NOT EXISTS idx_servers_owner ON servers(owner_id);
CREATE INDEX IF NOT EXISTS idx_backups_server ON backups(server_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_refresh_user ON refresh_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_user ON activity_log(user_id);
`;

function initSchema() {
  db.exec(SCHEMA);
  log.info('Database schema verified/initialized');
}

function seedDefaults() {
  const settingsCount = db.prepare('SELECT COUNT(*) AS c FROM settings').get().c;
  if (settingsCount === 0) {
    const insert = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
    const defaults = {
      theme: 'dark-glass',
      maintenance_mode: 'false',
      maintenance_message: 'NX Panel is currently undergoing maintenance. Please check back soon.',
      panel_name: 'NX Panel'
    };
    const tx = db.transaction(() => {
      for (const [k, v] of Object.entries(defaults)) insert.run(k, v);
    });
    tx();
    log.info('Default settings seeded');
  }

  const shopCount = db.prepare('SELECT COUNT(*) AS c FROM shop_items').get().c;
  if (shopCount === 0) {
    const insert = db.prepare(
      'INSERT INTO shop_items (type, label, amount, price, enabled) VALUES (?, ?, ?, ?, 1)'
    );
    const tx = db.transaction(() => {
      insert.run('ram', '+512MB RAM', 512, 150);
      insert.run('ram', '+1024MB RAM', 1024, 280);
      insert.run('cpu', '+25% CPU', 25, 200);
      insert.run('storage', '+5GB Storage', 5120, 120);
      insert.run('slot', '+1 Server Slot', 1, 1000);
    });
    tx();
    log.info('Default shop items seeded');
  }

  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount === 0 && config.admin.autoCreate) {
    const hash = bcrypt.hashSync(config.admin.password, config.security.bcryptRounds);
    const referral = Math.random().toString(36).slice(2, 10).toUpperCase();
    db.prepare(
      `INSERT INTO users (username, email, password_hash, role, coins, server_slots, referral_code)
       VALUES (?, ?, ?, 'admin', 100000, 999, ?)`
    ).run(config.admin.username, config.admin.email, hash, referral);
    log.info(`Default admin account created: ${config.admin.username} (CHANGE THE PASSWORD IMMEDIATELY)`);
  }
}

initSchema();
seedDefaults();

module.exports = db;

'use strict';

/**
 * Standalone migration entry point.
 * Running `npm run migrate` (or `node database/migrate.js`) will create
 * the SQLite database file and apply the full schema + seed defaults
 * without starting the HTTP server. Safe to run multiple times
 * (idempotent: uses CREATE TABLE IF NOT EXISTS).
 */
const { createLogger } = require('../utils/logger');
const log = createLogger('migrate');

log.info('Running NX Panel database migration...');
require('./db');
log.info('Migration complete. Database is ready.');

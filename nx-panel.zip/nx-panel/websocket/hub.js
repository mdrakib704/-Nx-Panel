'use strict';

const { verifyAccessToken } = require('../auth/jwt');
const db = require('../database/db');
const serverService = require('../services/server.service');
const { createLogger } = require('../utils/logger');
const { getCpuUsagePercent, getMemoryInfo, getDiskInfo } = require('../utils/systemStats');

const log = createLogger('websocket');

/** Map<serverId, Set<socket>> for console/stats subscribers */
const serverSubscribers = new Map();
/** Set<socket> for global dashboard subscribers (host stats, notifications) */
const globalSubscribers = new Set();

function subscribeToServer(serverId, socket) {
  if (!serverSubscribers.has(serverId)) serverSubscribers.set(serverId, new Set());
  serverSubscribers.get(serverId).add(socket);
}

function unsubscribeFromServer(serverId, socket) {
  const set = serverSubscribers.get(serverId);
  if (set) {
    set.delete(socket);
    if (set.size === 0) serverSubscribers.delete(serverId);
  }
}

function safeSend(socket, payload) {
  if (socket.readyState === 1) {
    try {
      socket.send(JSON.stringify(payload));
    } catch (err) {
      log.warn(`Failed to send WS payload: ${err.message}`);
    }
  }
}

function broadcastToServer(serverId, event, data) {
  const set = serverSubscribers.get(serverId);
  if (!set) return;
  for (const socket of set) {
    safeSend(socket, { channel: 'server', serverId, event, data });
  }
}

function broadcastGlobal(event, data) {
  for (const socket of globalSubscribers) {
    safeSend(socket, { channel: 'global', event, data });
  }
}

serverService.setBroadcaster((serverId, event, data) => {
  broadcastToServer(serverId, event, data);
});

function authenticateSocket(token) {
  if (!token) return null;
  try {
    const decoded = verifyAccessToken(token);
    const user = db.prepare('SELECT id, username, role FROM users WHERE id = ?').get(decoded.sub);
    return user || null;
  } catch (err) {
    return null;
  }
}

function canAccessServer(user, serverId) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  const server = serverService.getServerById(serverId);
  return server && server.owner_id === user.id;
}

/**
 * Registers the WebSocket route on a Fastify instance that has the
 * @fastify/websocket plugin registered. Single endpoint /ws handles
 * server console/stats subscriptions and global dashboard updates via
 * a lightweight JSON message protocol.
 */
function registerWebSocketRoutes(fastify) {
  fastify.get('/ws', { websocket: true }, (connection, request) => {
    const socket = connection.socket || connection;
    let user = null;
    const subscribedServers = new Set();

    socket.on('message', raw => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch (err) {
        return safeSend(socket, { channel: 'error', event: 'invalid_json' });
      }

      if (msg.type === 'auth') {
        user = authenticateSocket(msg.token);
        if (user) {
          safeSend(socket, { channel: 'auth', event: 'success', data: { username: user.username } });
        } else {
          safeSend(socket, { channel: 'auth', event: 'failed' });
        }
        return;
      }

      if (!user) {
        return safeSend(socket, { channel: 'error', event: 'not_authenticated' });
      }

      if (msg.type === 'subscribe_global') {
        globalSubscribers.add(socket);
        safeSend(socket, { channel: 'global', event: 'subscribed' });
        return;
      }

      if (msg.type === 'unsubscribe_global') {
        globalSubscribers.delete(socket);
        return;
      }

      if (msg.type === 'subscribe_server') {
        const serverId = msg.serverId;
        if (!canAccessServer(user, serverId)) {
          return safeSend(socket, { channel: 'error', event: 'forbidden' });
        }
        subscribeToServer(serverId, socket);
        subscribedServers.add(serverId);
        const buffer = serverService.getConsoleBuffer(serverId);
        safeSend(socket, { channel: 'server', serverId, event: 'console_history', data: { lines: buffer } });
        safeSend(socket, {
          channel: 'server',
          serverId,
          event: 'stats',
          data: serverService.getLiveStats(serverId)
        });
        return;
      }

      if (msg.type === 'unsubscribe_server') {
        unsubscribeFromServer(msg.serverId, socket);
        subscribedServers.delete(msg.serverId);
        return;
      }

      if (msg.type === 'console_command') {
        const serverId = msg.serverId;
        if (!canAccessServer(user, serverId)) {
          return safeSend(socket, { channel: 'error', event: 'forbidden' });
        }
        try {
          serverService.sendCommand(serverId, String(msg.command || '').slice(0, 500));
        } catch (err) {
          safeSend(socket, { channel: 'server', serverId, event: 'error', data: { message: err.message } });
        }
        return;
      }
    });

    socket.on('close', () => {
      for (const serverId of subscribedServers) {
        unsubscribeFromServer(serverId, socket);
      }
      globalSubscribers.delete(socket);
    });

    socket.on('error', () => {
      for (const serverId of subscribedServers) {
        unsubscribeFromServer(serverId, socket);
      }
      globalSubscribers.delete(socket);
    });
  });
}

/**
 * Periodic broadcaster for host-level stats and per-server live stats
 * to all currently subscribed sockets. Called from server.js on an
 * interval timer.
 */
function tickBroadcast() {
  if (globalSubscribers.size > 0) {
    broadcastGlobal('host_stats', {
      cpu: getCpuUsagePercent(),
      memory: getMemoryInfo(),
      disk: getDiskInfo('.'),
      timestamp: Date.now()
    });
  }

  for (const serverId of serverSubscribers.keys()) {
    broadcastToServer(serverId, 'stats', serverService.getLiveStats(serverId));
  }
}

function pushNotification(userId, title, message) {
  db.prepare('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)').run(
    userId,
    title,
    message
  );
  broadcastGlobal('notification', { title, message, userId });
}

module.exports = {
  registerWebSocketRoutes,
  tickBroadcast,
  broadcastGlobal,
  broadcastToServer,
  pushNotification
};

'use strict';

const db = require('../database/db');
const { verifyAccessToken } = require('../auth/tokens');
const processManager = require('../services/processManager');
const systemStats = require('../services/systemStats');

const clients = new Map();

function safeSend(ws, obj) {
  try {
    if (ws && ws.readyState === 1) {
      ws.send(JSON.stringify(obj));
      return true;
    }
  } catch {}
  return false;
}

function broadcast(channel, payload) {
  for (const [ws, meta] of clients.entries()) {
    if (meta.subscriptions.has(channel)) {
      safeSend(ws, Object.assign({ channel }, payload));
    }
  }
}

// Forward process events
processManager.on('console', function({ uuid, line }) {
  broadcast('console:' + uuid, { type: 'console', line });
});

processManager.on('status', function({ uuid, status }) {
  broadcast('stats:' + uuid, { type: 'status', status });
  try {
    db.prepare('UPDATE servers SET status = ? WHERE uuid = ?').run(status, uuid);
  } catch {}
});

// System stats every 5s
setInterval(function() {
  let hasSystemSub = false;
  for (const meta of clients.values()) {
    if (meta.subscriptions.has('system')) { hasSystemSub = true; break; }
  }
  if (!hasSystemSub) return;
  try {
    const snap = systemStats.snapshot();
    broadcast('system', { type: 'system_stats', data: snap });
  } catch {}
}, 5000);

// Server stats every 3s
setInterval(function() {
  const uuids = new Set();
  for (const meta of clients.values()) {
    for (const sub of meta.subscriptions) {
      if (sub.startsWith('stats:')) uuids.add(sub.slice(6));
    }
  }
  for (const uuid of uuids) {
    try {
      const stats = processManager.getStats(uuid);
      broadcast('stats:' + uuid, { type: 'server_stats', data: stats });
    } catch {}
  }
}, 3000);

function ownsServer(user, uuid) {
  if (user.role === 'admin') return true;
  try {
    const s = db.prepare('SELECT id FROM servers WHERE uuid = ? AND owner_id = ?').get(uuid, user.id);
    return !!s;
  } catch { return false; }
}

function wsHandler(connection, request) {
  const ws = connection.socket;
  const meta = { user: null, subscriptions: new Set() };
  clients.set(ws, meta);

  // Auth timeout: 5 seconds
  const authTimeout = setTimeout(function() {
    if (!meta.user) {
      safeSend(ws, { type: 'error', message: 'Authentication timeout.' });
      try { ws.close(); } catch {}
    }
  }, 5000);

  ws.on('message', function(raw) {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch {
      safeSend(ws, { type: 'error', message: 'Invalid JSON.' });
      return;
    }

    if (!meta.user) {
      if (msg.type !== 'auth') {
        safeSend(ws, { type: 'error', message: 'Send auth first.' });
        return;
      }
      try {
        const payload = verifyAccessToken(msg.token);
        const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
        if (!user || user.suspended) throw new Error('Unauthorized');
        clearTimeout(authTimeout);
        meta.user = user;
        safeSend(ws, { type: 'auth_ok', username: user.username, role: user.role });
      } catch {
        safeSend(ws, { type: 'error', message: 'Invalid token.' });
        try { ws.close(); } catch {}
      }
      return;
    }

    if (msg.type === 'subscribe') {
      const ch = String(msg.channel || '');
      if (ch === 'system' || ch === 'notifications') {
        meta.subscriptions.add(ch);
        safeSend(ws, { type: 'subscribed', channel: ch });
        return;
      }
      const colonIdx = ch.indexOf(':');
      if (colonIdx < 0) {
        safeSend(ws, { type: 'error', message: 'Unknown channel.' });
        return;
      }
      const prefix = ch.slice(0, colonIdx);
      const uuid   = ch.slice(colonIdx + 1);
      if (!uuid || !['console', 'stats'].includes(prefix)) {
        safeSend(ws, { type: 'error', message: 'Unknown channel: ' + ch });
        return;
      }
      if (!ownsServer(meta.user, uuid)) {
        safeSend(ws, { type: 'error', message: 'Access denied.' });
        return;
      }
      meta.subscriptions.add(ch);
      safeSend(ws, { type: 'subscribed', channel: ch });
      if (prefix === 'console') {
        try {
          const logs = processManager.getRecentLogs(uuid);
          if (logs) safeSend(ws, { channel: ch, type: 'console', line: logs });
        } catch {}
      }
      return;
    }

    if (msg.type === 'unsubscribe') {
      meta.subscriptions.delete(String(msg.channel || ''));
      return;
    }

    if (msg.type === 'command') {
      const uuid    = String(msg.uuid || '');
      const command = String(msg.command || '').slice(0, 256);
      if (!uuid || !command) {
        safeSend(ws, { type: 'error', message: 'Invalid command.' });
        return;
      }
      if (!ownsServer(meta.user, uuid)) {
        safeSend(ws, { type: 'error', message: 'Access denied.' });
        return;
      }
      try {
        processManager.sendCommand(uuid, command);
      } catch (err) {
        safeSend(ws, { type: 'error', message: err.message });
      }
      return;
    }

    safeSend(ws, { type: 'error', message: 'Unknown message type.' });
  });

  ws.on('close', function() { clients.delete(ws); });
  ws.on('error', function() { clients.delete(ws); });
}

module.exports = { wsHandler };

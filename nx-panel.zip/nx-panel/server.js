'use strict';

const path = require('path');
const fs = require('fs');
const fastifyFactory = require('fastify');
const config = require('./config.json');
const { createLogger } = require('./utils/logger');
const { ok } = require('./utils/response');

const log = createLogger('server');

// Ensure required runtime directories exist before anything else touches them.
for (const dirKey of ['servers', 'backups', 'uploads', 'backgrounds', 'logs']) {
  const dirPath = path.join(__dirname, dirKey);
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

// Initialize database (creates schema + default admin on first run).
require('./database/db');

const fastify = fastifyFactory({
  logger: false, // we use our own lightweight logger to keep memory footprint low
  trustProxy: config.panel.trustProxy,
  bodyLimit: 10 * 1024 * 1024 // 10MB JSON body limit; large uploads use multipart streaming
});

async function build() {
  // ---- Security & performance plugins ----
  await fastify.register(require('@fastify/cors'), {
    origin: true,
    credentials: true
  });

  await fastify.register(require('@fastify/cookie'));

  await fastify.register(require('@fastify/compress'), {
    global: true,
    threshold: 1024
  });

  await fastify.register(require('@fastify/rate-limit'), {
    max: config.security.rateLimit.max,
    timeWindow: config.security.rateLimit.timeWindow,
    allowList: [],
    ban: 0
  });

  await fastify.register(require('@fastify/multipart'), {
    limits: {
      fileSize: 250 * 1024 * 1024, // 250MB max (covers background videos and server jars)
      files: 1
    }
  });

  await fastify.register(require('@fastify/websocket'));

  // ---- Security headers (Helmet-equivalent, hand-rolled to avoid extra deps) ----
  fastify.addHook('onSend', async (request, reply, payload) => {
    reply.header('X-Content-Type-Options', 'nosniff');
    reply.header('X-Frame-Options', 'SAMEORIGIN');
    reply.header('X-XSS-Protection', '0');
    reply.header('Referrer-Policy', 'strict-origin-when-cross-origin');
    reply.header(
      'Content-Security-Policy',
      "default-src 'self'; img-src 'self' data: https:; media-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self' ws: wss:;"
    );
    reply.header('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    if (request.protocol === 'https') {
      reply.header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains');
    }
    return payload;
  });

  // ---- Static file serving ----
  await fastify.register(require('@fastify/static'), {
    root: path.join(__dirname, 'public'),
    prefix: '/',
    decorateReply: true,
    cacheControl: true,
    maxAge: '1h',
    immutable: false
  });

  await fastify.register(require('@fastify/static'), {
    root: path.join(__dirname, 'backgrounds'),
    prefix: '/backgrounds/',
    decorateReply: false,
    cacheControl: true,
    maxAge: '7d'
  });

  // ---- API routes (versioned) ----
  await fastify.register(require('./api/v1/index'), { prefix: '/api/v1' });

  // ---- WebSocket routes ----
  const { registerWebSocketRoutes } = require('./websocket/hub');
  await fastify.register(async instance => {
    registerWebSocketRoutes(instance);
  });

  // ---- Health check ----
  fastify.get('/api/health', async (request, reply) => {
    return ok(reply, { status: 'healthy', uptime: process.uptime() });
  });

  // ---- 404 handler for unmatched API routes ----
  fastify.setNotFoundHandler((request, reply) => {
    if (request.raw.url && request.raw.url.startsWith('/api/')) {
      return reply.code(404).send({ success: false, message: 'Endpoint not found' });
    }
    // For non-API paths, serve the SPA-style index for client-side routing fallback.
    return reply.code(404).sendFile('index.html');
  });

  fastify.setErrorHandler((error, request, reply) => {
    log.error(`Unhandled error on ${request.method} ${request.url}: ${error.message}`, {
      stack: error.stack
    });
    const statusCode = error.statusCode || 500;
    return reply.code(statusCode).send({
      success: false,
      message: statusCode === 500 ? 'Internal server error' : error.message
    });
  });

  return fastify;
}

async function start() {
  try {
    await build();
    await fastify.listen({ port: config.panel.port, host: config.panel.host });
    log.info(`NX Panel is running at http://${config.panel.host}:${config.panel.port}`);

    // ---- Background schedulers (low frequency, minimal memory footprint) ----
    const { tickBroadcast } = require('./websocket/hub');
    const backupService = require('./services/backup.service');

    // Live stats broadcast every 3 seconds to subscribed WebSocket clients only.
    setInterval(() => {
      try {
        tickBroadcast();
      } catch (err) {
        log.error(`Stats broadcast tick failed: ${err.message}`);
      }
    }, 3000);

    // Backup schedule check every 60 seconds.
    setInterval(() => {
      backupService.runDueSchedules().catch(err => {
        log.error(`Scheduled backup run failed: ${err.message}`);
      });
    }, 60000);

    // Graceful shutdown
    const shutdown = async signal => {
      log.info(`Received ${signal}, shutting down gracefully...`);
      try {
        await fastify.close();
        log.info('Server closed. Goodbye.');
        process.exit(0);
      } catch (err) {
        log.error(`Error during shutdown: ${err.message}`);
        process.exit(1);
      }
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
  } catch (err) {
    log.error(`Failed to start NX Panel: ${err.message}`, { stack: err.stack });
    process.exit(1);
  }
}

start();

module.exports = fastify;

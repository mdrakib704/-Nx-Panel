'use strict';

function ok(reply, data = {}, message = 'OK', statusCode = 200) {
  return reply.code(statusCode).send({
    success: true,
    message,
    data
  });
}

function fail(reply, message = 'Error', statusCode = 400, errors = null) {
  return reply.code(statusCode).send({
    success: false,
    message,
    errors
  });
}

module.exports = { ok, fail };

'use strict';

const os = require('os');
const fs = require('fs');
const path = require('path');

let prevCpuInfo = os.cpus();
let prevTimestamp = Date.now();

/**
 * Computes overall host CPU usage percentage since the last call.
 * Lightweight: relies only on os.cpus() deltas, no child processes.
 */
function getCpuUsagePercent() {
  const cpus = os.cpus();
  let idleDiff = 0;
  let totalDiff = 0;

  for (let i = 0; i < cpus.length; i++) {
    const prev = prevCpuInfo[i] ? prevCpuInfo[i].times : cpus[i].times;
    const curr = cpus[i].times;
    const idle = curr.idle - prev.idle;
    const total =
      (curr.user - prev.user) +
      (curr.nice - prev.nice) +
      (curr.sys - prev.sys) +
      (curr.irq - prev.irq) +
      idle;
    idleDiff += idle;
    totalDiff += total;
  }

  prevCpuInfo = cpus;
  prevTimestamp = Date.now();

  if (totalDiff <= 0) return 0;
  const usage = 100 - (idleDiff / totalDiff) * 100;
  return Math.max(0, Math.min(100, Math.round(usage * 10) / 10));
}

function getMemoryInfo() {
  const total = os.totalmem();
  const free = os.freemem();
  const used = total - free;
  return {
    totalMb: Math.round(total / 1024 / 1024),
    usedMb: Math.round(used / 1024 / 1024),
    freeMb: Math.round(free / 1024 / 1024),
    usedPercent: Math.round((used / total) * 1000) / 10
  };
}

function getDiskInfo(targetPath) {
  try {
    const stat = fs.statfsSync(targetPath || '.');
    const total = stat.blocks * stat.bsize;
    const free = stat.bfree * stat.bsize;
    const used = total - free;
    return {
      totalMb: Math.round(total / 1024 / 1024),
      usedMb: Math.round(used / 1024 / 1024),
      freeMb: Math.round(free / 1024 / 1024),
      usedPercent: total > 0 ? Math.round((used / total) * 1000) / 10 : 0
    };
  } catch (err) {
    return { totalMb: 0, usedMb: 0, freeMb: 0, usedPercent: 0 };
  }
}

function getNetworkInterfaces() {
  const interfaces = os.networkInterfaces();
  const result = [];
  for (const [name, addrs] of Object.entries(interfaces)) {
    if (!addrs) continue;
    for (const addr of addrs) {
      if (addr.internal) continue;
      result.push({ name, address: addr.address, family: addr.family });
    }
  }
  return result;
}

function getDirSizeMb(dirPath) {
  let total = 0;
  function walk(p) {
    let entries;
    try {
      entries = fs.readdirSync(p, { withFileTypes: true });
    } catch (err) {
      return;
    }
    for (const entry of entries) {
      const full = path.join(p, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile()) {
        try {
          total += fs.statSync(full).size;
        } catch (err) {
          /* ignore unreadable file */
        }
      }
    }
  }
  walk(dirPath);
  return Math.round((total / 1024 / 1024) * 100) / 100;
}

function getUptimeSeconds() {
  return Math.floor(os.uptime());
}

module.exports = {
  getCpuUsagePercent,
  getMemoryInfo,
  getDiskInfo,
  getNetworkInterfaces,
  getDirSizeMb,
  getUptimeSeconds
};

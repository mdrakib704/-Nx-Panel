'use strict';

const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const SAFE_NAME_RE = /^[a-zA-Z0-9 _.\-]{1,64}$/;
const SAFE_PATH_SEGMENT_RE = /^[a-zA-Z0-9 _.\-]+$/;

function isValidUsername(value) {
  return typeof value === 'string' && USERNAME_RE.test(value);
}

function isValidEmail(value) {
  return typeof value === 'string' && EMAIL_RE.test(value) && value.length <= 254;
}

function isValidPassword(value) {
  return typeof value === 'string' && value.length >= 8 && value.length <= 128;
}

function isValidServerName(value) {
  return typeof value === 'string' && SAFE_NAME_RE.test(value);
}

function isSafePathSegment(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > 255) return false;
  if (value === '.' || value === '..') return false;
  if (value.includes('/') || value.includes('\\')) return false;
  return SAFE_PATH_SEGMENT_RE.test(value);
}

/**
 * Resolves a user-supplied relative path against a base directory and
 * guarantees the resolved path cannot escape the base directory
 * (prevents path traversal attacks).
 */
function resolveSafePath(path, baseDir, relativePath) {
  const normalizedRel = (relativePath || '').replace(/\\/g, '/').split('/').filter(seg => seg !== '' && seg !== '.');
  for (const seg of normalizedRel) {
    if (seg === '..') {
      throw new Error('Path traversal detected');
    }
  }
  const target = path.join(baseDir, ...normalizedRel);
  const resolvedBase = path.resolve(baseDir);
  const resolvedTarget = path.resolve(target);
  if (resolvedTarget !== resolvedBase && !resolvedTarget.startsWith(resolvedBase + path.sep)) {
    throw new Error('Path traversal detected');
  }
  return resolvedTarget;
}

function escapeHtml(str) {
  if (typeof str !== 'string') return str;
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sanitizeString(value, maxLength = 1000) {
  if (typeof value !== 'string') return '';
  return value.slice(0, maxLength).replace(/\0/g, '');
}

function isPositiveInt(value, max = Number.MAX_SAFE_INTEGER) {
  return Number.isInteger(value) && value > 0 && value <= max;
}

module.exports = {
  isValidUsername,
  isValidEmail,
  isValidPassword,
  isValidServerName,
  isSafePathSegment,
  resolveSafePath,
  escapeHtml,
  sanitizeString,
  isPositiveInt
};

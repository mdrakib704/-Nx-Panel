'use strict';

const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(__dirname, '..', 'logs');
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

const LEVELS = { error: 0, warn: 1, info: 2, debug: 3 };
const CURRENT_LEVEL = LEVELS[process.env.NX_LOG_LEVEL || 'info'] ?? 2;

function timestamp() {
  return new Date().toISOString();
}

function writeToFile(line) {
  const file = path.join(LOG_DIR, `nxpanel-${new Date().toISOString().slice(0, 10)}.log`);
  fs.appendFile(file, line + '\n', () => {});
}

function format(level, scope, message, meta) {
  const base = `[${timestamp()}] [${level.toUpperCase()}] [${scope}] ${message}`;
  return meta ? `${base} ${JSON.stringify(meta)}` : base;
}

function log(level, scope, message, meta) {
  if (LEVELS[level] > CURRENT_LEVEL) return;
  const line = format(level, scope, message, meta);
  if (level === 'error') {
    console.error(line);
  } else if (level === 'warn') {
    console.warn(line);
  } else {
    console.log(line);
  }
  writeToFile(line);
}

function createLogger(scope) {
  return {
    error: (msg, meta) => log('error', scope, msg, meta),
    warn: (msg, meta) => log('warn', scope, msg, meta),
    info: (msg, meta) => log('info', scope, msg, meta),
    debug: (msg, meta) => log('debug', scope, msg, meta)
  };
}

module.exports = { createLogger };

'use strict';

const db = require('../../database/db');
const { authenticate } = require('../../auth/middleware');
const { ok, fail } = require('../../utils/response');
const { getCpuUsagePercent, getMemoryInfo, getDiskInfo, getUptimeSeconds } = require('../../utils/systemStats');
const serverService = require('../../services/server.service');
const audit = require('../../services/audit.service');
const backgroundService = require('../../services/background.service');

async function statsRoutes(fastify) {
  // Public: panel status + active announcements + maintenance state (no auth required)
  fastify.get('/status', async (request, reply) => {
    const settingsRows = db.prepare('SELECT key, value FROM settings').all();
    const settings = {};
    for (const row of settingsRows) settings[row.key] = row.value;

    const announcements = db
      .prepare('SELECT * FROM announcements WHERE active = 1 ORDER BY created_at DESC LIMIT 10')
      .all();

    const activeBackground = backgroundService.getActiveBackground();

    return ok(reply, {
      panelName: settings.panel_name || 'NX Panel',
      maintenanceMode: settings.maintenance_mode === 'true',
      maintenanceMessage: settings.maintenance_message || '',
      theme: settings.theme || 'dark-glass',
      announcements,
      background: activeBackground || null
    });
  });

  fastify.get('/stats/dashboard', { preHandler: authenticate }, async (request, reply) => {
    const servers = serverService.listServersForUser(request.user.id);
    const onlineCount = servers.filter(s => serverService.isRunning(s.id)).length;

    let totalPlayers = 0;
    let avgTps = 0;
    let tpsCount = 0;
    for (const s of servers) {
      const live = serverService.getLiveStats(s.id);
      if (live.online) {
        totalPlayers += live.players;
        avgTps += live.tps;
        tpsCount++;
      }
    }

    return ok(reply, {
      servers: {
        total: servers.length,
        online: onlineCount,
        offline: servers.length - onlineCount
      },
      players: totalPlayers,
      avgTps: tpsCount > 0 ? Math.round((avgTps / tpsCount) * 10) / 10 : 20.0,
      host: {
        cpu: getCpuUsagePercent(),
        memory: getMemoryInfo(),
        disk: getDiskInfo('.'),
        uptimeSeconds: getUptimeSeconds()
      },
      recentActivity: audit.recentForUser(request.user.id, 15)
    });
  });

  fastify.get('/stats/server/:id', { preHandler: authenticate }, async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!server || (server.owner_id !== request.user.id && request.user.role !== 'admin')) {
      return fail(reply, 'Server not found', 404);
    }
    return ok(reply, { stats: serverService.getLiveStats(server.id) });
  });
}

module.exports = statsRoutes;

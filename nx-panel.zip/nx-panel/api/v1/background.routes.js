'use strict';

const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { authenticate, requireAdmin } = require('../../auth/middleware');
const { ok, fail } = require('../../utils/response');
const backgroundService = require('../../services/background.service');

const ALLOWED_MIME = new Set(['video/mp4', 'video/webm']);
const MAX_SIZE_BYTES = 200 * 1024 * 1024; // 200MB

async function backgroundRoutes(fastify) {
  fastify.addHook('preHandler', authenticate);
  fastify.addHook('preHandler', requireAdmin);

  fastify.post('/backgrounds/upload', async (request, reply) => {
    const data = await request.file();
    if (!data) return fail(reply, 'No file uploaded', 422);

    if (!ALLOWED_MIME.has(data.mimetype)) {
      return fail(reply, 'Only MP4 and WebM video files are allowed', 422);
    }

    const ext = data.mimetype === 'video/mp4' ? '.mp4' : '.webm';
    const filename = `bg-${uuidv4()}${ext}`;
    const targetPath = path.join(backgroundService.BACKGROUNDS_DIR, filename);

    let totalBytes = 0;
    const writeStream = fs.createWriteStream(targetPath);

    try {
      await new Promise((resolve, reject) => {
        data.file.on('data', chunk => {
          totalBytes += chunk.length;
          if (totalBytes > MAX_SIZE_BYTES) {
            data.file.destroy();
            writeStream.destroy();
            reject(new Error('File exceeds maximum size of 200MB'));
          }
        });
        data.file.pipe(writeStream);
        writeStream.on('finish', resolve);
        writeStream.on('error', reject);
        data.file.on('error', reject);
      });
    } catch (err) {
      if (fs.existsSync(targetPath)) fs.unlinkSync(targetPath);
      return fail(reply, err.message, 400);
    }

    const background = backgroundService.registerBackground({ filename, mimeType: data.mimetype });
    return ok(reply, { background }, 'Background uploaded', 201);
  });
}

module.exports = backgroundRoutes;

'use strict';

const authRoutes = require('./auth.routes');
const serverRoutes = require('./server.routes');
const userRoutes = require('./user.routes');
const adminRoutes = require('./admin.routes');
const backgroundRoutes = require('./background.routes');
const statsRoutes = require('./stats.routes');

/**
 * Registers all versioned (v1) API routes under the /api/v1 prefix.
 * Each route module manages its own authentication preHandlers.
 */
async function registerApiV1(fastify) {
  await fastify.register(authRoutes);
  await fastify.register(serverRoutes);
  await fastify.register(userRoutes);
  await fastify.register(adminRoutes);
  await fastify.register(backgroundRoutes);
  await fastify.register(statsRoutes);
}

module.exports = registerApiV1;

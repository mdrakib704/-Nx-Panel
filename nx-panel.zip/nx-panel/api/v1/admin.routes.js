'use strict';

const { authenticate, requireAdmin } = require('../../auth/middleware');
const { ok, fail } = require('../../utils/response');
const db = require('../../database/db');
const serverService = require('../../services/server.service');
const coinService = require('../../services/coin.service');
const adService = require('../../services/ad.service');
const backgroundService = require('../../services/background.service');
const audit = require('../../services/audit.service');
const { isPositiveInt, isValidUsername, isValidEmail } = require('../../utils/validate');
const { getCpuUsagePercent, getMemoryInfo, getDiskInfo, getUptimeSeconds } = require('../../utils/systemStats');

async function adminRoutes(fastify) {
  fastify.addHook('preHandler', authenticate);
  fastify.addHook('preHandler', requireAdmin);

  // ---- Dashboard / stats ----
  fastify.get('/admin/overview', async (request, reply) => {
    const totalUsers = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
    const totalServers = db.prepare('SELECT COUNT(*) as c FROM servers').get().c;
    const onlineServers = db.prepare("SELECT COUNT(*) as c FROM servers WHERE status = 'online'").get().c;
    const suspendedUsers = db.prepare('SELECT COUNT(*) as c FROM users WHERE suspended = 1').get().c;

    return ok(reply, {
      totalUsers,
      totalServers,
      onlineServers,
      suspendedUsers,
      host: {
        cpu: getCpuUsagePercent(),
        memory: getMemoryInfo(),
        disk: getDiskInfo('.'),
        uptimeSeconds: getUptimeSeconds()
      }
    });
  });

  // ---- User management ----
  fastify.get('/admin/users', async (request, reply) => {
    const users = db
      .prepare(
        'SELECT id, username, email, role, coins, server_slots, suspended, created_at FROM users ORDER BY created_at DESC'
      )
      .all();
    return ok(reply, { users });
  });

  fastify.get('/admin/users/:id', async (request, reply) => {
    const user = db
      .prepare('SELECT id, username, email, role, coins, server_slots, suspended, created_at FROM users WHERE id = ?')
      .get(request.params.id);
    if (!user) return fail(reply, 'User not found', 404);
    const servers = serverService.listServersForUser(user.id);
    return ok(reply, { user, servers });
  });

  fastify.post('/admin/users/:id/suspend', async (request, reply) => {
    db.prepare('UPDATE users SET suspended = 1 WHERE id = ?').run(request.params.id);
    audit.log(request.user.id, 'admin.user_suspend', `Suspended user #${request.params.id}`, request.ip);
    return ok(reply, {}, 'User suspended');
  });

  fastify.post('/admin/users/:id/unsuspend', async (request, reply) => {
    db.prepare('UPDATE users SET suspended = 0 WHERE id = ?').run(request.params.id);
    audit.log(request.user.id, 'admin.user_unsuspend', `Unsuspended user #${request.params.id}`, request.ip);
    return ok(reply, {}, 'User unsuspended');
  });

  fastify.delete('/admin/users/:id', async (request, reply) => {
    const targetId = parseInt(request.params.id, 10);
    if (targetId === request.user.id) {
      return fail(reply, 'You cannot delete your own account', 400);
    }
    const servers = serverService.listServersForUser(targetId);
    for (const s of servers) serverService.deleteServer(s.id);
    db.prepare('DELETE FROM users WHERE id = ?').run(targetId);
    audit.log(request.user.id, 'admin.user_delete', `Deleted user #${targetId}`, request.ip);
    return ok(reply, {}, 'User deleted');
  });

  fastify.patch('/admin/users/:id', async (request, reply) => {
    const { serverSlots, role, coins } = request.body || {};
    const sets = [];
    const values = [];
    if (serverSlots !== undefined) {
      if (!isPositiveInt(serverSlots, 1000)) return fail(reply, 'Invalid serverSlots', 422);
      sets.push('server_slots = ?');
      values.push(serverSlots);
    }
    if (role !== undefined) {
      if (!['user', 'admin'].includes(role)) return fail(reply, 'Invalid role', 422);
      sets.push('role = ?');
      values.push(role);
    }
    if (coins !== undefined) {
      if (!Number.isInteger(coins) || coins < 0) return fail(reply, 'Invalid coins value', 422);
      sets.push('coins = ?');
      values.push(coins);
    }
    if (sets.length === 0) return fail(reply, 'No valid fields to update', 422);
    values.push(request.params.id);
    db.prepare(`UPDATE users SET ${sets.join(', ')} WHERE id = ?`).run(...values);
    audit.log(request.user.id, 'admin.user_edit', `Edited user #${request.params.id}`, request.ip);
    return ok(reply, {}, 'User updated');
  });

  fastify.post('/admin/users/:id/reward', async (request, reply) => {
    const { amount, description } = request.body || {};
    if (!Number.isInteger(amount) || amount === 0) return fail(reply, 'A non-zero integer amount is required', 422);
    const newBalance = coinService.manualReward(request.user.id, request.params.id, amount, description);
    audit.log(request.user.id, 'admin.coin_reward', `Rewarded user #${request.params.id} with ${amount} coins`, request.ip);
    return ok(reply, { balance: newBalance }, 'Reward applied');
  });

  // ---- Server management ----
  fastify.get('/admin/servers', async (request, reply) => {
    const servers = serverService.listAllServers().map(s => ({ ...s, live: serverService.getLiveStats(s.id) }));
    return ok(reply, { servers });
  });

  fastify.patch('/admin/servers/:id/resources', async (request, reply) => {
    const { ramMb, cpuPercent, diskMb } = request.body || {};
    const server = serverService.getServerById(request.params.id);
    if (!server) return fail(reply, 'Server not found', 404);
    const fields = {};
    if (ramMb !== undefined) {
      if (!isPositiveInt(ramMb, 131072)) return fail(reply, 'Invalid ramMb', 422);
      fields.ram_mb = ramMb;
    }
    if (cpuPercent !== undefined) {
      if (!isPositiveInt(cpuPercent, 1600)) return fail(reply, 'Invalid cpuPercent', 422);
      fields.cpu_percent = cpuPercent;
    }
    if (diskMb !== undefined) {
      if (!isPositiveInt(diskMb, 1048576)) return fail(reply, 'Invalid diskMb', 422);
      fields.disk_mb = diskMb;
    }
    const updated = serverService.updateServerMeta(server.id, fields);
    audit.log(request.user.id, 'admin.server_resources', `Updated resources for server ${server.id}`, request.ip);
    return ok(reply, { server: updated }, 'Resources updated');
  });

  fastify.post('/admin/servers/:id/suspend', async (request, reply) => {
    serverService.suspendServer(request.params.id, true);
    audit.log(request.user.id, 'admin.server_suspend', `Suspended server ${request.params.id}`, request.ip);
    return ok(reply, {}, 'Server suspended');
  });

  fastify.post('/admin/servers/:id/unsuspend', async (request, reply) => {
    serverService.suspendServer(request.params.id, false);
    audit.log(request.user.id, 'admin.server_unsuspend', `Unsuspended server ${request.params.id}`, request.ip);
    return ok(reply, {}, 'Server unsuspended');
  });

  fastify.delete('/admin/servers/:id', async (request, reply) => {
    serverService.deleteServer(request.params.id);
    audit.log(request.user.id, 'admin.server_delete', `Deleted server ${request.params.id}`, request.ip);
    return ok(reply, {}, 'Server deleted');
  });

  // ---- Broadcast / announcements ----
  fastify.post('/admin/broadcast', async (request, reply) => {
    const { title, message } = request.body || {};
    if (!title || !message) return fail(reply, 'Title and message are required', 422);
    const users = db.prepare('SELECT id FROM users').all();
    const insert = db.prepare('INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)');
    const tx = db.transaction(() => {
      for (const u of users) insert.run(u.id, title, message);
    });
    tx();
    const { broadcastGlobal } = require('../../websocket/hub');
    broadcastGlobal('broadcast', { title, message });
    audit.log(request.user.id, 'admin.broadcast', `Broadcast: ${title}`, request.ip);
    return ok(reply, {}, 'Broadcast sent');
  });

  fastify.get('/admin/announcements', async (request, reply) => {
    return ok(reply, { announcements: db.prepare('SELECT * FROM announcements ORDER BY created_at DESC').all() });
  });

  fastify.post('/admin/announcements', async (request, reply) => {
    const { title, message, severity } = request.body || {};
    if (!title || !message) return fail(reply, 'Title and message are required', 422);
    const sev = ['info', 'warning', 'critical'].includes(severity) ? severity : 'info';
    const result = db
      .prepare('INSERT INTO announcements (title, message, severity) VALUES (?, ?, ?)')
      .run(title, message, sev);
    return ok(reply, { id: result.lastInsertRowid }, 'Announcement created', 201);
  });

  fastify.delete('/admin/announcements/:id', async (request, reply) => {
    db.prepare('DELETE FROM announcements WHERE id = ?').run(request.params.id);
    return ok(reply, {}, 'Announcement removed');
  });

  // ---- Maintenance mode ----
  fastify.post('/admin/maintenance', async (request, reply) => {
    const { enabled, message } = request.body || {};
    db.prepare("INSERT INTO settings (key, value) VALUES ('maintenance_mode', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(
      enabled ? 'true' : 'false'
    );
    if (message) {
      db.prepare("INSERT INTO settings (key, value) VALUES ('maintenance_message', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(
        message
      );
    }
    audit.log(request.user.id, 'admin.maintenance', `Maintenance mode set to ${enabled}`, request.ip);
    return ok(reply, {}, 'Maintenance mode updated');
  });

  // ---- Settings / theme ----
  fastify.get('/admin/settings', async (request, reply) => {
    const rows = db.prepare('SELECT key, value FROM settings').all();
    const settings = {};
    for (const row of rows) settings[row.key] = row.value;
    return ok(reply, { settings });
  });

  fastify.post('/admin/settings', async (request, reply) => {
    const updates = request.body || {};
    const stmt = db.prepare(
      "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"
    );
    const tx = db.transaction(() => {
      for (const [k, v] of Object.entries(updates)) {
        stmt.run(k, String(v));
      }
    });
    tx();
    return ok(reply, {}, 'Settings updated');
  });

  // ---- Logs ----
  fastify.get('/admin/logs/audit', async (request, reply) => {
    return ok(reply, { logs: audit.recentAuditLogs(200) });
  });

  fastify.get('/admin/logs/activity', async (request, reply) => {
    return ok(reply, { logs: audit.recent(200) });
  });

  // ---- Coin manager ----
  fastify.get('/admin/promo-codes', async (request, reply) => {
    return ok(reply, { promoCodes: coinService.listPromoCodes() });
  });

  fastify.post('/admin/promo-codes', async (request, reply) => {
    const { code, amount, maxUses, expiresAt } = request.body || {};
    if (!code || typeof code !== 'string' || code.length > 32) return fail(reply, 'A valid code is required', 422);
    if (!Number.isInteger(amount) || amount <= 0) return fail(reply, 'A positive integer amount is required', 422);
    try {
      const promo = coinService.createPromoCode({ code, amount, maxUses, expiresAt });
      return ok(reply, { promo }, 'Promo code created', 201);
    } catch (err) {
      return fail(reply, 'Promo code already exists', 409);
    }
  });

  fastify.delete('/admin/promo-codes/:id', async (request, reply) => {
    coinService.deletePromoCode(request.params.id);
    return ok(reply, {}, 'Promo code deleted');
  });

  fastify.get('/admin/shop-items', async (request, reply) => {
    return ok(reply, { items: db.prepare('SELECT * FROM shop_items ORDER BY type').all() });
  });

  fastify.post('/admin/shop-items', async (request, reply) => {
    const { type, label, amount, price } = request.body || {};
    if (!['ram', 'cpu', 'storage', 'slot'].includes(type)) return fail(reply, 'Invalid type', 422);
    if (!label || !Number.isInteger(amount) || !Number.isInteger(price)) return fail(reply, 'Invalid shop item fields', 422);
    const result = db
      .prepare('INSERT INTO shop_items (type, label, amount, price) VALUES (?, ?, ?, ?)')
      .run(type, label, amount, price);
    return ok(reply, { id: result.lastInsertRowid }, 'Shop item created', 201);
  });

  fastify.patch('/admin/shop-items/:id', async (request, reply) => {
    const { label, amount, price, enabled } = request.body || {};
    const sets = [];
    const values = [];
    if (label !== undefined) { sets.push('label = ?'); values.push(label); }
    if (amount !== undefined) { sets.push('amount = ?'); values.push(amount); }
    if (price !== undefined) { sets.push('price = ?'); values.push(price); }
    if (enabled !== undefined) { sets.push('enabled = ?'); values.push(enabled ? 1 : 0); }
    if (sets.length === 0) return fail(reply, 'No fields to update', 422);
    values.push(request.params.id);
    db.prepare(`UPDATE shop_items SET ${sets.join(', ')} WHERE id = ?`).run(...values);
    return ok(reply, {}, 'Shop item updated');
  });

  fastify.delete('/admin/shop-items/:id', async (request, reply) => {
    db.prepare('DELETE FROM shop_items WHERE id = ?').run(request.params.id);
    return ok(reply, {}, 'Shop item deleted');
  });

  // ---- Ad manager ----
  fastify.get('/admin/ads', async (request, reply) => {
    return ok(reply, { ads: adService.listAllAds() });
  });

  fastify.post('/admin/ads', async (request, reply) => {
    const { title, type, content } = request.body || {};
    const validTypes = ['banner', 'reward', 'popup', 'html', 'image', 'video'];
    if (!title || !validTypes.includes(type) || !content) {
      return fail(reply, `Title, valid type (${validTypes.join(', ')}), and content are required`, 422);
    }
    const ad = adService.createAd(request.body);
    audit.log(request.user.id, 'admin.ad_create', `Created ad "${title}"`, request.ip);
    return ok(reply, { ad }, 'Ad created', 201);
  });

  fastify.patch('/admin/ads/:id', async (request, reply) => {
    const ad = adService.updateAd(request.params.id, request.body || {});
    return ok(reply, { ad }, 'Ad updated');
  });

  fastify.delete('/admin/ads/:id', async (request, reply) => {
    adService.deleteAd(request.params.id);
    return ok(reply, {}, 'Ad deleted');
  });

  fastify.get('/admin/ads/analytics', async (request, reply) => {
    return ok(reply, { analytics: adService.getAnalytics() });
  });

  // ---- Background manager ----
  fastify.get('/admin/backgrounds', async (request, reply) => {
    return ok(reply, { backgrounds: backgroundService.listBackgrounds() });
  });

  fastify.post('/admin/backgrounds/:id/activate', async (request, reply) => {
    const bg = backgroundService.setActiveBackground(request.params.id);
    const { broadcastGlobal } = require('../../websocket/hub');
    broadcastGlobal('background_changed', { background: bg });
    return ok(reply, { background: bg }, 'Background activated');
  });

  fastify.patch('/admin/backgrounds/:id', async (request, reply) => {
    const bg = backgroundService.updateBackgroundSettings(request.params.id, request.body || {});
    const { broadcastGlobal } = require('../../websocket/hub');
    broadcastGlobal('background_settings_changed', { background: bg });
    return ok(reply, { background: bg }, 'Background settings updated');
  });

  fastify.delete('/admin/backgrounds/:id', async (request, reply) => {
    backgroundService.deleteBackground(request.params.id);
    return ok(reply, {}, 'Background deleted');
  });
}

module.exports = adminRoutes;

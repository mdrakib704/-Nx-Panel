'use strict';

const path = require('path');
const fs = require('fs');
const { authenticate } = require('../../auth/middleware');
const { ok, fail } = require('../../utils/response');
const serverService = require('../../services/server.service');
const backupService = require('../../services/backup.service');
const fileManager = require('../../services/fileManager.service');
const config = require('../../config.json');
const db = require('../../database/db');
const { isValidServerName, isPositiveInt, isSafePathSegment } = require('../../utils/validate');
const { v4: uuidv4 } = require('uuid');

function ownsOrAdmin(request, server) {
  if (!server) return false;
  return request.user.role === 'admin' || server.owner_id === request.user.id;
}

async function serverRoutes(fastify) {
  fastify.addHook('preHandler', authenticate);

  // List servers owned by current user
  fastify.get('/servers', async (request, reply) => {
    const servers = serverService.listServersForUser(request.user.id);
    const enriched = servers.map(s => ({
      ...s,
      live: serverService.getLiveStats(s.id)
    }));
    return ok(reply, { servers: enriched });
  });

  // Create a new server (subject to free-tier slot limits)
  fastify.post('/servers', async (request, reply) => {
    const { name, software, mcVersion, javaVersion } = request.body || {};
    if (!isValidServerName(name)) {
      return fail(reply, 'Server name must be 1-64 characters (letters, numbers, spaces, - and _)', 422);
    }
    const validSoftware = ['paper', 'purpur', 'fabric', 'forge', 'vanilla'];
    if (!validSoftware.includes(software)) {
      return fail(reply, `Software must be one of: ${validSoftware.join(', ')}`, 422);
    }

    const user = db.prepare('SELECT server_slots FROM users WHERE id = ?').get(request.user.id);
    const currentCount = serverService.countServersForUser(request.user.id);
    if (currentCount >= user.server_slots) {
      return fail(reply, `You have reached your server slot limit (${user.server_slots}). Upgrade in the Shop for more slots.`, 403);
    }

    try {
      const server = await serverService.createServer({
        ownerId: request.user.id,
        name,
        software,
        mcVersion: mcVersion || 'latest',
        javaVersion: javaVersion || '21',
        ramMb: config.defaults.freeServer.ramMb,
        cpuPercent: config.defaults.freeServer.cpuPercent,
        diskMb: config.defaults.freeServer.diskMb
      });
      return ok(reply, { server }, 'Server created. Upload a server jar via File Manager to begin installation.', 201);
    } catch (err) {
      return fail(reply, err.message, 500);
    }
  });

  fastify.get('/servers/:id', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    return ok(reply, { server: { ...server, live: serverService.getLiveStats(server.id) } });
  });

  fastify.patch('/servers/:id', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { name } = request.body || {};
    if (name !== undefined && !isValidServerName(name)) {
      return fail(reply, 'Invalid server name', 422);
    }
    const updated = serverService.updateServerMeta(server.id, { name });
    return ok(reply, { server: updated }, 'Server updated');
  });

  fastify.delete('/servers/:id', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    serverService.deleteServer(server.id);
    return ok(reply, {}, 'Server deleted');
  });

  fastify.post('/servers/:id/start', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      serverService.startServer(server.id);
      return ok(reply, {}, 'Server starting');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/stop', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      serverService.stopServer(server.id, false);
      return ok(reply, {}, 'Server stopping');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/restart', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      serverService.restartServer(server.id);
      return ok(reply, {}, 'Server restarting');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/kill', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      serverService.stopServer(server.id, true);
      return ok(reply, {}, 'Server killed');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/command', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { command } = request.body || {};
    if (!command || typeof command !== 'string' || command.length > 500) {
      return fail(reply, 'A valid command is required', 422);
    }
    try {
      serverService.sendCommand(server.id, command);
      return ok(reply, {}, 'Command sent');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.get('/servers/:id/console', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    return ok(reply, { lines: serverService.getConsoleBuffer(server.id) });
  });

  // ---- File Manager ----

  fastify.get('/servers/:id/files', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      const entries = fileManager.listDirectory(server.id, request.query.path || '');
      return ok(reply, { entries, path: request.query.path || '' });
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.get('/servers/:id/files/content', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      const content = fileManager.readFile(server.id, request.query.path);
      return ok(reply, { content });
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.put('/servers/:id/files/content', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { path: filePath, content } = request.body || {};
    if (typeof content !== 'string') return fail(reply, 'Content must be a string', 422);
    try {
      fileManager.writeFile(server.id, filePath, content);
      return ok(reply, {}, 'File saved');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.delete('/servers/:id/files', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      fileManager.deleteEntry(server.id, request.query.path);
      return ok(reply, {}, 'Deleted');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/files/rename', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { path: filePath, newName } = request.body || {};
    if (!isSafePathSegment(newName)) return fail(reply, 'Invalid new name', 422);
    try {
      fileManager.renameEntry(server.id, filePath, newName);
      return ok(reply, {}, 'Renamed');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/files/mkdir', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { path: dirPath, name } = request.body || {};
    if (!isSafePathSegment(name)) return fail(reply, 'Invalid directory name', 422);
    try {
      fileManager.createDirectory(server.id, dirPath, name);
      return ok(reply, {}, 'Directory created');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/files/upload', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const data = await request.file();
    if (!data) return fail(reply, 'No file uploaded', 422);
    const targetPath = data.fields && data.fields.path ? data.fields.path.value : '';
    try {
      const buffer = await data.toBuffer();
      fileManager.saveUploadedFile(server.id, targetPath, data.filename, buffer);
      return ok(reply, { filename: data.filename }, 'File uploaded', 201);
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.get('/servers/:id/files/download', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      const filePath = fileManager.getFilePathForDownload(server.id, request.query.path);
      const stream = fs.createReadStream(filePath);
      reply.header('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
      return reply.send(stream);
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/files/zip', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { path: targetPath } = request.body || {};
    try {
      const outputName = `archive-${uuidv4()}.zip`;
      const outputPath = path.join(serverService.serverDir(server.id), outputName);
      await fileManager.zipDirectory(server.id, targetPath, outputPath);
      return ok(reply, { filename: outputName }, 'Archive created', 201);
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/servers/:id/files/unzip', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { path: targetPath } = request.body || {};
    try {
      await fileManager.unzipFile(server.id, targetPath);
      return ok(reply, {}, 'Archive extracted');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  // ---- Backups ----

  fastify.get('/servers/:id/backups', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    return ok(reply, { backups: backupService.listBackups(server.id) });
  });

  fastify.post('/servers/:id/backups', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    try {
      const backup = await backupService.createBackup(server.id, 'manual');
      return ok(reply, { backup }, 'Backup created', 201);
    } catch (err) {
      return fail(reply, err.message, 500);
    }
  });

  fastify.post('/servers/:id/backups/:backupId/restore', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    if (serverService.isRunning(server.id)) {
      return fail(reply, 'Stop the server before restoring a backup', 400);
    }
    try {
      await backupService.restoreBackup(request.params.backupId);
      return ok(reply, {}, 'Backup restored');
    } catch (err) {
      return fail(reply, err.message, 500);
    }
  });

  fastify.delete('/servers/:id/backups/:backupId', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    backupService.deleteBackup(request.params.backupId);
    return ok(reply, {}, 'Backup deleted');
  });

  fastify.get('/servers/:id/backups/schedules', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    return ok(reply, { schedules: backupService.listSchedules(server.id) });
  });

  fastify.post('/servers/:id/backups/schedules', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    const { intervalMinutes, keepCount } = request.body || {};
    if (!isPositiveInt(intervalMinutes) || !isPositiveInt(keepCount, 50)) {
      return fail(reply, 'Valid intervalMinutes and keepCount (max 50) are required', 422);
    }
    const schedule = backupService.createSchedule(server.id, intervalMinutes, keepCount);
    return ok(reply, { schedule }, 'Backup schedule created', 201);
  });

  fastify.delete('/servers/:id/backups/schedules/:scheduleId', async (request, reply) => {
    const server = serverService.getServerById(request.params.id);
    if (!ownsOrAdmin(request, server)) return fail(reply, 'Server not found', 404);
    backupService.deleteSchedule(request.params.scheduleId);
    return ok(reply, {}, 'Schedule deleted');
  });
}

module.exports = serverRoutes;

'use strict';

const authService = require('../../auth/auth.service');
const { authenticate } = require('../../auth/middleware');
const { ok, fail } = require('../../utils/response');
const { isValidUsername, isValidEmail, isValidPassword } = require('../../utils/validate');
const db = require('../../database/db');
const { hashToken } = require('../../auth/jwt');

async function authRoutes(fastify) {
  fastify.post('/auth/register', async (request, reply) => {
    const { username, email, password, referralCode } = request.body || {};

    if (!isValidUsername(username)) {
      return fail(reply, 'Username must be 3-20 characters (letters, numbers, underscore only)', 422);
    }
    if (!isValidEmail(email)) {
      return fail(reply, 'A valid email address is required', 422);
    }
    if (!isValidPassword(password)) {
      return fail(reply, 'Password must be at least 8 characters', 422);
    }

    try {
      const user = await authService.register(
        { username, email, password, referralCode },
        request.ip
      );
      return ok(reply, { user: authService.sanitizeUser(user) }, 'Registration successful', 201);
    } catch (err) {
      return fail(reply, err.message, err.statusCode || 400);
    }
  });

  fastify.post('/auth/login', async (request, reply) => {
    const { identifier, password, remember } = request.body || {};
    if (!identifier || !password) {
      return fail(reply, 'Username/email and password are required', 422);
    }

    try {
      const result = await authService.login({ identifier, password, remember }, request.ip);
      reply.setCookie('nx_refresh', result.refreshToken, {
        httpOnly: true,
        secure: request.protocol === 'https',
        sameSite: 'strict',
        path: '/',
        maxAge: remember ? 60 * 60 * 24 * 30 : 60 * 60 * 24
      });
      return ok(reply, {
        user: result.user,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken
      }, 'Login successful');
    } catch (err) {
      return fail(reply, err.message, err.statusCode || 400);
    }
  });

  fastify.post('/auth/refresh', async (request, reply) => {
    const tokenFromCookie = request.cookies ? request.cookies.nx_refresh : null;
    const token = (request.body && request.body.refreshToken) || tokenFromCookie;
    if (!token) {
      return fail(reply, 'Refresh token required', 401);
    }
    try {
      const result = authService.refresh(token, request.ip);
      reply.setCookie('nx_refresh', result.refreshToken, {
        httpOnly: true,
        secure: request.protocol === 'https',
        sameSite: 'strict',
        path: '/',
        maxAge: 60 * 60 * 24 * 30
      });
      return ok(reply, {
        user: result.user,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken
      }, 'Token refreshed');
    } catch (err) {
      return fail(reply, err.message, err.statusCode || 401);
    }
  });

  fastify.post('/auth/logout', async (request, reply) => {
    const tokenFromCookie = request.cookies ? request.cookies.nx_refresh : null;
    const token = (request.body && request.body.refreshToken) || tokenFromCookie;
    authService.logout(token);
    reply.clearCookie('nx_refresh', { path: '/' });
    return ok(reply, {}, 'Logged out');
  });

  fastify.post('/auth/forgot-password', async (request, reply) => {
    const { email } = request.body || {};
    if (!isValidEmail(email)) {
      return fail(reply, 'A valid email address is required', 422);
    }
    const token = authService.requestPasswordReset(email);
    // In a production deployment this token would be emailed to the user.
    // We avoid leaking whether the account exists in the response message.
    return ok(
      reply,
      process.env.NODE_ENV !== 'production' && token ? { devResetToken: token } : {},
      'If an account with that email exists, a reset link has been generated.'
    );
  });

  fastify.post('/auth/reset-password', async (request, reply) => {
    const { token, newPassword } = request.body || {};
    if (!token || !isValidPassword(newPassword)) {
      return fail(reply, 'A valid token and new password (min 8 chars) are required', 422);
    }
    try {
      await authService.resetPassword(token, newPassword);
      return ok(reply, {}, 'Password reset successful');
    } catch (err) {
      return fail(reply, err.message, err.statusCode || 400);
    }
  });

  fastify.get('/auth/me', { preHandler: authenticate }, async (request, reply) => {
    const user = authService.findUserById(request.user.id);
    return ok(reply, { user: authService.sanitizeUser(user) });
  });

  fastify.post('/auth/api-keys', { preHandler: authenticate }, async (request, reply) => {
    const { name, permissions } = request.body || {};
    if (!name || typeof name !== 'string' || name.length > 64) {
      return fail(reply, 'A valid key name is required', 422);
    }
    const crypto = require('crypto');
    const rawKey = 'nx_' + crypto.randomBytes(24).toString('hex');
    const prefix = rawKey.slice(0, 8);
    const hash = hashToken(rawKey);
    const perms = Array.isArray(permissions) ? permissions.filter(p => typeof p === 'string') : [];

    db.prepare(
      'INSERT INTO api_keys (user_id, name, key_hash, key_prefix, permissions) VALUES (?, ?, ?, ?, ?)'
    ).run(request.user.id, name, hash, prefix, JSON.stringify(perms));

    return ok(reply, { apiKey: rawKey, name, permissions: perms }, 'API key created. Store it securely, it will not be shown again.', 201);
  });

  fastify.get('/auth/api-keys', { preHandler: authenticate }, async (request, reply) => {
    const keys = db
      .prepare('SELECT id, name, key_prefix, permissions, last_used_at, created_at FROM api_keys WHERE user_id = ?')
      .all(request.user.id);
    return ok(reply, { apiKeys: keys });
  });

  fastify.delete('/auth/api-keys/:id', { preHandler: authenticate }, async (request, reply) => {
    const id = parseInt(request.params.id, 10);
    const key = db.prepare('SELECT * FROM api_keys WHERE id = ? AND user_id = ?').get(id, request.user.id);
    if (!key) return fail(reply, 'API key not found', 404);
    db.prepare('DELETE FROM api_keys WHERE id = ?').run(id);
    return ok(reply, {}, 'API key revoked');
  });
}

module.exports = authRoutes;

'use strict';

const { authenticate } = require('../../auth/middleware');
const { ok, fail } = require('../../utils/response');
const coinService = require('../../services/coin.service');
const adService = require('../../services/ad.service');
const audit = require('../../services/audit.service');
const db = require('../../database/db');

async function userRoutes(fastify) {
  fastify.addHook('preHandler', authenticate);

  fastify.get('/user/notifications', async (request, reply) => {
    const notifications = db
      .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
      .all(request.user.id);
    return ok(reply, { notifications });
  });

  fastify.post('/user/notifications/:id/read', async (request, reply) => {
    db.prepare('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?').run(
      request.params.id,
      request.user.id
    );
    return ok(reply, {}, 'Marked as read');
  });

  fastify.get('/user/activity', async (request, reply) => {
    return ok(reply, { activity: audit.recentForUser(request.user.id, 50) });
  });

  // ---- Coins ----

  fastify.get('/coins/balance', async (request, reply) => {
    return ok(reply, { balance: coinService.getBalance(request.user.id) });
  });

  fastify.post('/coins/daily', async (request, reply) => {
    try {
      const result = coinService.claimDailyReward(request.user.id);
      return ok(reply, result, 'Daily reward claimed');
    } catch (err) {
      return fail(reply, err.message, 400, err.remainingSeconds ? { remainingSeconds: err.remainingSeconds } : null);
    }
  });

  fastify.post('/coins/promo', async (request, reply) => {
    const { code } = request.body || {};
    if (!code || typeof code !== 'string' || code.length > 32) {
      return fail(reply, 'A valid promo code is required', 422);
    }
    try {
      const result = coinService.redeemPromoCode(request.user.id, code);
      return ok(reply, result, 'Promo code redeemed');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.get('/coins/transactions', async (request, reply) => {
    return ok(reply, { transactions: coinService.getTransactionHistory(request.user.id, 100) });
  });

  fastify.get('/coins/leaderboard', async (request, reply) => {
    return ok(reply, { leaderboard: coinService.getLeaderboard(20) });
  });

  fastify.get('/shop/items', async (request, reply) => {
    const items = db.prepare('SELECT * FROM shop_items WHERE enabled = 1').all();
    return ok(reply, { items });
  });

  fastify.post('/shop/purchase/:itemId', async (request, reply) => {
    try {
      const item = coinService.purchaseShopItem(request.user.id, request.params.itemId);
      if (item.type === 'slot') {
        db.prepare('UPDATE users SET server_slots = server_slots + ? WHERE id = ?').run(item.amount, request.user.id);
      }
      // RAM/CPU/storage upgrades apply to a target server chosen by the user via a separate endpoint
      return ok(reply, { item, balance: coinService.getBalance(request.user.id) }, 'Purchase successful');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  fastify.post('/shop/apply-upgrade/:itemId', async (request, reply) => {
    const { serverId } = request.body || {};
    const serverService = require('../../services/server.service');
    const server = serverService.getServerById(serverId);
    if (!server || server.owner_id !== request.user.id) {
      return fail(reply, 'Server not found', 404);
    }
    const item = db.prepare('SELECT * FROM shop_items WHERE id = ? AND enabled = 1').get(request.params.itemId);
    if (!item) return fail(reply, 'Shop item not found', 404);

    try {
      coinService.deductCoins(request.user.id, item.price, 'purchase', `Applied upgrade: ${item.label} to ${server.name}`);
      const fieldMap = { ram: 'ram_mb', cpu: 'cpu_percent', storage: 'disk_mb' };
      const field = fieldMap[item.type];
      if (field) {
        db.prepare(`UPDATE servers SET ${field} = ${field} + ? WHERE id = ?`).run(item.amount, serverId);
      }
      return ok(reply, { server: serverService.getServerById(serverId) }, 'Upgrade applied');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });

  // ---- Ads ----

  fastify.get('/ads/active', async (request, reply) => {
    return ok(reply, { ads: adService.listActiveAds() });
  });

  fastify.post('/ads/:id/impression', async (request, reply) => {
    adService.recordImpression(request.params.id);
    return ok(reply, {}, 'Recorded');
  });

  fastify.post('/ads/:id/click', async (request, reply) => {
    adService.recordClick(request.params.id);
    return ok(reply, {}, 'Recorded');
  });

  fastify.post('/ads/:id/claim', async (request, reply) => {
    try {
      const result = adService.claimAdReward(request.user.id, request.params.id);
      return ok(reply, result, 'Reward claimed');
    } catch (err) {
      return fail(reply, err.message, 400);
    }
  });
}

module.exports = userRoutes;

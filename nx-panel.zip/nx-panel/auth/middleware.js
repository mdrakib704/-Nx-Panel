'use strict';

const crypto = require('crypto');
const db = require('../database/db');
const { verifyAccessToken } = require('./jwt');
const { fail } = require('../utils/response');

/**
 * Verifies the Bearer JWT access token on the request and attaches
 * `request.user` = { id, username, role }.
 */
async function authenticate(request, reply) {
  const header = request.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return fail(reply, 'Authentication required', 401);
  }
  const token = header.slice(7);

  try {
    const decoded = verifyAccessToken(token);
    const user = db.prepare('SELECT id, username, email, role, suspended FROM users WHERE id = ?').get(decoded.sub);
    if (!user) {
      return fail(reply, 'User not found', 401);
    }
    if (user.suspended) {
      return fail(reply, 'Account suspended', 403);
    }
    request.user = { id: user.id, username: user.username, email: user.email, role: user.role };
  } catch (err) {
    return fail(reply, 'Invalid or expired token', 401);
  }
}

/**
 * Requires request.user.role === 'admin'. Must run after authenticate.
 */
async function requireAdmin(request, reply) {
  if (!request.user || request.user.role !== 'admin') {
    return fail(reply, 'Administrator privileges required', 403);
  }
}

/**
 * Alternative authentication via API key (header: x-api-key).
 * Attaches request.user and request.apiKeyPermissions.
 */
async function authenticateApiKey(request, reply) {
  const key = request.headers['x-api-key'];
  if (!key || typeof key !== 'string' || key.length < 10) {
    return fail(reply, 'API key required', 401);
  }
  const prefix = key.slice(0, 8);
  const hash = crypto.createHash('sha256').update(key).digest('hex');

  const row = db
    .prepare('SELECT * FROM api_keys WHERE key_prefix = ? AND key_hash = ?')
    .get(prefix, hash);

  if (!row) {
    return fail(reply, 'Invalid API key', 401);
  }

  const user = db.prepare('SELECT id, username, email, role, suspended FROM users WHERE id = ?').get(row.user_id);
  if (!user || user.suspended) {
    return fail(reply, 'Account unavailable', 403);
  }

  db.prepare('UPDATE api_keys SET last_used_at = strftime(\'%s\',\'now\') WHERE id = ?').run(row.id);

  request.user = { id: user.id, username: user.username, email: user.email, role: user.role };
  request.apiKeyPermissions = JSON.parse(row.permissions || '[]');
}

/**
 * Combined middleware: accepts either a valid JWT or a valid API key.
 * Useful for versioned public API routes.
 */
async function authenticateAny(request, reply) {
  if (request.headers['x-api-key']) {
    return authenticateApiKey(request, reply);
  }
  return authenticate(request, reply);
}

module.exports = {
  authenticate,
  requireAdmin,
  authenticateApiKey,
  authenticateAny
};

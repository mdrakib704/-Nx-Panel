'use strict';

const bcrypt = require('bcrypt');
const crypto = require('crypto');
const db = require('../database/db');
const config = require('../config.json');
const { signAccessToken, signRefreshToken, verifyRefreshToken, hashToken } = require('./jwt');
const { createLogger } = require('../utils/logger');
const audit = require('../services/audit.service');

const log = createLogger('auth.service');

class AuthError extends Error {
  constructor(message, statusCode = 400) {
    super(message);
    this.statusCode = statusCode;
  }
}

function sanitizeUser(user) {
  if (!user) return null;
  const { password_hash, totp_secret, reset_token, ...safe } = user;
  return safe;
}

function findUserByUsernameOrEmail(identifier) {
  return db
    .prepare('SELECT * FROM users WHERE username = ? OR email = ?')
    .get(identifier, identifier);
}

function findUserById(id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

async function register({ username, email, password, referralCode }, ip) {
  const existing = db
    .prepare('SELECT id FROM users WHERE username = ? OR email = ?')
    .get(username, email);
  if (existing) {
    throw new AuthError('Username or email already in use', 409);
  }

  let referredBy = null;
  if (referralCode) {
    const referrer = db.prepare('SELECT id FROM users WHERE referral_code = ?').get(referralCode);
    if (referrer) referredBy = referrer.id;
  }

  const hash = await bcrypt.hash(password, config.security.bcryptRounds);
  const myReferralCode = crypto.randomBytes(5).toString('hex').toUpperCase();

  const result = db
    .prepare(
      `INSERT INTO users (username, email, password_hash, coins, server_slots, referral_code, referred_by)
       VALUES (?, ?, ?, ?, 1, ?, ?)`
    )
    .run(username, email, hash, config.coins.startingBalance, myReferralCode, referredBy);

  const newUserId = result.lastInsertRowid;

  if (referredBy) {
    db.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').run(
      config.coins.referralReward,
      referredBy
    );
    db.prepare(
      'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)'
    ).run(referredBy, config.coins.referralReward, 'referral', `Referral bonus for inviting ${username}`);
  }

  audit.log(newUserId, 'user.register', `User ${username} registered`, ip);
  log.info(`New user registered: ${username}`);

  return findUserById(newUserId);
}

async function login({ identifier, password, remember }, ip) {
  const user = findUserByUsernameOrEmail(identifier);
  if (!user) {
    throw new AuthError('Invalid credentials', 401);
  }
  if (user.suspended) {
    throw new AuthError('This account has been suspended', 403);
  }

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) {
    audit.log(user.id, 'user.login_failed', 'Invalid password attempt', ip);
    throw new AuthError('Invalid credentials', 401);
  }

  const accessToken = signAccessToken(user);
  const refreshToken = signRefreshToken(user, !!remember);
  const decoded = verifyRefreshToken(refreshToken);

  db.prepare(
    'INSERT INTO refresh_tokens (user_id, token_hash, expires_at, remember) VALUES (?, ?, ?, ?)'
  ).run(user.id, hashToken(refreshToken), decoded.exp, remember ? 1 : 0);

  audit.log(user.id, 'user.login', 'Successful login', ip);

  return { user: sanitizeUser(user), accessToken, refreshToken };
}

function refresh(refreshToken, ip) {
  let decoded;
  try {
    decoded = verifyRefreshToken(refreshToken);
  } catch (err) {
    throw new AuthError('Invalid or expired refresh token', 401);
  }

  const tokenHash = hashToken(refreshToken);
  const stored = db
    .prepare('SELECT * FROM refresh_tokens WHERE token_hash = ? AND user_id = ?')
    .get(tokenHash, decoded.sub);

  if (!stored) {
    throw new AuthError('Refresh token has been revoked', 401);
  }
  if (stored.expires_at < Math.floor(Date.now() / 1000)) {
    db.prepare('DELETE FROM refresh_tokens WHERE id = ?').run(stored.id);
    throw new AuthError('Refresh token expired', 401);
  }

  const user = findUserById(decoded.sub);
  if (!user || user.suspended) {
    throw new AuthError('Account unavailable', 403);
  }

  // Rotate refresh token
  db.prepare('DELETE FROM refresh_tokens WHERE id = ?').run(stored.id);
  const newRefreshToken = signRefreshToken(user, !!stored.remember);
  const newDecoded = verifyRefreshToken(newRefreshToken);
  db.prepare(
    'INSERT INTO refresh_tokens (user_id, token_hash, expires_at, remember) VALUES (?, ?, ?, ?)'
  ).run(user.id, hashToken(newRefreshToken), newDecoded.exp, stored.remember);

  const accessToken = signAccessToken(user);
  audit.log(user.id, 'user.token_refresh', 'Access token refreshed', ip);

  return { user: sanitizeUser(user), accessToken, refreshToken: newRefreshToken };
}

function logout(refreshToken) {
  if (!refreshToken) return;
  db.prepare('DELETE FROM refresh_tokens WHERE token_hash = ?').run(hashToken(refreshToken));
}

function requestPasswordReset(email) {
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) {
    // Do not leak account existence
    return null;
  }
  const token = crypto.randomBytes(32).toString('hex');
  const expires = Math.floor(Date.now() / 1000) + 3600; // 1 hour
  db.prepare('UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?').run(
    token,
    expires,
    user.id
  );
  audit.log(user.id, 'user.password_reset_requested', 'Password reset requested', null);
  return token;
}

async function resetPassword(token, newPassword) {
  const user = db.prepare('SELECT * FROM users WHERE reset_token = ?').get(token);
  if (!user || !user.reset_token_expires || user.reset_token_expires < Math.floor(Date.now() / 1000)) {
    throw new AuthError('Invalid or expired reset token', 400);
  }
  const hash = await bcrypt.hash(newPassword, config.security.bcryptRounds);
  db.prepare(
    'UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?'
  ).run(hash, user.id);
  db.prepare('DELETE FROM refresh_tokens WHERE user_id = ?').run(user.id);
  audit.log(user.id, 'user.password_reset', 'Password reset completed', null);
}

module.exports = {
  AuthError,
  sanitizeUser,
  register,
  login,
  refresh,
  logout,
  requestPasswordReset,
  resetPassword,
  findUserById,
  findUserByUsernameOrEmail
};

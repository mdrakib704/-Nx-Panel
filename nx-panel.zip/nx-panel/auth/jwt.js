'use strict';

const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const config = require('../config.json');

function signAccessToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, role: user.role },
    config.security.jwtSecret,
    { expiresIn: config.security.jwtExpiresIn }
  );
}

function signRefreshToken(user, remember) {
  const expiresIn = remember ? config.security.jwtRefreshExpiresIn : '1d';
  return jwt.sign(
    { sub: user.id, type: 'refresh', jti: crypto.randomUUID() },
    config.security.jwtRefreshSecret,
    { expiresIn }
  );
}

function verifyAccessToken(token) {
  return jwt.verify(token, config.security.jwtSecret);
}

function verifyRefreshToken(token) {
  return jwt.verify(token, config.security.jwtRefreshSecret);
}

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  hashToken
};

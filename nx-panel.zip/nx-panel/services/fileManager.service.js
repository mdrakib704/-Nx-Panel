'use strict';

const path = require('path');
const fs = require('fs');
const archiver = require('archiver');
const unzipper = require('unzipper');
const { serverDir } = require('./server.service');
const { resolveSafePath } = require('../utils/validate');

const MAX_EDITABLE_SIZE = 5 * 1024 * 1024; // 5MB
const TEXT_EXTENSIONS = new Set([
  '.txt', '.yml', '.yaml', '.json', '.properties', '.conf', '.cfg',
  '.toml', '.log', '.md', '.js', '.mcfunction', '.sh'
]);

function listDirectory(serverId, relativePath) {
  const base = serverDir(serverId);
  const target = resolveSafePath(path, base, relativePath);
  if (!fs.existsSync(target)) throw new Error('Path not found');
  const stat = fs.statSync(target);
  if (!stat.isDirectory()) throw new Error('Not a directory');

  const entries = fs.readdirSync(target, { withFileTypes: true });
  return entries
    .map(entry => {
      const entryPath = path.join(target, entry.name);
      let size = 0;
      let modified = 0;
      try {
        const s = fs.statSync(entryPath);
        size = s.size;
        modified = Math.floor(s.mtimeMs / 1000);
      } catch (err) {
        /* ignore */
      }
      return {
        name: entry.name,
        type: entry.isDirectory() ? 'directory' : 'file',
        size,
        modified
      };
    })
    .sort((a, b) => {
      if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
}

function readFile(serverId, relativePath) {
  const base = serverDir(serverId);
  const target = resolveSafePath(path, base, relativePath);
  const stat = fs.statSync(target);
  if (!stat.isFile()) throw new Error('Not a file');
  if (stat.size > MAX_EDITABLE_SIZE) throw new Error('File too large to edit in browser');
  const ext = path.extname(target).toLowerCase();
  if (!TEXT_EXTENSIONS.has(ext)) throw new Error('File type not editable in browser');
  return fs.readFileSync(target, 'utf8');
}

function writeFile(serverId, relativePath, content) {
  const base = serverDir(serverId);
  const target = resolveSafePath(path, base, relativePath);
  const ext = path.extname(target).toLowerCase();
  if (!TEXT_EXTENSIONS.has(ext)) throw new Error('File type not editable in browser');
  fs.writeFileSync(target, content, 'utf8');
  return true;
}

function deleteEntry(serverId, relativePath) {
  const base = serverDir(serverId);
  const target = resolveSafePath(path, base, relativePath);
  if (target === path.resolve(base)) throw new Error('Cannot delete server root directory');
  fs.rmSync(target, { recursive: true, force: true });
  return true;
}

function renameEntry(serverId, relativePath, newName) {
  const base = serverDir(serverId);
  const target = resolveSafePath(path, base, relativePath);
  if (newName.includes('/') || newName.includes('\\') || newName === '.' || newName === '..') {
    throw new Error('Invalid new name');
  }
  const dest = path.join(path.dirname(target), newName);
  const resolvedBase = path.resolve(base);
  if (dest !== resolvedBase && !path.resolve(dest).startsWith(resolvedBase + path.sep)) {
    throw new Error('Path traversal detected');
  }
  fs.renameSync(target, dest);
  return true;
}

function createDirectory(serverId, relativePath, name) {
  const base = serverDir(serverId);
  const parent = resolveSafePath(path, base, relativePath);
  if (name.includes('/') || name.includes('\\') || name === '.' || name === '..') {
    throw new Error('Invalid directory name');
  }
  const target = path.join(parent, name);
  fs.mkdirSync(target, { recursive: true });
  return true;
}

function getFilePathForDownload(serverId, relativePath) {
  const base = serverDir(serverId);
  const target = resolveSafePath(path, base, relativePath);
  if (!fs.existsSync(target)) throw new Error('File not found');
  return target;
}

function saveUploadedFile(serverId, relativePath, filename, buffer) {
  const base = serverDir(serverId);
  const dir = resolveSafePath(path, base, relativePath);
  if (filename.includes('/') || filename.includes('\\')) throw new Error('Invalid filename');
  const target = path.join(dir, filename);
  fs.writeFileSync(target, buffer);
  return target;
}

function zipDirectory(serverId, relativePath, outputZipPath) {
  return new Promise((resolve, reject) => {
    const base = serverDir(serverId);
    const target = resolveSafePath(path, base, relativePath);
    const output = fs.createWriteStream(outputZipPath);
    const archive = archiver('zip', { zlib: { level: 6 } });

    output.on('close', () => resolve(outputZipPath));
    archive.on('error', err => reject(err));
    archive.pipe(output);

    const stat = fs.statSync(target);
    if (stat.isDirectory()) {
      archive.directory(target, false);
    } else {
      archive.file(target, { name: path.basename(target) });
    }
    archive.finalize();
  });
}

async function unzipFile(serverId, relativePath) {
  const base = serverDir(serverId);
  const target = resolveSafePath(path, base, relativePath);
  const destDir = path.dirname(target);
  await fs.createReadStream(target).pipe(unzipper.Extract({ path: destDir })).promise();
  return true;
}

module.exports = {
  listDirectory,
  readFile,
  writeFile,
  deleteEntry,
  renameEntry,
  createDirectory,
  getFilePathForDownload,
  saveUploadedFile,
  zipDirectory,
  unzipFile,
  MAX_EDITABLE_SIZE,
  TEXT_EXTENSIONS
};

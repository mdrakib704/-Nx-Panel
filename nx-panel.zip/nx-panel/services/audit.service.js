'use strict';

const db = require('../database/db');

function log(userId, action, details, ip) {
  try {
    db.prepare(
      'INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)'
    ).run(userId || null, action, details || null, ip || null);
  } catch (err) {
    // Auditing must never crash the calling operation.
    console.error('[audit] failed to write audit log:', err.message);
  }
}

function activity(userId, serverId, action) {
  try {
    db.prepare(
      'INSERT INTO activity_log (user_id, server_id, action) VALUES (?, ?, ?)'
    ).run(userId || null, serverId || null, action);
  } catch (err) {
    console.error('[activity] failed to write activity log:', err.message);
  }
}

function recent(limit = 50) {
  return db
    .prepare(
      `SELECT a.id, a.action, a.server_id, a.created_at, u.username
       FROM activity_log a
       LEFT JOIN users u ON u.id = a.user_id
       ORDER BY a.id DESC LIMIT ?`
    )
    .all(limit);
}

function recentForUser(userId, limit = 50) {
  return db
    .prepare(
      `SELECT a.id, a.action, a.server_id, a.created_at, u.username
       FROM activity_log a
       LEFT JOIN users u ON u.id = a.user_id
       WHERE a.user_id = ?
       ORDER BY a.id DESC LIMIT ?`
    )
    .all(userId, limit);
}

function recentAuditLogs(limit = 100) {
  return db
    .prepare(
      `SELECT al.id, al.action, al.details, al.ip_address, al.created_at, u.username
       FROM audit_logs al
       LEFT JOIN users u ON u.id = al.user_id
       ORDER BY al.id DESC LIMIT ?`
    )
    .all(limit);
}

module.exports = { log, activity, recent, recentForUser, recentAuditLogs };

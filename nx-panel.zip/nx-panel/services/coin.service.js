'use strict';

const db = require('../database/db');
const config = require('../config.json');

const DAY_SECONDS = 86400;

function getBalance(userId) {
  const row = db.prepare('SELECT coins FROM users WHERE id = ?').get(userId);
  return row ? row.coins : 0;
}

function addCoins(userId, amount, type, description) {
  const tx = db.transaction(() => {
    db.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').run(amount, userId);
    db.prepare(
      'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)'
    ).run(userId, amount, type, description || null);
  });
  tx();
  return getBalance(userId);
}

function deductCoins(userId, amount, type, description) {
  const balance = getBalance(userId);
  if (balance < amount) {
    throw new Error('Insufficient coin balance');
  }
  return addCoins(userId, -amount, type, description);
}

function claimDailyReward(userId) {
  const user = db.prepare('SELECT last_daily_reward FROM users WHERE id = ?').get(userId);
  const now = Math.floor(Date.now() / 1000);
  if (user.last_daily_reward && now - user.last_daily_reward < DAY_SECONDS) {
    const remaining = DAY_SECONDS - (now - user.last_daily_reward);
    const err = new Error('Daily reward already claimed');
    err.remainingSeconds = remaining;
    throw err;
  }
  db.prepare('UPDATE users SET last_daily_reward = ? WHERE id = ?').run(now, userId);
  const newBalance = addCoins(userId, config.coins.dailyReward, 'daily', 'Daily login reward');
  return { amount: config.coins.dailyReward, balance: newBalance };
}

function redeemPromoCode(userId, code) {
  const promo = db.prepare('SELECT * FROM promo_codes WHERE code = ?').get(code.toUpperCase());
  if (!promo) throw new Error('Invalid promo code');
  if (promo.expires_at && promo.expires_at < Math.floor(Date.now() / 1000)) {
    throw new Error('Promo code has expired');
  }
  if (promo.used_count >= promo.max_uses) {
    throw new Error('Promo code has reached its usage limit');
  }
  const already = db
    .prepare('SELECT id FROM promo_redemptions WHERE promo_id = ? AND user_id = ?')
    .get(promo.id, userId);
  if (already) throw new Error('You have already redeemed this promo code');

  const tx = db.transaction(() => {
    db.prepare('INSERT INTO promo_redemptions (promo_id, user_id) VALUES (?, ?)').run(promo.id, userId);
    db.prepare('UPDATE promo_codes SET used_count = used_count + 1 WHERE id = ?').run(promo.id);
    addCoins(userId, promo.amount, 'promo', `Promo code redeemed: ${promo.code}`);
  });
  tx();

  return { amount: promo.amount, balance: getBalance(userId) };
}

function createPromoCode({ code, amount, maxUses, expiresAt }) {
  const result = db
    .prepare(
      'INSERT INTO promo_codes (code, amount, max_uses, expires_at) VALUES (?, ?, ?, ?)'
    )
    .run(code.toUpperCase(), amount, maxUses || 1, expiresAt || null);
  return db.prepare('SELECT * FROM promo_codes WHERE id = ?').get(result.lastInsertRowid);
}

function listPromoCodes() {
  return db.prepare('SELECT * FROM promo_codes ORDER BY created_at DESC').all();
}

function deletePromoCode(id) {
  db.prepare('DELETE FROM promo_codes WHERE id = ?').run(id);
}

function manualReward(adminUserId, targetUserId, amount, description) {
  return addCoins(targetUserId, amount, 'manual', description || `Manual adjustment by admin #${adminUserId}`);
}

function getTransactionHistory(userId, limit = 50) {
  return db
    .prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?')
    .all(userId, limit);
}

function getLeaderboard(limit = 20) {
  return db
    .prepare('SELECT id, username, coins FROM users WHERE suspended = 0 ORDER BY coins DESC LIMIT ?')
    .all(limit);
}

function purchaseShopItem(userId, itemId) {
  const item = db.prepare('SELECT * FROM shop_items WHERE id = ? AND enabled = 1').get(itemId);
  if (!item) throw new Error('Shop item not found or disabled');

  deductCoins(userId, item.price, 'purchase', `Purchased: ${item.label}`);
  return item;
}

module.exports = {
  getBalance,
  addCoins,
  deductCoins,
  claimDailyReward,
  redeemPromoCode,
  createPromoCode,
  listPromoCodes,
  deletePromoCode,
  manualReward,
  getTransactionHistory,
  getLeaderboard,
  purchaseShopItem
};

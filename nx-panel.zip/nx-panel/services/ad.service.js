'use strict';

const db = require('../database/db');
const coinService = require('./coin.service');

function listActiveAds() {
  const now = Math.floor(Date.now() / 1000);
  return db
    .prepare(
      `SELECT * FROM ads WHERE enabled = 1
       AND (start_at IS NULL OR start_at <= ?)
       AND (end_at IS NULL OR end_at >= ?)
       ORDER BY created_at DESC`
    )
    .all(now, now);
}

function listAllAds() {
  return db.prepare('SELECT * FROM ads ORDER BY created_at DESC').all();
}

function getAd(id) {
  return db.prepare('SELECT * FROM ads WHERE id = ?').get(id);
}

function createAd(data) {
  const result = db
    .prepare(
      `INSERT INTO ads (title, type, content, link_url, coin_reward, frequency_minutes, start_at, end_at, enabled)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      data.title,
      data.type,
      data.content,
      data.linkUrl || null,
      data.coinReward || 0,
      data.frequencyMinutes || 60,
      data.startAt || null,
      data.endAt || null,
      data.enabled === false ? 0 : 1
    );
  return getAd(result.lastInsertRowid);
}

function updateAd(id, data) {
  const allowed = ['title', 'type', 'content', 'link_url', 'coin_reward', 'frequency_minutes', 'start_at', 'end_at', 'enabled'];
  const map = {
    title: data.title,
    type: data.type,
    content: data.content,
    link_url: data.linkUrl,
    coin_reward: data.coinReward,
    frequency_minutes: data.frequencyMinutes,
    start_at: data.startAt,
    end_at: data.endAt,
    enabled: data.enabled === undefined ? undefined : (data.enabled ? 1 : 0)
  };
  const sets = [];
  const values = [];
  for (const key of allowed) {
    if (map[key] !== undefined) {
      sets.push(`${key} = ?`);
      values.push(map[key]);
    }
  }
  if (sets.length === 0) return getAd(id);
  values.push(id);
  db.prepare(`UPDATE ads SET ${sets.join(', ')} WHERE id = ?`).run(...values);
  return getAd(id);
}

function deleteAd(id) {
  db.prepare('DELETE FROM ads WHERE id = ?').run(id);
}

function recordImpression(adId) {
  db.prepare('UPDATE ads SET impressions = impressions + 1 WHERE id = ?').run(adId);
}

function recordClick(adId) {
  db.prepare('UPDATE ads SET clicks = clicks + 1 WHERE id = ?').run(adId);
}

function claimAdReward(userId, adId) {
  const ad = getAd(adId);
  if (!ad || !ad.enabled) throw new Error('Ad not found or inactive');
  if (ad.coin_reward <= 0) throw new Error('This ad does not offer a coin reward');

  const now = Math.floor(Date.now() / 1000);
  const cutoff = now - ad.frequency_minutes * 60;
  const recent = db
    .prepare(
      'SELECT id FROM ad_views WHERE ad_id = ? AND user_id = ? AND rewarded = 1 AND viewed_at > ?'
    )
    .get(adId, userId, cutoff);

  if (recent) {
    throw new Error('You must wait before claiming this ad reward again');
  }

  const tx = db.transaction(() => {
    db.prepare('INSERT INTO ad_views (ad_id, user_id, rewarded) VALUES (?, ?, 1)').run(adId, userId);
    db.prepare('UPDATE ads SET rewards_claimed = rewards_claimed + 1 WHERE id = ?').run(adId);
    coinService.addCoins(userId, ad.coin_reward, 'ad_reward', `Reward ad: ${ad.title}`);
  });
  tx();

  return { amount: ad.coin_reward, balance: coinService.getBalance(userId) };
}

function getAnalytics() {
  return db
    .prepare(
      'SELECT id, title, type, impressions, clicks, rewards_claimed, enabled FROM ads ORDER BY impressions DESC'
    )
    .all();
}

module.exports = {
  listActiveAds,
  listAllAds,
  getAd,
  createAd,
  updateAd,
  deleteAd,
  recordImpression,
  recordClick,
  claimAdReward,
  getAnalytics
};

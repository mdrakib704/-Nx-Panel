'use strict';

const path = require('path');
const fs = require('fs');
const archiver = require('archiver');
const unzipper = require('unzipper');
const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');
const { serverDir } = require('./server.service');
const audit = require('./audit.service');
const { createLogger } = require('../utils/logger');

const log = createLogger('backup.service');

const BACKUPS_DIR = path.resolve(__dirname, '..', 'backups');
if (!fs.existsSync(BACKUPS_DIR)) fs.mkdirSync(BACKUPS_DIR, { recursive: true });

function backupDirForServer(serverId) {
  const dir = path.join(BACKUPS_DIR, serverId);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function createBackup(serverId, type = 'manual') {
  return new Promise((resolve, reject) => {
    const id = uuidv4();
    const filename = `backup-${id}.zip`;
    const targetDir = backupDirForServer(serverId);
    const outputPath = path.join(targetDir, filename);
    const sourceDir = serverDir(serverId);

    if (!fs.existsSync(sourceDir)) {
      return reject(new Error('Server directory does not exist'));
    }

    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 6 } });

    output.on('close', () => {
      const sizeMb = Math.round((archive.pointer() / 1024 / 1024) * 100) / 100;
      db.prepare(
        'INSERT INTO backups (id, server_id, filename, size_mb, type) VALUES (?, ?, ?, ?, ?)'
      ).run(id, serverId, filename, sizeMb, type);
      log.info(`Backup created for server ${serverId}: ${filename} (${sizeMb} MB)`);
      resolve({ id, filename, sizeMb });
    });

    archive.on('error', err => reject(err));
    archive.on('warning', err => log.warn(`Archive warning: ${err.message}`));

    archive.pipe(output);
    archive.directory(sourceDir, false, entry => {
      if (entry.name.startsWith('backups' + path.sep)) return false;
      return entry;
    });
    archive.finalize();
  });
}

function listBackups(serverId) {
  return db
    .prepare('SELECT * FROM backups WHERE server_id = ? ORDER BY created_at DESC')
    .all(serverId);
}

function getBackup(backupId) {
  return db.prepare('SELECT * FROM backups WHERE id = ?').get(backupId);
}

function deleteBackup(backupId) {
  const backup = getBackup(backupId);
  if (!backup) return false;
  const filePath = path.join(backupDirForServer(backup.server_id), backup.filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  db.prepare('DELETE FROM backups WHERE id = ?').run(backupId);
  return true;
}

async function restoreBackup(backupId) {
  const backup = getBackup(backupId);
  if (!backup) throw new Error('Backup not found');
  const filePath = path.join(backupDirForServer(backup.server_id), backup.filename);
  if (!fs.existsSync(filePath)) throw new Error('Backup file missing on disk');

  const targetDir = serverDir(backup.server_id);
  // Clear existing world/server files before restore (keep directory itself).
  const entries = fs.readdirSync(targetDir);
  for (const entry of entries) {
    fs.rmSync(path.join(targetDir, entry), { recursive: true, force: true });
  }

  await fs
    .createReadStream(filePath)
    .pipe(unzipper.Extract({ path: targetDir }))
    .promise();

  log.info(`Backup ${backupId} restored to server ${backup.server_id}`);
  return true;
}

function createSchedule(serverId, intervalMinutes, keepCount) {
  const result = db
    .prepare(
      'INSERT INTO backup_schedules (server_id, cron_interval_minutes, keep_count) VALUES (?, ?, ?)'
    )
    .run(serverId, intervalMinutes, keepCount);
  return db.prepare('SELECT * FROM backup_schedules WHERE id = ?').get(result.lastInsertRowid);
}

function listSchedules(serverId) {
  return db.prepare('SELECT * FROM backup_schedules WHERE server_id = ?').all(serverId);
}

function deleteSchedule(scheduleId) {
  db.prepare('DELETE FROM backup_schedules WHERE id = ?').run(scheduleId);
}

function toggleSchedule(scheduleId, enabled) {
  db.prepare('UPDATE backup_schedules SET enabled = ? WHERE id = ?').run(enabled ? 1 : 0, scheduleId);
}

/**
 * Runs all due backup schedules. Intended to be called periodically
 * (see server.js scheduler interval). Enforces keep_count by pruning
 * the oldest scheduled backups per server.
 */
async function runDueSchedules() {
  const now = Math.floor(Date.now() / 1000);
  const due = db
    .prepare(
      `SELECT * FROM backup_schedules
       WHERE enabled = 1
       AND (last_run_at IS NULL OR (? - last_run_at) >= cron_interval_minutes * 60)`
    )
    .all(now);

  for (const schedule of due) {
    try {
      await createBackup(schedule.server_id, 'scheduled');
      db.prepare('UPDATE backup_schedules SET last_run_at = ? WHERE id = ?').run(now, schedule.id);

      const scheduledBackups = db
        .prepare(
          "SELECT * FROM backups WHERE server_id = ? AND type = 'scheduled' ORDER BY created_at DESC"
        )
        .all(schedule.server_id);

      if (scheduledBackups.length > schedule.keep_count) {
        const toRemove = scheduledBackups.slice(schedule.keep_count);
        for (const old of toRemove) deleteBackup(old.id);
      }
    } catch (err) {
      log.error(`Scheduled backup failed for server ${schedule.server_id}: ${err.message}`);
    }
  }
}

module.exports = {
  BACKUPS_DIR,
  backupDirForServer,
  createBackup,
  listBackups,
  getBackup,
  deleteBackup,
  restoreBackup,
  createSchedule,
  listSchedules,
  deleteSchedule,
  toggleSchedule,
  runDueSchedules
};

'use strict';

const path = require('path');
const fs = require('fs');
const db = require('../database/db');

const BACKGROUNDS_DIR = path.resolve(__dirname, '..', 'backgrounds');
if (!fs.existsSync(BACKGROUNDS_DIR)) fs.mkdirSync(BACKGROUNDS_DIR, { recursive: true });

function listBackgrounds() {
  return db.prepare('SELECT * FROM backgrounds ORDER BY created_at DESC').all();
}

function getActiveBackground() {
  return db.prepare('SELECT * FROM backgrounds WHERE active = 1 LIMIT 1').get();
}

function registerBackground({ filename, mimeType }) {
  const result = db
    .prepare('INSERT INTO backgrounds (filename, mime_type) VALUES (?, ?)')
    .run(filename, mimeType);
  return db.prepare('SELECT * FROM backgrounds WHERE id = ?').get(result.lastInsertRowid);
}

function setActiveBackground(id) {
  const tx = db.transaction(() => {
    db.prepare('UPDATE backgrounds SET active = 0').run();
    db.prepare('UPDATE backgrounds SET active = 1 WHERE id = ?').run(id);
  });
  tx();
  return db.prepare('SELECT * FROM backgrounds WHERE id = ?').get(id);
}

function updateBackgroundSettings(id, settings) {
  const allowed = ['loop', 'muted', 'overlay_opacity', 'blur_px', 'brightness_percent', 'opacity_percent'];
  const map = {
    loop: settings.loop === undefined ? undefined : (settings.loop ? 1 : 0),
    muted: settings.muted === undefined ? undefined : (settings.muted ? 1 : 0),
    overlay_opacity: settings.overlayOpacity,
    blur_px: settings.blurPx,
    brightness_percent: settings.brightnessPercent,
    opacity_percent: settings.opacityPercent
  };
  const sets = [];
  const values = [];
  for (const key of allowed) {
    if (map[key] !== undefined) {
      sets.push(`${key} = ?`);
      values.push(map[key]);
    }
  }
  if (sets.length === 0) return db.prepare('SELECT * FROM backgrounds WHERE id = ?').get(id);
  values.push(id);
  db.prepare(`UPDATE backgrounds SET ${sets.join(', ')} WHERE id = ?`).run(...values);
  return db.prepare('SELECT * FROM backgrounds WHERE id = ?').get(id);
}

function deleteBackground(id) {
  const bg = db.prepare('SELECT * FROM backgrounds WHERE id = ?').get(id);
  if (!bg) return false;
  const filePath = path.join(BACKGROUNDS_DIR, bg.filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  db.prepare('DELETE FROM backgrounds WHERE id = ?').run(id);
  return true;
}

module.exports = {
  BACKGROUNDS_DIR,
  listBackgrounds,
  getActiveBackground,
  registerBackground,
  setActiveBackground,
  updateBackgroundSettings,
  deleteBackground
};

'use strict';

const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');
const config = require('../config.json');
const { createLogger } = require('../utils/logger');
const audit = require('./audit.service');
const { getDirSizeMb } = require('../utils/systemStats');

const log = createLogger('server.service');

const SERVERS_DIR = path.resolve(__dirname, '..', 'servers');
if (!fs.existsSync(SERVERS_DIR)) fs.mkdirSync(SERVERS_DIR, { recursive: true });

/** In-memory registry of live child processes and console ring buffers. */
const runningProcesses = new Map(); // serverId -> { proc, stats: {tps, mspt, players}, consoleBuffer: [] }
const CONSOLE_BUFFER_LIMIT = 500;

let broadcastFn = null;
function setBroadcaster(fn) {
  broadcastFn = fn;
}

function broadcastConsole(serverId, line) {
  const entry = runningProcesses.get(serverId);
  if (entry) {
    entry.consoleBuffer.push({ line, ts: Date.now() });
    if (entry.consoleBuffer.length > CONSOLE_BUFFER_LIMIT) entry.consoleBuffer.shift();
  }
  if (broadcastFn) broadcastFn(serverId, 'console', { line });
}

function serverDir(serverId) {
  return path.join(SERVERS_DIR, serverId);
}

function nextAvailablePort() {
  const used = db.prepare('SELECT port FROM servers').all().map(r => r.port);
  let port = 25565;
  while (used.includes(port)) port++;
  return port;
}

function getServerById(id) {
  return db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
}

function listServersForUser(userId) {
  return db.prepare('SELECT * FROM servers WHERE owner_id = ? ORDER BY created_at DESC').all(userId);
}

function listAllServers() {
  return db
    .prepare(
      `SELECT s.*, u.username as owner_username FROM servers s
       JOIN users u ON u.id = s.owner_id ORDER BY s.created_at DESC`
    )
    .all();
}

function countServersForUser(userId) {
  return db.prepare('SELECT COUNT(*) as c FROM servers WHERE owner_id = ?').get(userId).c;
}

function writeEula(dir) {
  fs.writeFileSync(path.join(dir, 'eula.txt'), 'eula=true\n');
}

function writeServerProperties(dir, port) {
  const propsPath = path.join(dir, 'server.properties');
  const content = [
    `server-port=${port}`,
    'enable-query=true',
    'online-mode=true',
    'motd=A NX Panel Minecraft Server',
    'max-players=20',
    'view-distance=8',
    'simulation-distance=6',
    'spawn-protection=0',
    'enable-rcon=false'
  ].join('\n');
  fs.writeFileSync(propsPath, content + '\n');
}

/**
 * Creates a server record and provisions its directory. Actual jar
 * download is attempted asynchronously; failures leave the server in
 * 'offline' state with an activity log entry so the owner can retry
 * by re-uploading a jar manually via the file manager.
 */
async function createServer({ ownerId, name, software, mcVersion, ramMb, cpuPercent, diskMb, javaVersion }) {
  const id = uuidv4();
  const port = nextAvailablePort();
  const dir = serverDir(id);
  fs.mkdirSync(dir, { recursive: true });
  writeEula(dir);
  writeServerProperties(dir, port);

  db.prepare(
    `INSERT INTO servers (id, owner_id, name, software, mc_version, java_version, ram_mb, cpu_percent, disk_mb, port, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'offline')`
  ).run(id, ownerId, name, software, mcVersion || 'latest', javaVersion || '21', ramMb, cpuPercent, diskMb, port);

  audit.activity(ownerId, id, `Created server "${name}" (${software})`);
  log.info(`Server created: ${id} (${name}) for user ${ownerId}`);

  return getServerById(id);
}

function updateServerMeta(id, fields) {
  const allowed = ['name', 'ram_mb', 'cpu_percent', 'disk_mb', 'software', 'mc_version', 'java_version', 'auto_start'];
  const sets = [];
  const values = [];
  for (const key of allowed) {
    if (fields[key] !== undefined) {
      sets.push(`${key} = ?`);
      values.push(fields[key]);
    }
  }
  if (sets.length === 0) return getServerById(id);
  sets.push("updated_at = strftime('%s','now')");
  values.push(id);
  db.prepare(`UPDATE servers SET ${sets.join(', ')} WHERE id = ?`).run(...values);
  return getServerById(id);
}

function deleteServer(id) {
  const server = getServerById(id);
  if (!server) return false;
  if (runningProcesses.has(id)) {
    stopServer(id, true);
  }
  const dir = serverDir(id);
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
  db.prepare('DELETE FROM servers WHERE id = ?').run(id);
  audit.activity(server.owner_id, id, `Deleted server "${server.name}"`);
  return true;
}

function findServerJar(dir) {
  if (!fs.existsSync(dir)) return null;
  const files = fs.readdirSync(dir);
  const jar = files.find(f => f.toLowerCase().endsWith('.jar') && !f.toLowerCase().includes('installer'));
  return jar ? path.join(dir, jar) : null;
}

function startServer(id) {
  const server = getServerById(id);
  if (!server) throw new Error('Server not found');
  if (server.suspended) throw new Error('Server is suspended');
  if (runningProcesses.has(id)) throw new Error('Server is already running');

  const dir = serverDir(id);
  const jarPath = findServerJar(dir);
  if (!jarPath) {
    throw new Error('No server jar found. Please upload a server jar via the File Manager first.');
  }

  const javaArgs = [
    `-Xms${Math.min(1024, server.ram_mb)}M`,
    `-Xmx${server.ram_mb}M`,
    '-XX:+UseG1GC',
    '-XX:+ParallelRefProcEnabled',
    '-XX:MaxGCPauseMillis=200',
    '-XX:+UnlockExperimentalVMOptions',
    '-XX:+DisableExplicitGC',
    '-jar',
    path.basename(jarPath),
    'nogui'
  ];

  db.prepare("UPDATE servers SET status = 'starting' WHERE id = ?").run(id);
  if (broadcastFn) broadcastFn(id, 'status', { status: 'starting' });

  const proc = spawn(config.java.binary, javaArgs, {
    cwd: dir,
    stdio: ['pipe', 'pipe', 'pipe']
  });

  const entry = {
    proc,
    stats: { tps: 20.0, mspt: 0, players: 0, maxPlayers: 20 },
    consoleBuffer: []
  };
  runningProcesses.set(id, entry);

  db.prepare("UPDATE servers SET status = 'online', pid = ? WHERE id = ?").run(proc.pid, id);

  proc.stdout.on('data', chunk => {
    const text = chunk.toString('utf8');
    text.split(/\r?\n/).forEach(line => {
      if (!line.trim()) return;
      broadcastConsole(id, line);
      parseConsoleLineForStats(id, line);
      if (/Done \(/i.test(line) || /For help, type/i.test(line)) {
        db.prepare("UPDATE servers SET status = 'online' WHERE id = ?").run(id);
        if (broadcastFn) broadcastFn(id, 'status', { status: 'online' });
      }
    });
  });

  proc.stderr.on('data', chunk => {
    const text = chunk.toString('utf8');
    text.split(/\r?\n/).forEach(line => {
      if (line.trim()) broadcastConsole(id, `[STDERR] ${line}`);
    });
  });

  proc.on('exit', code => {
    runningProcesses.delete(id);
    const finalStatus = code === 0 ? 'offline' : 'crashed';
    db.prepare('UPDATE servers SET status = ?, pid = NULL WHERE id = ?').run(finalStatus, id);
    if (broadcastFn) broadcastFn(id, 'status', { status: finalStatus });
    broadcastConsole(id, `[NX Panel] Process exited with code ${code}`);
    log.info(`Server ${id} process exited with code ${code}`);
  });

  proc.on('error', err => {
    log.error(`Server ${id} failed to start: ${err.message}`);
    db.prepare("UPDATE servers SET status = 'crashed', pid = NULL WHERE id = ?").run(id);
    runningProcesses.delete(id);
    if (broadcastFn) broadcastFn(id, 'status', { status: 'crashed' });
  });

  audit.activity(server.owner_id, id, `Started server "${server.name}"`);
  return true;
}

function parseConsoleLineForStats(id, line) {
  const entry = runningProcesses.get(id);
  if (!entry) return;
  const joinMatch = line.match(/\[Server thread\/INFO\]:\s(\S+)\sjoined the game/);
  const leaveMatch = line.match(/\[Server thread\/INFO\]:\s(\S+)\sleft the game/);
  if (joinMatch) entry.stats.players = Math.min(entry.stats.maxPlayers, entry.stats.players + 1);
  if (leaveMatch) entry.stats.players = Math.max(0, entry.stats.players - 1);
}

function stopServer(id, force = false) {
  const entry = runningProcesses.get(id);
  if (!entry) throw new Error('Server is not running');
  db.prepare("UPDATE servers SET status = 'stopping' WHERE id = ?").run(id);
  if (broadcastFn) broadcastFn(id, 'status', { status: 'stopping' });

  if (force) {
    entry.proc.kill('SIGKILL');
  } else {
    try {
      entry.proc.stdin.write('stop\n');
    } catch (err) {
      entry.proc.kill('SIGTERM');
    }
    setTimeout(() => {
      if (runningProcesses.has(id)) {
        entry.proc.kill('SIGKILL');
      }
    }, 30000);
  }
  const server = getServerById(id);
  if (server) audit.activity(server.owner_id, id, `${force ? 'Killed' : 'Stopped'} server "${server.name}"`);
  return true;
}

function restartServer(id) {
  const entry = runningProcesses.get(id);
  if (!entry) {
    return startServer(id);
  }
  const onExit = () => {
    setTimeout(() => {
      try {
        startServer(id);
      } catch (err) {
        log.error(`Failed to restart server ${id}: ${err.message}`);
      }
    }, 1500);
  };
  entry.proc.once('exit', onExit);
  stopServer(id, false);
  return true;
}

function sendCommand(id, command) {
  const entry = runningProcesses.get(id);
  if (!entry) throw new Error('Server is not running');
  entry.proc.stdin.write(command.trim() + '\n');
  broadcastConsole(id, `> ${command.trim()}`);
}

function getConsoleBuffer(id) {
  const entry = runningProcesses.get(id);
  return entry ? entry.consoleBuffer : [];
}

function getLiveStats(id) {
  const entry = runningProcesses.get(id);
  const server = getServerById(id);
  if (!entry || !server) {
    return { online: false, tps: 0, mspt: 0, players: 0, maxPlayers: 20, diskMb: getDirSizeMb(serverDir(id)) };
  }
  return {
    online: true,
    tps: entry.stats.tps,
    mspt: entry.stats.mspt,
    players: entry.stats.players,
    maxPlayers: entry.stats.maxPlayers,
    diskMb: getDirSizeMb(serverDir(id))
  };
}

function isRunning(id) {
  return runningProcesses.has(id);
}

function suspendServer(id, suspended) {
  if (suspended && runningProcesses.has(id)) {
    stopServer(id, true);
  }
  db.prepare('UPDATE servers SET suspended = ? WHERE id = ?').run(suspended ? 1 : 0, id);
}

module.exports = {
  SERVERS_DIR,
  serverDir,
  createServer,
  getServerById,
  listServersForUser,
  listAllServers,
  countServersForUser,
  updateServerMeta,
  deleteServer,
  startServer,
  stopServer,
  restartServer,
  sendCommand,
  getConsoleBuffer,
  getLiveStats,
  isRunning,
  suspendServer,
  setBroadcaster,
  findServerJar
};

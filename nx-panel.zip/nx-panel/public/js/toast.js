'use strict';

const NXToast = (() => {
  let container = null;

  function ensureContainer() {
    if (!container) {
      container = document.getElementById('nx-toast-container');
      if (!container) {
        container = document.createElement('div');
        container.id = 'nx-toast-container';
        document.body.appendChild(container);
      }
    }
    return container;
  }

  function show(title, message, type = 'info', duration = 4500) {
    const el = ensureContainer();
    const toast = document.createElement('div');
    toast.className = `nx-toast ${type}`;
    toast.innerHTML = `
      <div class="nx-toast-title">${escapeHtml(title)}</div>
      ${message ? `<div class="nx-toast-msg">${escapeHtml(message)}</div>` : ''}
    `;
    el.appendChild(toast);
    setTimeout(() => {
      toast.style.transition = 'opacity 200ms ease, transform 200ms ease';
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      setTimeout(() => toast.remove(), 220);
    }, duration);
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
  }

  return {
    success: (title, msg) => show(title, msg, 'success'),
    error: (title, msg) => show(title, msg, 'error'),
    warning: (title, msg) => show(title, msg, 'warning'),
    info: (title, msg) => show(title, msg, 'info')
  };
})();

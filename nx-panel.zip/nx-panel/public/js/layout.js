'use strict';

const NXLayout = (() => {
  let currentUser = null;

  const NAV_USER = [
    { section: 'Overview' },
    { href: '/dashboard.html', icon: 'grid', label: 'Dashboard', match: 'dashboard' },
    { href: '/servers.html', icon: 'server', label: 'My Servers', match: 'servers' },
    { section: 'Economy' },
    { href: '/coins.html', icon: 'coin', label: 'Coins & Shop', match: 'coins' },
    { href: '/leaderboard.html', icon: 'trophy', label: 'Leaderboard', match: 'leaderboard' },
    { section: 'Account' },
    { href: '/settings.html', icon: 'settings', label: 'Settings', match: 'settings' }
  ];

  const NAV_ADMIN_EXTRA = [
    { section: 'Administration' },
    { href: '/admin.html', icon: 'shield', label: 'Admin Overview', match: 'admin' },
    { href: '/admin-users.html', icon: 'users', label: 'Users', match: 'admin-users' },
    { href: '/admin-servers.html', icon: 'stack', label: 'All Servers', match: 'admin-servers' },
    { href: '/admin-coins.html', icon: 'coin', label: 'Coin Manager', match: 'admin-coins' },
    { href: '/admin-ads.html', icon: 'megaphone', label: 'Ad Manager', match: 'admin-ads' },
    { href: '/admin-background.html', icon: 'film', label: 'Background Manager', match: 'admin-background' },
    { href: '/admin-settings.html', icon: 'sliders', label: 'Panel Settings', match: 'admin-settings' },
    { href: '/admin-logs.html', icon: 'file-text', label: 'Logs', match: 'admin-logs' }
  ];

  const ICONS = {
    grid: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
    server: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="13" width="18" height="7" rx="1.5"/><circle cx="7" cy="7.5" r="1"/><circle cx="7" cy="16.5" r="1"/></svg>',
    coin: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M9 12h6M12 9v6"/></svg>',
    trophy: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 4h12v4a6 6 0 0 1-12 0V4z"/><path d="M6 6H3a3 3 0 0 0 3 5M18 6h3a3 3 0 0 1-3 5"/><path d="M9 20h6M12 15v5"/></svg>',
    settings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c.66.25 1.13.9 1.13 1.65"/></svg>',
    shield: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
    users: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    stack: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
    megaphone: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 11v3a1 1 0 0 0 1 1h2l4 5v-15l-4 5H4a1 1 0 0 0-1 1z"/><path d="M17 8a5 5 0 0 1 0 8M21 5a10 10 0 0 1 0 14"/></svg>',
    film: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M7 4v16M17 4v16M2 9h5M17 9h5M2 15h5M17 15h5"/></svg>',
    sliders: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/></svg>',
    'file-text': '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/></svg>'
  };

  function buildNavHtml(activeMatch, isAdmin) {
    const items = isAdmin ? [...NAV_USER, ...NAV_ADMIN_EXTRA] : NAV_USER;
    return items
      .map(item => {
        if (item.section) {
          return `<div class="nx-nav-section-label">${item.section}</div>`;
        }
        const active = item.match === activeMatch ? 'active' : '';
        return `<a class="nx-nav-item ${active}" href="${item.href}">
          <span class="nx-nav-icon">${ICONS[item.icon] || ''}</span>
          <span>${item.label}</span>
        </a>`;
      })
      .join('');
  }

  async function init(activeMatch, options) {
    const opts = options || {};
    const requireAdmin = !!opts.requireAdmin;

    try {
      const data = await NXApi.get('/auth/me');
      currentUser = data.user;
    } catch (err) {
      window.location.href = '/login.html';
      return null;
    }

    if (requireAdmin && currentUser.role !== 'admin') {
      window.location.href = '/dashboard.html';
      return null;
    }

    renderShell(activeMatch);
    NXSocket.connect();

    try {
      const status = await NXApi.get('/status');
      if (status.background) NXUi.applyBackground(status.background);
      if (status.maintenanceMode && currentUser.role !== 'admin') {
        NXToast.warning('Maintenance Mode', status.maintenanceMessage || 'The panel is under maintenance.');
      }
    } catch (err) {
      /* non-fatal */
    }

    NXSocket.on('global', 'background_changed', data => {
      if (data && data.background) NXUi.applyBackground(data.background);
    });
    NXSocket.on('global', 'background_settings_changed', data => {
      if (data && data.background) NXUi.applyBackground(data.background);
    });
    NXSocket.on('global', 'broadcast', data => {
      NXToast.info(data.title, data.message);
    });
    NXSocket.on('global', 'notification', data => {
      if (!data.userId || data.userId === currentUser.id) {
        NXToast.info(data.title, data.message);
      }
    });
    NXSocket.on('auth', 'ready', () => {
      NXSocket.subscribeGlobal();
    });

    return currentUser;
  }

  function renderShell(activeMatch) {
    const root = document.getElementById('nx-app-root');
    if (!root) return;

    const initials = currentUser.username.slice(0, 2).toUpperCase();

    root.innerHTML = `
      <div id="nx-bg-video-wrap"></div>
      <div id="nx-bg-overlay"></div>
      <div id="nx-toast-container"></div>
      <div class="nx-app">
        <aside class="nx-sidebar" id="nx-sidebar">
          <div class="nx-brand">
            <div class="nx-brand-logo">NX</div>
            <div class="nx-brand-name">NX Panel</div>
          </div>
          <nav class="nx-nav">
            ${buildNavHtml(activeMatch, currentUser.role === 'admin')}
          </nav>
          <div class="nx-sidebar-footer">
            <div class="nx-user-chip">
              <div class="nx-avatar">${NXUi.escapeHtml(initials)}</div>
              <div class="nx-user-meta">
                <div class="nx-user-name">${NXUi.escapeHtml(currentUser.username)}</div>
                <div class="nx-user-role">${NXUi.escapeHtml(currentUser.role)}</div>
              </div>
            </div>
            <button class="nx-btn nx-btn-block" id="nx-logout-btn">Log Out</button>
          </div>
        </aside>
        <main class="nx-main">
          <div class="nx-topbar">
            <div class="nx-flex nx-items-center nx-gap-12">
              <button class="nx-mobile-toggle" id="nx-mobile-toggle">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
              </button>
              <div>
                <div class="nx-page-title" id="nx-page-title">NX Panel</div>
                <div class="nx-page-subtitle" id="nx-page-subtitle"></div>
              </div>
            </div>
            <div class="nx-topbar-actions" id="nx-topbar-actions"></div>
          </div>
          <div id="nx-page-content"></div>
        </main>
      </div>
    `;

    document.getElementById('nx-logout-btn').addEventListener('click', async () => {
      try {
        await NXApi.post('/auth/logout', {});
      } catch (err) {
        /* ignore */
      }
      NXApi.setAccessToken(null);
      window.location.href = '/login.html';
    });

    const toggle = document.getElementById('nx-mobile-toggle');
    const sidebar = document.getElementById('nx-sidebar');
    if (toggle && sidebar) {
      toggle.addEventListener('click', () => sidebar.classList.toggle('open'));
    }
  }

  function setPageTitle(title, subtitle) {
    const t = document.getElementById('nx-page-title');
    const s = document.getElementById('nx-page-subtitle');
    if (t) t.textContent = title;
    if (s) s.textContent = subtitle || '';
  }

  function setTopbarActions(html) {
    const el = document.getElementById('nx-topbar-actions');
    if (el) el.innerHTML = html;
  }

  function getUser() {
    return currentUser;
  }

  return { init, setPageTitle, setTopbarActions, getUser };
})();

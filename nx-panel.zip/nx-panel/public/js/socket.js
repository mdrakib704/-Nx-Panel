'use strict';

const NXSocket = (() => {
  let socket = null;
  let authenticated = false;
  const listeners = new Map(); // key: `${channel}:${event}` -> Set<fn>
  const pendingSubscriptions = [];
  let reconnectAttempts = 0;
  let reconnectTimer = null;

  function key(channel, event) {
    return `${channel}:${event}`;
  }

  function on(channel, event, fn) {
    const k = key(channel, event);
    if (!listeners.has(k)) listeners.set(k, new Set());
    listeners.get(k).add(fn);
    return () => listeners.get(k).delete(fn);
  }

  function emit(channel, event, data, serverId) {
    const k = key(channel, event);
    const set = listeners.get(k);
    if (set) {
      for (const fn of set) fn(data, serverId);
    }
    const wildcardSet = listeners.get(key(channel, '*'));
    if (wildcardSet) {
      for (const fn of wildcardSet) fn({ event, data }, serverId);
    }
  }

  function send(payload) {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(payload));
    } else {
      pendingSubscriptions.push(payload);
    }
  }

  function connect() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    socket = new WebSocket(`${protocol}//${window.location.host}/ws`);

    socket.addEventListener('open', () => {
      reconnectAttempts = 0;
      const token = NXApi.getAccessToken();
      if (token) {
        socket.send(JSON.stringify({ type: 'auth', token }));
      }
    });

    socket.addEventListener('message', evt => {
      let msg;
      try {
        msg = JSON.parse(evt.data);
      } catch (err) {
        return;
      }
      if (msg.channel === 'auth' && msg.event === 'success') {
        authenticated = true;
        for (const p of pendingSubscriptions.splice(0)) {
          socket.send(JSON.stringify(p));
        }
        emit('auth', 'ready', {});
        return;
      }
      emit(msg.channel, msg.event, msg.data, msg.serverId);
    });

    socket.addEventListener('close', () => {
      authenticated = false;
      reconnectAttempts++;
      const delay = Math.min(15000, 1000 * reconnectAttempts);
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(connect, delay);
    });

    socket.addEventListener('error', () => {
      if (socket) socket.close();
    });
  }

  function subscribeServer(serverId) {
    send({ type: 'subscribe_server', serverId });
  }

  function unsubscribeServer(serverId) {
    send({ type: 'unsubscribe_server', serverId });
  }

  function subscribeGlobal() {
    send({ type: 'subscribe_global' });
  }

  function sendCommand(serverId, command) {
    send({ type: 'console_command', serverId, command });
  }

  return {
    connect,
    on,
    subscribeServer,
    unsubscribeServer,
    subscribeGlobal,
    sendCommand,
    isAuthenticated: () => authenticated
  };
})();

'use strict';

/**
 * NX Panel API client. Handles JWT access token storage in memory +
 * localStorage, automatic refresh on 401, and JSON request helpers.
 */
const NXApi = (() => {
  const BASE = '/api/v1';
  let accessToken = localStorage.getItem('nx_access_token') || null;
  let refreshingPromise = null;

  function setAccessToken(token) {
    accessToken = token;
    if (token) {
      localStorage.setItem('nx_access_token', token);
    } else {
      localStorage.removeItem('nx_access_token');
    }
  }

  function getAccessToken() {
    return accessToken;
  }

  async function doRefresh() {
    if (refreshingPromise) return refreshingPromise;
    refreshingPromise = fetch(`${BASE}/auth/refresh`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    })
      .then(async res => {
        const json = await res.json();
        if (res.ok && json.data && json.data.accessToken) {
          setAccessToken(json.data.accessToken);
          return json.data.accessToken;
        }
        setAccessToken(null);
        return null;
      })
      .catch(() => {
        setAccessToken(null);
        return null;
      })
      .finally(() => {
        refreshingPromise = null;
      });
    return refreshingPromise;
  }

  async function request(method, path, body, opts = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`;

    const fetchOpts = {
      method,
      headers,
      credentials: 'include'
    };
    if (body !== undefined && body !== null) {
      fetchOpts.body = JSON.stringify(body);
    }

    let res = await fetch(`${BASE}${path}`, fetchOpts);

    if (res.status === 401 && !opts.noRetry) {
      const newToken = await doRefresh();
      if (newToken) {
        headers['Authorization'] = `Bearer ${newToken}`;
        res = await fetch(`${BASE}${path}`, { ...fetchOpts, headers });
      }
    }

    let json;
    try {
      json = await res.json();
    } catch (err) {
      json = { success: false, message: 'Unexpected server response' };
    }

    if (!res.ok || json.success === false) {
      const err = new Error(json.message || `Request failed (${res.status})`);
      err.status = res.status;
      err.errors = json.errors;
      throw err;
    }
    return json.data;
  }

  async function upload(path, formData) {
    const headers = {};
    if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`;
    let res = await fetch(`${BASE}${path}`, {
      method: 'POST',
      headers,
      body: formData,
      credentials: 'include'
    });

    if (res.status === 401) {
      const newToken = await doRefresh();
      if (newToken) {
        headers['Authorization'] = `Bearer ${newToken}`;
        res = await fetch(`${BASE}${path}`, { method: 'POST', headers, body: formData, credentials: 'include' });
      }
    }

    const json = await res.json();
    if (!res.ok || json.success === false) {
      throw new Error(json.message || 'Upload failed');
    }
    return json.data;
  }

  return {
    get: (path, opts) => request('GET', path, null, opts),
    post: (path, body, opts) => request('POST', path, body || {}, opts),
    put: (path, body, opts) => request('PUT', path, body || {}, opts),
    patch: (path, body, opts) => request('PATCH', path, body || {}, opts),
    delete: (path, opts) => request('DELETE', path, null, opts),
    upload,
    setAccessToken,
    getAccessToken,
    doRefresh
  };
})();

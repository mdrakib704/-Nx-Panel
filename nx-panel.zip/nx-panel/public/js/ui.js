'use strict';

const NXUi = (() => {
  function formatBytes(mb) {
    if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
    return `${Math.round(mb)} MB`;
  }

  function formatUptime(seconds) {
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (d > 0) return `${d}d ${h}h`;
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m`;
  }

  function timeAgo(unixSeconds) {
    const diff = Math.floor(Date.now() / 1000) - unixSeconds;
    if (diff < 60) return 'just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = String(str === undefined || str === null ? '' : str);
    return div.innerHTML;
  }

  function statusBadge(status) {
    const labels = {
      online: 'Online', offline: 'Offline', starting: 'Starting',
      stopping: 'Stopping', installing: 'Installing', crashed: 'Crashed',
      suspended: 'Suspended'
    };
    const cls = status || 'offline';
    return `<span class="nx-badge ${cls}"><span class="nx-badge-dot"></span>${labels[cls] || cls}</span>`;
  }

  function openModal({ title, bodyHtml, footerHtml, onClose }) {
    const backdrop = document.createElement('div');
    backdrop.className = 'nx-modal-backdrop';
    backdrop.innerHTML = `
      <div class="nx-modal">
        <div class="nx-modal-header">
          <div class="nx-modal-title">${escapeHtml(title)}</div>
          <button class="nx-modal-close" aria-label="Close">&times;</button>
        </div>
        <div class="nx-modal-body">${bodyHtml}</div>
        ${footerHtml ? `<div class="nx-modal-footer">${footerHtml}</div>` : ''}
      </div>
    `;
    document.body.appendChild(backdrop);

    function close() {
      backdrop.remove();
      if (onClose) onClose();
    }

    backdrop.addEventListener('click', e => {
      if (e.target === backdrop) close();
    });
    backdrop.querySelector('.nx-modal-close').addEventListener('click', close);

    return { el: backdrop, close };
  }

  function confirmAction(message) {
    return new Promise(resolve => {
      const { close } = openModal({
        title: 'Please Confirm',
        bodyHtml: `<p style="color:var(--nx-text-dim);font-size:14px;">${escapeHtml(message)}</p>`,
        footerHtml: `
          <button class="nx-btn" id="nx-confirm-cancel">Cancel</button>
          <button class="nx-btn nx-btn-danger" id="nx-confirm-ok">Confirm</button>
        `
      });
      document.getElementById('nx-confirm-cancel').addEventListener('click', () => {
        close();
        resolve(false);
      });
      document.getElementById('nx-confirm-ok').addEventListener('click', () => {
        close();
        resolve(true);
      });
    });
  }

  function applyBackground(background) {
    const wrap = document.getElementById('nx-bg-video-wrap');
    const overlay = document.getElementById('nx-bg-overlay');
    if (!wrap || !overlay) return;

    let video = document.getElementById('nx-bg-video');
    if (!background) {
      if (video) video.remove();
      overlay.style.background = 'rgba(10,11,15,0.4)';
      return;
    }

    if (!video) {
      video = document.createElement('video');
      video.id = 'nx-bg-video';
      video.autoplay = true;
      video.playsInline = true;
      wrap.appendChild(video);
    }

    const src = `/backgrounds/${background.filename}`;
    if (video.dataset.src !== src) {
      video.dataset.src = src;
      video.src = src;
    }
    video.loop = !!background.loop;
    video.muted = background.muted === undefined ? true : !!background.muted;
    video.style.filter = `brightness(${background.brightness_percent || 100}%)`;
    video.style.opacity = (background.opacity_percent !== undefined ? background.opacity_percent : 100) / 100;

    overlay.style.background = `rgba(10,11,15,${background.overlay_opacity !== undefined ? background.overlay_opacity : 0.4})`;
    overlay.style.backdropFilter = `blur(${background.blur_px || 0}px)`;

    video.play().catch(() => {
      // Autoplay might be blocked until user interaction; muted videos generally succeed.
    });
  }

  return { formatBytes, formatUptime, timeAgo, escapeHtml, statusBadge, openModal, confirmAction, applyBackground };
})();

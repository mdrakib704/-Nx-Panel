'use strict';

const db = require('../../database/db');
const coinService = require('../../services/coinService');
const { audit } = require('../../utils/audit');

async function coinRoutes(fastify) {
  fastify.addHook('onRequest', fastify.authenticate);

  fastify.get('/api/v1/coins/balance', async (request) => {
    const user = db
      .prepare('SELECT coins FROM users WHERE id = ?')
      .get(request.user.id);
    return { coins: user.coins };
  });

  fastify.post('/api/v1/coins/daily', async (request, reply) => {
    try {
      const amount = coinService.claimDailyReward(request.user.id);
      return { message: `You claimed ${amount} coins!`, amount };
    } catch (err) {
      const body = { error: err.message };
      if (err.remainingSeconds) body.remainingSeconds = err.remainingSeconds;
      return reply.code(429).send(body);
    }
  });

  fastify.post('/api/v1/coins/promo', async (request, reply) => {
    const { code } = request.body || {};
    if (!code || typeof code !== 'string') {
      return reply.code(400).send({ error: 'Promo code is required.' });
    }
    try {
      const amount = coinService.redeemPromo(request.user.id, code.trim().toUpperCase());
      return { message: `Redeemed ${amount} coins!`, amount };
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.get('/api/v1/coins/leaderboard', async () => {
    return coinService.getLeaderboard(10);
  });

  fastify.get('/api/v1/coins/history', async (request) => {
    return coinService.getTransactionHistory(request.user.id, 50);
  });

  fastify.get('/api/v1/shop', async () => {
    return db.prepare('SELECT * FROM shop_items WHERE enabled = 1').all();
  });

  fastify.post('/api/v1/shop/buy', async (request, reply) => {
    const { itemId, serverId } = request.body || {};
    if (!itemId) return reply.code(400).send({ error: 'itemId is required.' });
    try {
      await coinService.purchaseShopItem(request.user.id, itemId, serverId);
      audit(request.user.id, 'shop_purchase', { itemId, serverId }, request.ip);
      return { message: 'Purchase successful!' };
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.post('/api/v1/ads/reward', async (request, reply) => {
    const { adId } = request.body || {};
    if (!adId) return reply.code(400).send({ error: 'adId is required.' });

    const ad = db
      .prepare('SELECT * FROM ads WHERE id = ? AND enabled = 1 AND coin_reward > 0')
      .get(adId);
    if (!ad) return reply.code(404).send({ error: 'Ad not found.' });

    db.prepare('UPDATE ads SET impressions = impressions + 1 WHERE id = ?').run(adId);
    coinService.addCoins(request.user.id, ad.coin_reward, 'ad_reward', `Watched ad: ${ad.title}`);
    return { message: `You earned ${ad.coin_reward} coins!`, amount: ad.coin_reward };
  });
}

module.exports = coinRoutes;

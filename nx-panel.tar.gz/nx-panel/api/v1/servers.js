'use strict';

const crypto = require('crypto');
const db = require('../../database/db');
const config = require('../../config.json');
const processManager = require('../../services/processManager');
const backupService = require('../../services/backupService');
const { isValidServerName } = require('../../utils/validate');
const { audit } = require('../../utils/audit');

const ALLOWED_SOFTWARE = ['paper', 'purpur', 'fabric', 'forge', 'vanilla'];

function nextAvailablePort() {
  const used = db.prepare('SELECT port FROM servers').all().map((r) => r.port);
  let port = 25565;
  while (used.includes(port)) port += 1;
  return port;
}

async function serverRoutes(fastify) {
  fastify.addHook('onRequest', fastify.authenticate);

  // List servers owned by the current user (admins see all via /admin/servers)
  fastify.get('/api/v1/servers', async (request) => {
    const rows = db
      .prepare('SELECT * FROM servers WHERE owner_id = ? ORDER BY created_at DESC')
      .all(request.user.id);
    return rows.map((s) => ({ ...s, stats: processManager.getStats(s.uuid) }));
  });

  fastify.get('/api/v1/servers/:id', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });
    return { ...server, stats: processManager.getStats(server.uuid) };
  });

  fastify.post('/api/v1/servers', async (request, reply) => {
    const { name, software, version } = request.body || {};
    if (!isValidServerName(name)) {
      return reply.code(400).send({ error: 'Invalid server name (3-32 chars, letters/numbers/spaces/-/_).' });
    }
    if (!ALLOWED_SOFTWARE.includes(software)) {
      return reply.code(400).send({ error: 'Unsupported server software.' });
    }

    const owned = db
      .prepare('SELECT COUNT(*) AS c FROM servers WHERE owner_id = ?')
      .get(request.user.id).c;

    if (request.user.role !== 'admin' && owned >= request.user.server_slots) {
      return reply.code(403).send({
        error: `You have reached your server slot limit (${request.user.server_slots}). Purchase more slots in the Shop.`
      });
    }

    const uuid = crypto.randomUUID();
    const port = nextAvailablePort();
    const defaults = config.freeServerDefaults;

    const result = db
      .prepare(
        `INSERT INTO servers (uuid, owner_id, name, software, version, java_version, ram_mb, cpu_percent, disk_mb, port)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        uuid,
        request.user.id,
        name,
        software,
        version || 'latest',
        config.javaVersions[software] || 'java17',
        defaults.ramMb,
        defaults.cpuPercent,
        defaults.diskMb,
        port
      );

    processManager.ensureServerDir(uuid);
    audit(request.user.id, 'server_create', { name, software }, request.ip);

    return reply.code(201).send({ id: result.lastInsertRowid, uuid, port });
  });

  fastify.patch('/api/v1/servers/:id', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const { name } = request.body || {};
    if (name && !isValidServerName(name)) {
      return reply.code(400).send({ error: 'Invalid server name.' });
    }
    if (name) {
      db.prepare('UPDATE servers SET name = ? WHERE id = ?').run(name, server.id);
    }
    return { message: 'Server updated.' };
  });

  fastify.delete('/api/v1/servers/:id', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    if (processManager.isRunning(server.uuid)) {
      return reply.code(409).send({ error: 'Stop the server before deleting it.' });
    }

    db.prepare('DELETE FROM servers WHERE id = ?').run(server.id);
    audit(request.user.id, 'server_delete', { name: server.name }, request.ip);
    return { message: 'Server deleted.' };
  });

  fastify.post('/api/v1/servers/:id/start', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });
    if (server.suspended) return reply.code(403).send({ error: 'Server is suspended.' });

    try {
      processManager.start(server);
      db.prepare("UPDATE servers SET status = 'starting' WHERE id = ?").run(server.id);
      audit(request.user.id, 'server_start', { name: server.name }, request.ip);
      return { message: 'Server starting.' };
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.post('/api/v1/servers/:id/stop', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    try {
      processManager.stop(server.uuid, false);
      db.prepare("UPDATE servers SET status = 'stopping' WHERE id = ?").run(server.id);
      audit(request.user.id, 'server_stop', { name: server.name }, request.ip);
      return { message: 'Server stopping.' };
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.post('/api/v1/servers/:id/kill', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    try {
      processManager.stop(server.uuid, true);
      db.prepare("UPDATE servers SET status = 'stopped' WHERE id = ?").run(server.id);
      audit(request.user.id, 'server_kill', { name: server.name }, request.ip);
      return { message: 'Server killed.' };
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.post('/api/v1/servers/:id/restart', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    processManager.restart(server);
    audit(request.user.id, 'server_restart', { name: server.name }, request.ip);
    return { message: 'Server restarting.' };
  });

  fastify.post('/api/v1/servers/:id/command', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const { command } = request.body || {};
    if (!command || typeof command !== 'string' || command.length > 256) {
      return reply.code(400).send({ error: 'Invalid command.' });
    }

    try {
      processManager.sendCommand(server.uuid, command);
      return { message: 'Command sent.' };
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.get('/api/v1/servers/:id/console', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });
    return { logs: processManager.getRecentLogs(server.uuid) };
  });

  // Backups
  fastify.get('/api/v1/servers/:id/backups', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });
    return backupService.listBackups(server.id);
  });

  fastify.post('/api/v1/servers/:id/backups', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    try {
      const result = await backupService.createBackup(server);
      audit(request.user.id, 'backup_create', { server: server.name }, request.ip);
      return reply.code(201).send(result);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.delete('/api/v1/servers/:id/backups/:backupId', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    try {
      backupService.deleteBackup(request.params.backupId, server.uuid);
      return { message: 'Backup deleted.' };
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
  });

  fastify.get('/api/v1/servers/:id/backups/:backupId/download', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const backup = db
      .prepare('SELECT * FROM backups WHERE id = ? AND server_id = ?')
      .get(request.params.backupId, server.id);
    if (!backup) return reply.code(404).send({ error: 'Backup not found.' });

    const filePath = backupService.getBackupPath(server.uuid, backup.filename);
    return reply.type('application/gzip').send(require('fs').createReadStream(filePath));
  });

  // Backup schedules
  fastify.post('/api/v1/servers/:id/backup-schedule', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const { cronExpr } = request.body || {};
    if (!cronExpr || typeof cronExpr !== 'string') {
      return reply.code(400).send({ error: 'A valid cron expression is required.' });
    }

    db.prepare(
      'INSERT INTO backup_schedules (server_id, cron_expr) VALUES (?, ?)'
    ).run(server.id, cronExpr);

    return reply.code(201).send({ message: 'Backup schedule created.' });
  });
}

module.exports = serverRoutes;

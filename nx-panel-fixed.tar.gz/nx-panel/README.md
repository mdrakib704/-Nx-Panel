# ⬡ NX Panel

**Lightweight Minecraft Server Hosting Panel** built with Fastify, SQLite, and Vanilla JS.

Optimised for a VPS with as little as **2 GB RAM**. The panel itself idles at under 80 MB.

---

## ✨ Features

| Category | Features |
|---|---|
| **Dashboard** | Live CPU / RAM / Disk / Uptime · Animated glass cards · Server status |
| **Servers** | Create · Start · Stop · Restart · Kill · Rename · Delete |
| **Console** | Live WebSocket console · Send commands · Coloured log output |
| **File Manager** | Browse · Upload · Download · Edit · Rename · Delete · ZIP · Mkdir |
| **Backups** | Manual & scheduled backups · Download · Delete |
| **Auth** | Register · Login · JWT + Refresh tokens · Remember Me · Forgot password · Rate limiting |
| **Coin System** | Daily reward · Promo codes · Referral program · Leaderboard · Transaction history |
| **Shop** | Upgrade RAM · CPU · Disk · Server slots · Admin-configurable prices |
| **Ad Manager** | Banner · Popup · Reward · HTML · Image · Video ads · Coin rewards · Analytics |
| **Admin Panel** | User management · Suspend/unsuspend · Coin grants · Server oversight · Announcements · Audit logs |
| **Background Video** | Upload MP4/WebM · Opacity · Blur · Overlay controls · Live preview |
| **API** | REST API v1 · API key auth · Per-key permission scopes |
| **WebSocket** | Live console · Live system stats · Live server stats · Notifications |
| **Security** | bcrypt passwords · JWT · HttpOnly cookies · SQL injection protection · XSS protection · CSRF-safe · Audit logs · Input validation · Path traversal protection |

---

## 🚀 Quick Start

### Requirements

- **Node.js 18+** (LTS recommended)
- **Java 17+** (for Minecraft servers — must be on `PATH`)
- Linux / Ubuntu / Debian (or macOS for dev)

### Installation

```bash
git clone https://github.com/your-org/nx-panel.git
cd nx-panel
npm install
```

### Configure

Edit `config.json` before first run:

```json
{
  "port": 3000,
  "host": "0.0.0.0",
  "jwtSecret": "CHANGE_ME_TO_A_LONG_RANDOM_SECRET",
  "jwtRefreshSecret": "CHANGE_ME_TO_ANOTHER_LONG_RANDOM_SECRET",
  "defaultAdmin": {
    "username": "admin",
    "email": "admin@nxpanel.local",
    "password": "ChangeMe123!"
  }
}
```

> ⚠️ **Change `jwtSecret`, `jwtRefreshSecret`, and the admin password before exposing to the internet.**

### Start

```bash
npm start
```

Panel is now available at:

```
http://YOUR_SERVER_IP:3000
```

Default admin credentials (printed on first start and configurable in `config.json`):

```
Username: admin
Password: ChangeMe123!
```

---

## 🐳 Docker

### Docker Compose (recommended)

```bash
git clone https://github.com/your-org/nx-panel.git
cd nx-panel
# Edit config.json first!
docker compose up -d
```

### Manual Docker

```bash
docker build -t nx-panel .
docker run -d \
  -p 3000:3000 \
  -v nx-data:/app/database \
  -v nx-servers:/app/servers \
  -v nx-backups:/app/backups \
  --name nx-panel \
  nx-panel
```

---

## 🖥 Adding a Minecraft Server

1. **Create server** in the panel → My Servers → Create Server.
2. **Upload `server.jar`** via File Manager into the server's root directory.
   - Download Paper: https://papermc.io/downloads
   - Download Purpur: https://purpurmc.org/downloads
   - Download Vanilla: https://minecraft.net/en-us/download/server
3. **Start** the server from the dashboard or console page.
4. Connect Minecraft client to `YOUR_SERVER_IP:PORT` (shown on the server card).

> The panel auto-generates a `eula.txt` with `eula=true` on first start.

---

## ⚙️ Configuration Reference

`config.json` full options:

| Key | Default | Description |
|---|---|---|
| `port` | `3000` | Panel HTTP port |
| `host` | `0.0.0.0` | Bind address |
| `jwtSecret` | *(required)* | JWT access token secret — keep secret |
| `jwtRefreshSecret` | *(required)* | JWT refresh token secret — keep secret |
| `jwtExpiresIn` | `15m` | Access token lifetime |
| `jwtRefreshExpiresIn` | `7d` | Refresh token lifetime (Remember Me) |
| `bcryptRounds` | `12` | Password hashing rounds (higher = slower + safer) |
| `dbFile` | `./database/nxpanel.db` | SQLite database path |
| `defaultAdmin.username` | `admin` | Initial admin username |
| `defaultAdmin.email` | `admin@nxpanel.local` | Initial admin email |
| `defaultAdmin.password` | `ChangeMe123!` | Initial admin password |
| `freeServerDefaults.ramMb` | `3072` | Default RAM per new server (MB) |
| `freeServerDefaults.cpuPercent` | `100` | Default CPU limit per server |
| `freeServerDefaults.diskMb` | `10240` | Default disk per server (MB) |
| `rateLimit.max` | `200` | Requests per time window |
| `rateLimit.timeWindow` | `1 minute` | Rate limit window |

---

## 📡 REST API

Base URL: `http://YOUR_IP:3000/api/v1`

All endpoints (except auth) require `Authorization: Bearer <token>`.

### Authentication

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/auth/register` | Register a new account |
| `POST` | `/auth/login` | Login → returns `accessToken` + sets refresh cookie |
| `POST` | `/auth/refresh` | Exchange refresh cookie for new access token |
| `POST` | `/auth/logout` | Invalidate session |
| `POST` | `/auth/forgot-password` | Initiate password reset |
| `POST` | `/auth/reset-password` | Complete password reset with token |

**Login request:**
```json
POST /api/v1/auth/login
{ "username": "admin", "password": "ChangeMe123!", "rememberMe": true }
```

**Login response:**
```json
{ "accessToken": "eyJ...", "user": { "id": 1, "username": "admin", "role": "admin", "coins": 1000 } }
```

### Servers

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/servers` | List your servers |
| `POST` | `/servers` | Create a server |
| `GET` | `/servers/:id` | Get server details |
| `PATCH` | `/servers/:id` | Rename server |
| `DELETE` | `/servers/:id` | Delete server |
| `POST` | `/servers/:id/start` | Start server |
| `POST` | `/servers/:id/stop` | Graceful stop |
| `POST` | `/servers/:id/restart` | Restart |
| `POST` | `/servers/:id/kill` | Force kill |
| `POST` | `/servers/:id/command` | Send console command |
| `GET` | `/servers/:id/console` | Get recent log buffer |

**Create server:**
```json
POST /api/v1/servers
{ "name": "My SMP", "software": "paper", "version": "1.21" }
```

### File Manager

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/servers/:id/files?path=.` | List directory |
| `GET` | `/servers/:id/files/download?path=file.txt` | Download file |
| `POST` | `/servers/:id/files/upload?path=.` | Upload file (multipart) |
| `POST` | `/servers/:id/files/rename` | Rename / move |
| `DELETE` | `/servers/:id/files` | Delete file or folder |
| `POST` | `/servers/:id/files/mkdir` | Create directory |
| `POST` | `/servers/:id/files/zip` | Archive to `.tar.gz` |
| `GET` | `/servers/:id/files/content?path=server.properties` | Read text file |
| `PUT` | `/servers/:id/files/content` | Save text file |

### Backups

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/servers/:id/backups` | List backups |
| `POST` | `/servers/:id/backups` | Create backup |
| `DELETE` | `/servers/:id/backups/:backupId` | Delete backup |
| `GET` | `/servers/:id/backups/:backupId/download` | Download backup |
| `POST` | `/servers/:id/backup-schedule` | Create cron schedule |

### Coins & Shop

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/coins/balance` | Get coin balance |
| `POST` | `/coins/daily` | Claim daily reward |
| `POST` | `/coins/promo` | Redeem promo code `{ "code": "PROMO123" }` |
| `GET` | `/coins/leaderboard` | Top 10 users by coins |
| `GET` | `/coins/history` | Transaction history |
| `GET` | `/shop` | List shop items |
| `POST` | `/shop/buy` | Purchase item `{ "itemId": 1, "serverId": 2 }` |
| `POST` | `/ads/reward` | Claim ad coin reward `{ "adId": 1 }` |

### User / Profile

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/user/me` | Get current user |
| `PATCH` | `/user/me` | Update email / password |
| `GET` | `/user/notifications` | List notifications |
| `POST` | `/user/notifications/read` | Mark notifications read |
| `GET` | `/user/sessions` | Active sessions |
| `DELETE` | `/user/sessions/:id` | Revoke a session |
| `GET` | `/user/api-keys` | List API keys |
| `POST` | `/user/api-keys` | Create API key |
| `DELETE` | `/user/api-keys/:id` | Revoke API key |
| `GET` | `/user/referral` | Referral code + list |

### Statistics

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/stats/system` | Host CPU / RAM / Disk snapshot |
| `GET` | `/stats/servers/:id` | Live server stats |
| `GET` | `/announcements` | Active announcements |
| `GET` | `/ads/active` | Active ads (optional `?type=banner`) |

### Admin (requires `role: admin`)

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/admin/stats` | Panel-wide statistics |
| `GET` | `/admin/users` | List all users (paginated) |
| `GET` | `/admin/users/:id` | User detail + servers |
| `PATCH` | `/admin/users/:id` | Edit user (suspend, coins, slots, role) |
| `DELETE` | `/admin/users/:id` | Delete user |
| `POST` | `/admin/users/:id/coins` | Grant/remove coins |
| `GET` | `/admin/servers` | List all servers |
| `PATCH` | `/admin/servers/:id` | Edit server (suspend, resources) |
| `GET` | `/admin/announcements` | List announcements |
| `POST` | `/admin/announcements` | Post announcement (broadcasts to all) |
| `DELETE` | `/admin/announcements/:id` | Delete announcement |
| `GET` | `/admin/promos` | List promo codes |
| `POST` | `/admin/promos` | Create promo code |
| `DELETE` | `/admin/promos/:id` | Delete promo code |
| `GET` | `/admin/shop` | List shop items |
| `PATCH` | `/admin/shop/:id` | Edit shop item price/enabled |
| `GET` | `/admin/ads` | List all ads |
| `POST` | `/admin/ads` | Create ad |
| `PATCH` | `/admin/ads/:id` | Toggle ad / update |
| `DELETE` | `/admin/ads/:id` | Delete ad |
| `GET` | `/admin/settings` | Get all settings |
| `PATCH` | `/admin/settings` | Update settings |
| `POST` | `/admin/background` | Upload background video |
| `GET` | `/admin/logs` | Audit log |
| `GET` | `/admin/api-keys` | All API keys |
| `DELETE` | `/admin/api-keys/:id` | Revoke any API key |

---

## 🔌 WebSocket API

Connect to `ws://YOUR_IP:3000/ws`

### Authentication (first message required)

```json
{ "type": "auth", "token": "<accessToken>" }
```

Response:
```json
{ "type": "auth_ok", "username": "admin", "role": "admin" }
```

### Subscribe to channels

```json
{ "type": "subscribe", "channel": "system" }
{ "type": "subscribe", "channel": "console:<serverUuid>" }
{ "type": "subscribe", "channel": "stats:<serverUuid>" }
{ "type": "subscribe", "channel": "notifications" }
```

### Send console command

```json
{ "type": "command", "uuid": "<serverUuid>", "command": "list" }
```

### Incoming message types

| Channel | `type` | Description |
|---|---|---|
| `system` | `system_stats` | Host CPU / RAM / disk every 5s |
| `stats:<uuid>` | `server_stats` | TPS / players / uptime every 3s |
| `stats:<uuid>` | `status` | Status change (starting / running / stopped) |
| `console:<uuid>` | `console` | Console line(s) |
| `notifications` | *(push)* | New notification for current user |

---

## 🔐 API Key Authentication

Create an API key in Profile → API Keys (or `POST /api/v1/user/api-keys`).

Pass it as a Bearer token:

```bash
curl -H "Authorization: Bearer nxp_abc123..." http://localhost:3000/api/v1/servers
```

Available permission scopes: `server:read`, `server:write`, `files:read`, `files:write`, `coins:read`.

---

## 📁 Directory Structure

```
nx-panel/
├── server.js              # Fastify entry point
├── config.json            # Panel configuration
├── package.json
├── Dockerfile
├── docker-compose.yml
├── database/
│   └── db.js              # SQLite init + migrations
├── auth/
│   ├── routes.js          # Auth HTTP routes
│   ├── middleware.js      # JWT fastify decorators
│   └── tokens.js          # JWT + session helpers
├── api/v1/
│   ├── servers.js         # Server lifecycle API
│   ├── files.js           # File manager API
│   ├── coins.js           # Coin + shop API
│   ├── user.js            # User profile + API keys
│   ├── stats.js           # Statistics + ads API
│   └── admin.js           # Admin API
├── websocket/
│   └── wsHandler.js       # WebSocket hub
├── services/
│   ├── processManager.js  # Minecraft process lifecycle
│   ├── systemStats.js     # Host CPU/RAM/disk
│   ├── backupService.js   # Backup creation + listing
│   ├── coinService.js     # Coin economy logic
│   └── tarStream.js       # Dependency-free tar writer
├── utils/
│   ├── validate.js        # Input validation helpers
│   └── audit.js           # Audit log writer
├── public/
│   ├── index.html         # Single-page app shell
│   ├── css/style.css      # Dark glass theme
│   └── js/
│       ├── app.js         # Core: API client, router, auth, WS
│       ├── auth.js        # Auth form handlers
│       ├── dashboard.js   # Dashboard + system stats
│       └── pages.js       # All other page loaders
├── servers/               # Server directories (auto-created)
├── backups/               # Backup archives (auto-created)
├── backgrounds/           # Background videos (auto-created)
├── uploads/               # General uploads (auto-created)
└── logs/                  # Application logs (auto-created)
```

---

## 🛡 Security Notes

- Change **both JWT secrets** and the **admin password** before production use.
- Run behind an **nginx reverse proxy** with TLS in production.
- The panel uses **HttpOnly, SameSite=Strict** cookies for refresh tokens.
- All file paths are validated against path traversal (no `../`).
- All SQL queries use **prepared statements** — no string interpolation.
- Passwords are hashed with **bcrypt (12 rounds)** by default.
- Auth endpoints are individually rate-limited (10 req / 5–10 min).

### Recommended nginx config snippet

```nginx
server {
    listen 443 ssl;
    server_name panel.yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/panel.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/panel.yourdomain.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 3600s;
        client_max_body_size 500m;
    }
}
```

---

## 📸 Screenshots

> *(Deploy the panel and visit `http://YOUR_IP:3000` to see the live UI.)*

| View | Description |
|---|---|
| Login | Dark glass auth screen with animated background |
| Dashboard | Live stat cards · Server grid · Activity feed · Leaderboard |
| Console | Full terminal with live WebSocket output |
| File Manager | Tree browser with inline editing |
| Admin | User table · Coin grants · Audit logs |

---

## 🗺 Roadmap

- [ ] TOTP 2FA
- [ ] SMTP email for password reset
- [ ] Reverse proxy sub-domain support
- [ ] Per-server resource monitoring graphs
- [ ] Plugin/mod installer integrations (Modrinth API)
- [ ] Multi-node support (remote daemon)

---

## 🤝 Contributing

Pull requests are welcome. Please open an issue first for large changes.

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m 'feat: add my feature'`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📄 License

[MIT](./LICENSE) © 2025 NX Panel Contributors

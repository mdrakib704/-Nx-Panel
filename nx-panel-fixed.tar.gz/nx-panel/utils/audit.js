'use strict';

const db = require('../database/db');

const insertLog = db.prepare(
  'INSERT INTO audit_logs (user_id, action, details, ip) VALUES (?, ?, ?, ?)'
);

function audit(userId, action, details, ip) {
  try {
    insertLog.run(
      userId || null,
      action,
      details ? JSON.stringify(details) : null,
      ip || null
    );
  } catch (err) {
    console.error('[audit] failed to write log:', err.message);
  }
}

module.exports = { audit };

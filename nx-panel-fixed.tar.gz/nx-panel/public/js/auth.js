/* ════════════════════════════════════════════════════════════════
   NX Panel — Authentication Page JS
   ════════════════════════════════════════════════════════════════ */

'use strict';

function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach((el) =>
    el.classList.toggle('active', el.dataset.tab === tab)
  );
  document.getElementById('auth-form-login').style.display    = tab === 'login'    ? 'block' : 'none';
  document.getElementById('auth-form-register').style.display = tab === 'register' ? 'block' : 'none';
  document.getElementById('auth-form-forgot').style.display   = tab === 'forgot'   ? 'block' : 'none';
  document.getElementById('auth-msg').textContent = '';
}

function showForgotPassword() {
  document.querySelectorAll('.auth-tab').forEach((el) => el.classList.remove('active'));
  document.getElementById('auth-form-login').style.display    = 'none';
  document.getElementById('auth-form-register').style.display = 'none';
  document.getElementById('auth-form-forgot').style.display   = 'block';
  document.getElementById('auth-msg').textContent = '';
}

async function doLogin(e) {
  if (e) e.preventDefault();
  const username   = document.getElementById('login-username').value.trim();
  const password   = document.getElementById('login-password').value;
  const rememberMe = document.getElementById('login-remember').checked;
  const msgEl      = document.getElementById('auth-msg');
  const btn        = document.getElementById('login-btn');

  msgEl.textContent = '';
  if (!username || !password) {
    setAuthMsg('Username and password are required.', 'danger');
    return;
  }

  btn.disabled     = true;
  btn.innerHTML    = '<span class="spinner"></span> Signing in...';

  try {
    const data = await post('/api/v1/auth/login', { username, password, rememberMe });
    NX.token = data.accessToken;
    NX.user  = data.user;
    document.getElementById('login-password').value = '';
    showPanel();
  } catch (err) {
    setAuthMsg(err.message || 'Login failed.', 'danger');
  } finally {
    btn.disabled  = false;
    btn.textContent = 'Sign In';
  }
}

async function doRegister(e) {
  if (e) e.preventDefault();
  const username     = document.getElementById('reg-username').value.trim();
  const email        = document.getElementById('reg-email').value.trim();
  const password     = document.getElementById('reg-password').value;
  const confirm      = document.getElementById('reg-confirm').value;
  const referralCode = document.getElementById('reg-referral').value.trim();
  const btn          = document.getElementById('register-btn');

  if (!username || !email || !password) {
    setAuthMsg('All fields are required.', 'danger'); return;
  }
  if (password !== confirm) {
    setAuthMsg('Passwords do not match.', 'danger'); return;
  }
  if (password.length < 8) {
    setAuthMsg('Password must be at least 8 characters.', 'danger'); return;
  }

  btn.disabled  = true;
  btn.innerHTML = '<span class="spinner"></span> Creating account...';

  try {
    await post('/api/v1/auth/register', { username, email, password, referralCode: referralCode || undefined });
    setAuthMsg('Account created! You can now sign in.', 'success');
    document.getElementById('reg-username').value = '';
    document.getElementById('reg-email').value    = '';
    document.getElementById('reg-password').value = '';
    document.getElementById('reg-confirm').value  = '';
    document.getElementById('reg-referral').value = '';
    setTimeout(() => switchAuthTab('login'), 2000);
  } catch (err) {
    setAuthMsg(err.message || 'Registration failed.', 'danger');
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Create Account';
  }
}

async function doForgotPassword(e) {
  if (e) e.preventDefault();
  const email = document.getElementById('forgot-email').value.trim();
  const btn   = document.getElementById('forgot-btn');

  if (!email) { setAuthMsg('Email is required.', 'danger'); return; }

  btn.disabled  = true;
  btn.innerHTML = '<span class="spinner"></span> Sending...';

  try {
    const result = await post('/api/v1/auth/forgot-password', { email });
    setAuthMsg(result.message, 'success');
    document.getElementById('forgot-email').value = '';
  } catch (err) {
    setAuthMsg(err.message || 'Request failed.', 'danger');
  } finally {
    btn.disabled    = false;
    btn.textContent = 'Send Reset Link';
  }
}

function setAuthMsg(message, type) {
  const el = document.getElementById('auth-msg');
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.textContent = message;
  el.style.display = 'flex';
}

// Allow Enter key to submit forms
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const auth = document.getElementById('auth-screen');
  if (!auth || auth.style.display === 'none') return;
  const loginVisible  = document.getElementById('auth-form-login').style.display  !== 'none';
  const regVisible    = document.getElementById('auth-form-register').style.display !== 'none';
  const forgotVisible = document.getElementById('auth-form-forgot').style.display  !== 'none';
  if (loginVisible)  doLogin();
  if (regVisible)    doRegister();
  if (forgotVisible) doForgotPassword();
});

/* ════════════════════════════════════════════════════════════════
   NX Panel — Core Application JS
   ════════════════════════════════════════════════════════════════ */

'use strict';

// ── State ─────────────────────────────────────────────────────────────────────
const NX = {
  token: null,
  user: null,
  ws: null,
  wsChannels: new Set(),
  wsReconnectTimer: null,
  currentPage: null,
  currentServerId: null,
  serverData: null,
  filePath: '.'
};

// ── API Client ─────────────────────────────────────────────────────────────────
async function api(method, path, body, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (NX.token) headers['Authorization'] = `Bearer ${NX.token}`;
  if (opts.formData) delete headers['Content-Type'];

  const res = await fetch(path, {
    method,
    headers,
    body: opts.formData ? body : (body ? JSON.stringify(body) : undefined),
    credentials: 'include'
  });

  if (res.status === 401 && !opts.noRefresh) {
    const refreshed = await tryRefreshToken();
    if (refreshed) return api(method, path, body, { ...opts, noRefresh: true });
    logoutUI();
    return null;
  }

  let data;
  try { data = await res.json(); } catch { data = {}; }
  if (!res.ok) throw Object.assign(new Error(data.error || 'Request failed'), { status: res.status, data });
  return data;
}

const get  = (p, o)    => api('GET', p, null, o);
const post = (p, b, o) => api('POST', p, b, o);
const put  = (p, b, o) => api('PUT', p, b, o);
const patch = (p, b, o) => api('PATCH', p, b, o);
const del  = (p, b, o) => api('DELETE', p, b, o);

async function tryRefreshToken() {
  try {
    const data = await api('POST', '/api/v1/auth/refresh', null, { noRefresh: true });
    if (data && data.accessToken) {
      NX.token = data.accessToken;
      return true;
    }
  } catch {}
  return false;
}

// ── Toast Notifications ────────────────────────────────────────────────────────
function toast(message, type = 'info', duration = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const icons = { success: '✓', error: '✕', info: 'ℹ', warning: '⚠' };
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<span>${icons[type] || 'ℹ'}</span><span>${escHtml(message)}</span>`;
  el.addEventListener('click', () => el.remove());
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity 0.3s'; setTimeout(() => el.remove(), 300); }, duration);
}

// ── HTML Escaping ──────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── Date formatting ────────────────────────────────────────────────────────────
function fmtDate(ts) {
  if (!ts) return '—';
  const ms = ts > 1e12 ? ts : ts * 1000;
  return new Date(ms).toLocaleString();
}
function fmtBytes(b) {
  if (b === undefined || b === null) return '—';
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1024 / 1024).toFixed(1) + ' MB';
}
function fmtUptime(ms) {
  if (!ms) return '—';
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}

// ── Auth State ─────────────────────────────────────────────────────────────────
async function initAuth() {
  const refreshed = await tryRefreshToken();
  if (refreshed) {
    try {
      NX.user = await get('/api/v1/user/me');
      showPanel();
    } catch {
      showAuth();
    }
  } else {
    showAuth();
  }
}

function showAuth() {
  document.getElementById('auth-screen').style.display = 'flex';
  document.getElementById('panel-screen').style.display = 'none';
}

function showPanel() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('panel-screen').style.display = 'flex';
  renderSidebar();
  loadAnnouncements();
  connectWebSocket();
  navigate('dashboard');
  scheduleTokenRefresh();
}

function logoutUI() {
  NX.token = null;
  NX.user = null;
  if (NX.ws) { NX.ws.close(); NX.ws = null; }
  clearTimeout(NX.wsReconnectTimer);
  showAuth();
}

async function doLogout() {
  try { await post('/api/v1/auth/logout'); } catch {}
  logoutUI();
}

function scheduleTokenRefresh() {
  // Refresh access token every 12 minutes (token expires at 15m)
  setInterval(async () => {
    if (NX.user) await tryRefreshToken();
  }, 12 * 60 * 1000);
}

// ── Router / Page Navigation ───────────────────────────────────────────────────
const PAGE_LOADERS = {
  dashboard:    loadDashboard,
  servers:      loadServersPage,
  console:      loadConsolePage,
  files:        loadFilesPage,
  backups:      loadBackupsPage,
  coins:        loadCoinsPage,
  shop:         loadShopPage,
  profile:      loadProfilePage,
  admin:        loadAdminDashboard,
  'admin-users':   loadAdminUsers,
  'admin-servers': loadAdminServers,
  'admin-ads':     loadAdminAds,
  'admin-settings':loadAdminSettings,
  'admin-logs':    loadAdminLogs
};

function navigate(page, data) {
  if (data) Object.assign(NX, data);
  NX.currentPage = page;

  document.querySelectorAll('.nav-item').forEach((el) => {
    el.classList.toggle('active', el.dataset.page === page);
  });

  document.querySelectorAll('.page').forEach((el) => el.classList.remove('active'));
  const pageEl = document.getElementById(`page-${page}`);
  if (pageEl) pageEl.classList.add('active');

  const titleEl = document.querySelector('.header-title');
  const titles = {
    dashboard: '🏠 Dashboard', servers: '🖥 My Servers', console: '📟 Console',
    files: '📁 File Manager', backups: '💾 Backups', coins: '🪙 Coins',
    shop: '🛒 Shop', profile: '👤 Profile', admin: '⚙️ Admin Dashboard',
    'admin-users': '👥 User Management', 'admin-servers': '🖥 All Servers',
    'admin-ads': '📢 Ad Manager', 'admin-settings': '⚙️ Settings', 'admin-logs': '📋 Audit Logs'
  };
  if (titleEl) titleEl.textContent = titles[page] || 'NX Panel';

  if (PAGE_LOADERS[page]) PAGE_LOADERS[page]();
}

// ── Sidebar ────────────────────────────────────────────────────────────────────
function renderSidebar() {
  if (!NX.user) return;
  const isAdmin = NX.user.role === 'admin';

  const nav = document.getElementById('sidebar-nav');
  const userItems = [
    { page: 'dashboard', icon: '⊞', label: 'Dashboard' },
    { page: 'servers',   icon: '🖥', label: 'My Servers' },
    { page: 'coins',     icon: '🪙', label: 'Coins' },
    { page: 'shop',      icon: '🛒', label: 'Shop' },
    { page: 'profile',   icon: '👤', label: 'Profile' }
  ];
  const adminItems = [
    { page: 'admin',          icon: '⚙️', label: 'Overview' },
    { page: 'admin-users',    icon: '👥', label: 'Users' },
    { page: 'admin-servers',  icon: '🖥', label: 'All Servers' },
    { page: 'admin-ads',      icon: '📢', label: 'Ad Manager' },
    { page: 'admin-settings', icon: '🔧', label: 'Settings' },
    { page: 'admin-logs',     icon: '📋', label: 'Audit Logs' }
  ];

  let html = '<div class="nav-section-label">Menu</div>';
  for (const item of userItems) {
    html += `<button class="nav-item" data-page="${item.page}" onclick="navigate('${item.page}')">
      <span class="nav-icon">${item.icon}</span> ${item.label}
    </button>`;
  }

  if (isAdmin) {
    html += '<div class="nav-section-label">Admin</div>';
    for (const item of adminItems) {
      html += `<button class="nav-item" data-page="${item.page}" onclick="navigate('${item.page}')">
        <span class="nav-icon">${item.icon}</span> ${item.label}
      </button>`;
    }
  }

  nav.innerHTML = html;

  const avatar = document.getElementById('sidebar-avatar');
  const userName = document.getElementById('sidebar-username');
  const userRole = document.getElementById('sidebar-role');
  const userCoins = document.getElementById('sidebar-coins');

  if (avatar)   avatar.textContent = NX.user.username[0].toUpperCase();
  if (userName) userName.textContent = NX.user.username;
  if (userRole) userRole.textContent = NX.user.role === 'admin' ? '👑 Admin' : '👤 User';
  if (userCoins) userCoins.textContent = `🪙 ${NX.user.coins}`;
}

async function refreshUserCoins() {
  try {
    const data = await get('/api/v1/coins/balance');
    if (data) {
      NX.user.coins = data.coins;
      const el = document.getElementById('sidebar-coins');
      if (el) el.textContent = `🪙 ${data.coins}`;
    }
  } catch {}
}

// ── WebSocket ──────────────────────────────────────────────────────────────────
function connectWebSocket() {
  if (NX.ws && NX.ws.readyState < 2) return;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  NX.ws = new WebSocket(`${proto}://${location.host}/ws`);

  NX.ws.addEventListener('open', () => {
    NX.ws.send(JSON.stringify({ type: 'auth', token: NX.token }));
  });

  NX.ws.addEventListener('message', (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    handleWsMessage(msg);
  });

  NX.ws.addEventListener('close', () => {
    NX.wsReconnectTimer = setTimeout(connectWebSocket, 5000);
  });
  NX.ws.addEventListener('error', () => {
    NX.ws.close();
  });
}

function wsSubscribe(channel) {
  if (!NX.ws || NX.ws.readyState !== 1) return;
  NX.ws.send(JSON.stringify({ type: 'subscribe', channel }));
  NX.wsChannels.add(channel);
}

function handleWsMessage(msg) {
  if (msg.type === 'auth_ok') {
    wsSubscribe('system');
    wsSubscribe('notifications');
    if (NX.currentServerId) {
      const server = NX.serverData;
      if (server) {
        wsSubscribe(`console:${server.uuid}`);
        wsSubscribe(`stats:${server.uuid}`);
      }
    }
    return;
  }

  if (msg.channel === 'system' && msg.type === 'system_stats') {
    updateSystemStatDisplay(msg.data);
    return;
  }

  if (msg.channel && msg.channel.startsWith('console:') && msg.type === 'console') {
    appendConsoleLine(msg.line);
    return;
  }

  if (msg.channel && msg.channel.startsWith('stats:') && msg.type === 'server_stats') {
    updateServerStatDisplay(msg.data);
    return;
  }

  if (msg.channel === 'notifications') {
    updateNotificationBadge();
    return;
  }
}

function sendWsCommand(uuid, command) {
  if (!NX.ws || NX.ws.readyState !== 1) { toast('WebSocket not connected.', 'error'); return; }
  NX.ws.send(JSON.stringify({ type: 'command', uuid, command }));
}

// ── Announcements ──────────────────────────────────────────────────────────────
async function loadAnnouncements() {
  try {
    const items = await get('/api/v1/announcements');
    if (!items || items.length === 0) return;
    const latest = items[0];
    const bar = document.getElementById('announcement-bar');
    if (bar) {
      bar.innerHTML = `<span class="badge badge-${latest.level === 'danger' ? 'red' : latest.level === 'warning' ? 'yellow' : 'blue'}">${latest.level.toUpperCase()}</span>
        <span>${escHtml(latest.title)}: ${escHtml(latest.message)}</span>
        <button class="btn-icon" style="margin-left:auto;width:24px;height:24px;font-size:12px" onclick="this.parentElement.remove()">✕</button>`;
      bar.style.display = 'flex';
    }
  } catch {}
}

async function updateNotificationBadge() {
  try {
    const notes = await get('/api/v1/user/notifications');
    const unread = notes ? notes.filter((n) => !n.read).length : 0;
    const badge = document.getElementById('notif-badge');
    if (badge) {
      badge.textContent = unread;
      badge.style.display = unread > 0 ? 'inline' : 'none';
    }
  } catch {}
}

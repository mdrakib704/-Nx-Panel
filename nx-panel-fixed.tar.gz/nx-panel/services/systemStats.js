'use strict';

const os = require('os');
const fs = require('fs');

let lastCpuInfo = os.cpus();
let lastSampleTime = Date.now();

function cpuUsagePercent() {
  const cpus = os.cpus();
  let idleDiff = 0;
  let totalDiff = 0;

  for (let i = 0; i < cpus.length; i++) {
    const prev = lastCpuInfo[i] ? lastCpuInfo[i].times : cpus[i].times;
    const cur = cpus[i].times;
    const prevTotal = Object.values(prev).reduce((a, b) => a + b, 0);
    const curTotal = Object.values(cur).reduce((a, b) => a + b, 0);
    idleDiff += cur.idle - prev.idle;
    totalDiff += curTotal - prevTotal;
  }

  lastCpuInfo = cpus;
  lastSampleTime = Date.now();

  if (totalDiff <= 0) return 0;
  const usage = 1 - idleDiff / totalDiff;
  return Math.max(0, Math.min(100, Math.round(usage * 1000) / 10));
}

function memoryUsage() {
  const total = os.totalmem();
  const free = os.freemem();
  const used = total - free;
  return {
    totalMb: Math.round(total / 1024 / 1024),
    usedMb: Math.round(used / 1024 / 1024),
    freeMb: Math.round(free / 1024 / 1024),
    percent: Math.round((used / total) * 1000) / 10
  };
}

function diskUsage(targetPath = '/') {
  try {
    const stats = fs.statfsSync(targetPath);
    const total = stats.blocks * stats.bsize;
    const free = stats.bfree * stats.bsize;
    const used = total - free;
    return {
      totalMb: Math.round(total / 1024 / 1024),
      usedMb: Math.round(used / 1024 / 1024),
      freeMb: Math.round(free / 1024 / 1024),
      percent: total > 0 ? Math.round((used / total) * 1000) / 10 : 0
    };
  } catch {
    return { totalMb: 0, usedMb: 0, freeMb: 0, percent: 0 };
  }
}

function networkStats() {
  const nets = os.networkInterfaces();
  let interfaceCount = 0;
  for (const name of Object.keys(nets)) {
    if (nets[name].some((i) => !i.internal)) interfaceCount += 1;
  }
  return { activeInterfaces: interfaceCount };
}

function snapshot() {
  return {
    cpu: cpuUsagePercent(),
    memory: memoryUsage(),
    disk: diskUsage(),
    network: networkStats(),
    loadAvg: os.loadavg(),
    uptimeSec: os.uptime(),
    timestamp: Date.now()
  };
}

module.exports = { snapshot, cpuUsagePercent, memoryUsage, diskUsage };

'use strict';

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const EventEmitter = require('events');

const SERVERS_DIR = path.resolve(__dirname, '..', 'servers');

/**
 * In-memory registry of running Minecraft server processes.
 * Kept intentionally simple/lightweight: no external process manager,
 * just native child_process so the panel itself stays low on RAM.
 */
class ServerProcessManager extends EventEmitter {
  constructor() {
    super();
    this.processes = new Map(); // serverUuid -> { proc, logBuffer, stats }
  }

  getServerDir(uuid) {
    return path.join(SERVERS_DIR, uuid);
  }

  ensureServerDir(uuid) {
    const dir = this.getServerDir(uuid);
    fs.mkdirSync(dir, { recursive: true });
    return dir;
  }

  isRunning(uuid) {
    return this.processes.has(uuid);
  }

  start(serverRow) {
    const { uuid, ram_mb, port } = serverRow;
    if (this.isRunning(uuid)) {
      throw new Error('Server is already running.');
    }

    const dir = this.ensureServerDir(uuid);
    const jarPath = path.join(dir, 'server.jar');

    if (!fs.existsSync(jarPath)) {
      // Write an EULA + placeholder note so operators know to drop a jar in.
      fs.writeFileSync(
        path.join(dir, 'eula.txt'),
        'eula=true\n# Accepted automatically by NX Panel on first start.\n'
      );
      throw new Error(
        'No server.jar found in this server\'s directory. Upload a server jar (Paper/Purpur/Fabric/Forge/Vanilla) via the File Manager before starting.'
      );
    }

    const args = [
      `-Xms256M`,
      `-Xmx${ram_mb}M`,
      '-Dfile.encoding=UTF-8',
      '-jar',
      'server.jar',
      'nogui'
    ];

    const proc = spawn('java', args, {
      cwd: dir,
      env: { ...process.env, NX_SERVER_PORT: String(port) }
    });

    const entry = {
      proc,
      logBuffer: [],
      stats: { tps: 20.0, mspt: 0, playersOnline: 0, playersMax: 20 },
      startedAt: Date.now()
    };
    this.processes.set(uuid, entry);

    proc.stdout.on('data', (chunk) => {
      const text = chunk.toString('utf8');
      this._pushLog(uuid, text);
      this._parseLogForStats(uuid, text);
    });

    proc.stderr.on('data', (chunk) => {
      this._pushLog(uuid, chunk.toString('utf8'));
    });

    proc.on('exit', (code) => {
      this._pushLog(uuid, `\n[NX Panel] Process exited with code ${code}\n`);
      this.processes.delete(uuid);
      this.emit('status', { uuid, status: 'stopped' });
    });

    this.emit('status', { uuid, status: 'starting' });
    return true;
  }

  _pushLog(uuid, text) {
    const entry = this.processes.get(uuid);
    if (!entry) return;
    entry.logBuffer.push(text);
    if (entry.logBuffer.length > 500) entry.logBuffer.shift();
    this.emit('console', { uuid, line: text });
  }

  _parseLogForStats(uuid, text) {
    const entry = this.processes.get(uuid);
    if (!entry) return;
    if (/Done \(/i.test(text)) {
      this.emit('status', { uuid, status: 'running' });
    }
    const joinMatch = text.match(/\[Server thread\/INFO\].*joined the game/);
    const leaveMatch = text.match(/\[Server thread\/INFO\].*left the game/);
    if (joinMatch) entry.stats.playersOnline += 1;
    if (leaveMatch) entry.stats.playersOnline = Math.max(0, entry.stats.playersOnline - 1);
  }

  sendCommand(uuid, command) {
    const entry = this.processes.get(uuid);
    if (!entry) throw new Error('Server is not running.');
    entry.proc.stdin.write(command + '\n');
  }

  stop(uuid, force = false) {
    const entry = this.processes.get(uuid);
    if (!entry) throw new Error('Server is not running.');
    if (force) {
      entry.proc.kill('SIGKILL');
    } else {
      entry.proc.stdin.write('stop\n');
      setTimeout(() => {
        if (this.processes.has(uuid)) {
          entry.proc.kill('SIGTERM');
        }
      }, 15000);
    }
    return true;
  }

  restart(serverRow) {
    const { uuid } = serverRow;
    if (this.isRunning(uuid)) {
      this.stop(uuid);
      const onExit = () => {
        this.off('status', onExit);
      };
      this.once('status', (evt) => {
        if (evt.uuid === uuid && evt.status === 'stopped') {
          setTimeout(() => this.start(serverRow), 1000);
        }
      });
    } else {
      this.start(serverRow);
    }
  }

  getRecentLogs(uuid) {
    const entry = this.processes.get(uuid);
    return entry ? entry.logBuffer.join('') : '';
  }

  getStats(uuid) {
    const entry = this.processes.get(uuid);
    if (!entry) {
      return { status: 'stopped', cpu: 0, ramMb: 0, playersOnline: 0, tps: 0, mspt: 0 };
    }
    return {
      status: 'running',
      cpu: 0,
      ramMb: 0,
      playersOnline: entry.stats.playersOnline,
      playersMax: entry.stats.playersMax,
      tps: entry.stats.tps,
      mspt: entry.stats.mspt,
      uptimeMs: Date.now() - entry.startedAt
    };
  }
}

module.exports = new ServerProcessManager();

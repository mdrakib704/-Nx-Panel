'use strict';

const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');

function buildHeader(name, size, mode, mtime, typeflag) {
  const buf = Buffer.alloc(512);
  const writeStr = (str, offset, len) => buf.write(str, offset, len, 'utf8');

  const safeName = name.length > 100 ? name.slice(-100) : name;
  writeStr(safeName, 0, 100);
  writeStr(mode.toString(8).padStart(6, '0') + ' \0', 100, 8);
  writeStr('0000000 \0', 108, 8);
  writeStr('0000000 \0', 116, 8);
  writeStr(size.toString(8).padStart(11, '0') + ' ', 124, 12);
  writeStr(Math.floor(mtime / 1000).toString(8).padStart(11, '0') + ' ', 136, 12);
  buf.write('        ', 148, 8, 'utf8'); // checksum placeholder
  buf.write(typeflag, 156, 1, 'utf8');
  buf.write('ustar', 257, 5, 'utf8');
  buf.write('00', 263, 2, 'utf8');

  let checksum = 0;
  for (let i = 0; i < 512; i++) checksum += buf[i];
  buf.write(checksum.toString(8).padStart(6, '0') + '\0 ', 148, 8, 'utf8');

  return buf;
}

function padTo512(buf) {
  const remainder = buf.length % 512;
  if (remainder === 0) return buf;
  return Buffer.concat([buf, Buffer.alloc(512 - remainder)]);
}

function walkFiles(rootDir, currentDir, fileList) {
  const entries = fs.readdirSync(currentDir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(currentDir, entry.name);
    const relPath = path.relative(rootDir, fullPath).split(path.sep).join('/');
    if (entry.isDirectory()) {
      fileList.push({ fullPath, relPath: relPath + '/', isDir: true });
      walkFiles(rootDir, fullPath, fileList);
    } else if (entry.isFile()) {
      fileList.push({ fullPath, relPath, isDir: false });
    }
  }
}

function createTarStream(rootDir) {
  const fileList = [];
  if (fs.existsSync(rootDir)) {
    walkFiles(rootDir, rootDir, fileList);
  }

  let index = 0;
  const stream = new Readable({
    read() {
      if (index >= fileList.length) {
        this.push(Buffer.alloc(1024)); // two 512-byte zero blocks = EOF
        this.push(null);
        return;
      }
      const item = fileList[index++];
      const stat = fs.statSync(item.fullPath);

      if (item.isDir) {
        const header = buildHeader(item.relPath, 0, 0o755, stat.mtimeMs, '5');
        this.push(header);
        return;
      }

      const content = fs.readFileSync(item.fullPath);
      const header = buildHeader(item.relPath, content.length, 0o644, stat.mtimeMs, '0');
      this.push(header);
      this.push(padTo512(content));
    }
  });

  return stream;
}

module.exports = { createTarStream };

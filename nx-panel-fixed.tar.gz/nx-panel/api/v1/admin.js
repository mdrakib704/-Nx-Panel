'use strict';

const db = require('../../database/db');
const { audit } = require('../../utils/audit');
const { addCoins } = require('../../services/coinService');
const { sanitizeString } = require('../../utils/validate');
const crypto = require('crypto');

async function adminRoutes(fastify) {
  fastify.addHook('preHandler', fastify.authenticate);
  fastify.addHook('preHandler', fastify.requireAdmin);

  // ─── Users ────────────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/users', async (request) => {
    const page = Math.max(1, parseInt(request.query.page) || 1);
    const limit = Math.min(100, parseInt(request.query.limit) || 25);
    const offset = (page - 1) * limit;
    const search = request.query.search
      ? `%${request.query.search}%`
      : '%';

    const users = db
      .prepare(
        `SELECT id, username, email, role, coins, suspended, server_slots, created_at, last_login_at
         FROM users WHERE username LIKE ? OR email LIKE ? LIMIT ? OFFSET ?`
      )
      .all(search, search, limit, offset);

    const total = db
      .prepare('SELECT COUNT(*) AS c FROM users WHERE username LIKE ? OR email LIKE ?')
      .get(search, search).c;

    return { users, total, page, limit };
  });

  fastify.get('/api/v1/admin/users/:id', async (request, reply) => {
    const user = db
      .prepare('SELECT id, username, email, role, coins, suspended, server_slots, created_at FROM users WHERE id = ?')
      .get(request.params.id);
    if (!user) return reply.code(404).send({ error: 'User not found.' });
    const servers = db.prepare('SELECT * FROM servers WHERE owner_id = ?').all(user.id);
    return { ...user, servers };
  });

  fastify.patch('/api/v1/admin/users/:id', async (request, reply) => {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(request.params.id);
    if (!user) return reply.code(404).send({ error: 'User not found.' });

    const body = request.body || {};
    const updates = [];
    const values = [];

    if (typeof body.suspended === 'number') {
      updates.push('suspended = ?');
      values.push(body.suspended ? 1 : 0);
    }
    if (typeof body.coins === 'number') {
      updates.push('coins = ?');
      values.push(Math.max(0, Math.floor(body.coins)));
    }
    if (typeof body.server_slots === 'number') {
      updates.push('server_slots = ?');
      values.push(Math.max(1, Math.floor(body.server_slots)));
    }
    if (body.role === 'admin' || body.role === 'user') {
      updates.push('role = ?');
      values.push(body.role);
    }

    if (updates.length === 0) return reply.code(400).send({ error: 'No valid fields to update.' });

    values.push(request.params.id);
    db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    audit(request.user.id, 'admin_edit_user', { targetId: request.params.id, updates: body }, request.ip);
    return { message: 'User updated.' };
  });

  fastify.delete('/api/v1/admin/users/:id', async (request, reply) => {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(request.params.id);
    if (!user) return reply.code(404).send({ error: 'User not found.' });
    if (user.id === request.user.id) {
      return reply.code(400).send({ error: 'Cannot delete your own account via admin API.' });
    }
    db.prepare('DELETE FROM users WHERE id = ?').run(user.id);
    audit(request.user.id, 'admin_delete_user', { username: user.username }, request.ip);
    return { message: 'User deleted.' };
  });

  fastify.post('/api/v1/admin/users/:id/coins', async (request, reply) => {
    const { amount, description } = request.body || {};
    if (typeof amount !== 'number' || amount === 0) {
      return reply.code(400).send({ error: 'A non-zero amount is required.' });
    }
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(request.params.id);
    if (!user) return reply.code(404).send({ error: 'User not found.' });
    addCoins(user.id, amount, 'admin_grant', description || 'Admin coin grant');
    audit(request.user.id, 'admin_coin_grant', { userId: user.id, amount }, request.ip);
    return { message: `${amount > 0 ? '+' : ''}${amount} coins applied to ${user.username}.` };
  });

  // ─── Servers (admin view) ─────────────────────────────────────────────────

  fastify.get('/api/v1/admin/servers', async () => {
    return db
      .prepare(
        `SELECT s.*, u.username AS owner_username
         FROM servers s JOIN users u ON u.id = s.owner_id
         ORDER BY s.created_at DESC`
      )
      .all();
  });

  fastify.patch('/api/v1/admin/servers/:id', async (request, reply) => {
    const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(request.params.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const body = request.body || {};
    const updates = [];
    const values = [];

    if (typeof body.suspended === 'number') { updates.push('suspended = ?'); values.push(body.suspended ? 1 : 0); }
    if (typeof body.ram_mb === 'number') { updates.push('ram_mb = ?'); values.push(body.ram_mb); }
    if (typeof body.cpu_percent === 'number') { updates.push('cpu_percent = ?'); values.push(body.cpu_percent); }
    if (typeof body.disk_mb === 'number') { updates.push('disk_mb = ?'); values.push(body.disk_mb); }

    if (updates.length === 0) return reply.code(400).send({ error: 'Nothing to update.' });

    values.push(request.params.id);
    db.prepare(`UPDATE servers SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    audit(request.user.id, 'admin_edit_server', { serverId: request.params.id }, request.ip);
    return { message: 'Server updated.' };
  });

  // ─── Announcements ────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/announcements', async () => {
    return db.prepare('SELECT * FROM announcements ORDER BY created_at DESC LIMIT 50').all();
  });

  fastify.post('/api/v1/admin/announcements', async (request, reply) => {
    const { title, message, level } = request.body || {};
    if (!title || !message) {
      return reply.code(400).send({ error: 'Title and message are required.' });
    }
    const safeLevel = ['info', 'warning', 'danger', 'success'].includes(level)
      ? level
      : 'info';

    const result = db
      .prepare('INSERT INTO announcements (title, message, level) VALUES (?, ?, ?)')
      .run(sanitizeString(title, 200), sanitizeString(message, 1000), safeLevel);

    // Broadcast a notification to all users
    db.prepare(
      'INSERT INTO notifications (user_id, title, message) SELECT id, ?, ? FROM users'
    ).run(sanitizeString(title, 200), sanitizeString(message, 1000));

    return reply.code(201).send({ id: result.lastInsertRowid, message: 'Announcement posted.' });
  });

  fastify.delete('/api/v1/admin/announcements/:id', async (request, reply) => {
    db.prepare('DELETE FROM announcements WHERE id = ?').run(request.params.id);
    return { message: 'Announcement deleted.' };
  });

  // ─── Promo Codes ─────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/promos', async () => {
    return db.prepare('SELECT * FROM promo_codes ORDER BY created_at DESC').all();
  });

  fastify.post('/api/v1/admin/promos', async (request, reply) => {
    const { code, coinValue, maxUses, expiresAt } = request.body || {};
    if (!code || !coinValue) {
      return reply.code(400).send({ error: 'code and coinValue are required.' });
    }
    const safeCode = code.trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 32);
    const result = db
      .prepare(
        'INSERT INTO promo_codes (code, coin_value, max_uses, expires_at) VALUES (?, ?, ?, ?)'
      )
      .run(safeCode, Math.floor(coinValue), maxUses || 1, expiresAt || null);
    return reply.code(201).send({ id: result.lastInsertRowid, code: safeCode });
  });

  fastify.delete('/api/v1/admin/promos/:id', async (request, reply) => {
    db.prepare('DELETE FROM promo_codes WHERE id = ?').run(request.params.id);
    return { message: 'Promo code deleted.' };
  });

  // ─── Shop Items ───────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/shop', async () => {
    return db.prepare('SELECT * FROM shop_items').all();
  });

  fastify.patch('/api/v1/admin/shop/:id', async (request, reply) => {
    const body = request.body || {};
    const updates = [];
    const values = [];
    if (typeof body.price_coins === 'number') { updates.push('price_coins = ?'); values.push(body.price_coins); }
    if (typeof body.enabled === 'number') { updates.push('enabled = ?'); values.push(body.enabled ? 1 : 0); }
    if (updates.length === 0) return reply.code(400).send({ error: 'Nothing to update.' });
    values.push(request.params.id);
    db.prepare(`UPDATE shop_items SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    return { message: 'Shop item updated.' };
  });

  // ─── Ads ─────────────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/ads', async () => {
    return db.prepare('SELECT * FROM ads ORDER BY created_at DESC').all();
  });

  fastify.post('/api/v1/admin/ads', async (request, reply) => {
    const body = request.body || {};
    const { type, title, content, coinReward, closeable, frequencyMinutes } = body;
    if (!type || !title || !content) {
      return reply.code(400).send({ error: 'type, title and content are required.' });
    }
    const safeType = ['banner', 'popup', 'reward', 'html', 'image', 'video'].includes(type)
      ? type
      : 'banner';

    const result = db
      .prepare(
        `INSERT INTO ads (type, title, content, coin_reward, closeable, frequency_minutes)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(
        safeType,
        sanitizeString(title, 200),
        sanitizeString(content, 5000),
        Math.max(0, parseInt(coinReward) || 0),
        closeable === false ? 0 : 1,
        Math.max(0, parseInt(frequencyMinutes) || 60)
      );

    return reply.code(201).send({ id: result.lastInsertRowid });
  });

  fastify.patch('/api/v1/admin/ads/:id', async (request, reply) => {
    const body = request.body || {};
    const updates = [];
    const values = [];
    if (typeof body.enabled === 'number') { updates.push('enabled = ?'); values.push(body.enabled ? 1 : 0); }
    if (typeof body.coin_reward === 'number') { updates.push('coin_reward = ?'); values.push(body.coin_reward); }
    if (typeof body.frequency_minutes === 'number') { updates.push('frequency_minutes = ?'); values.push(body.frequency_minutes); }
    if (updates.length === 0) return reply.code(400).send({ error: 'Nothing to update.' });
    values.push(request.params.id);
    db.prepare(`UPDATE ads SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    return { message: 'Ad updated.' };
  });

  fastify.delete('/api/v1/admin/ads/:id', async (request, reply) => {
    db.prepare('DELETE FROM ads WHERE id = ?').run(request.params.id);
    return { message: 'Ad deleted.' };
  });

  // ─── Settings ────────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/settings', async () => {
    const rows = db.prepare('SELECT key, value FROM settings').all();
    return Object.fromEntries(rows.map((r) => [r.key, r.value]));
  });

  fastify.patch('/api/v1/admin/settings', async (request, reply) => {
    const body = request.body || {};
    const ALLOWED_KEYS = [
      'site_name', 'background_video', 'background_loop', 'background_mute',
      'background_blur', 'background_brightness', 'background_opacity',
      'background_overlay', 'daily_reward_coins', 'referral_reward_coins',
      'maintenance_mode', 'theme'
    ];
    const upsert = db.prepare(
      'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
    );
    for (const [k, v] of Object.entries(body)) {
      if (ALLOWED_KEYS.includes(k)) {
        upsert.run(k, String(v));
      }
    }
    audit(request.user.id, 'admin_settings_update', body, request.ip);
    return { message: 'Settings updated.' };
  });

  // ─── Background video upload ──────────────────────────────────────────────

  fastify.post('/api/v1/admin/background', async (request, reply) => {
    const data = await request.file();
    if (!data) return reply.code(400).send({ error: 'No file uploaded.' });

    const ext = data.filename.split('.').pop().toLowerCase();
    if (!['mp4', 'webm'].includes(ext)) {
      return reply.code(400).send({ error: 'Only .mp4 and .webm files are allowed.' });
    }

    const fs = require('fs');
    const path = require('path');
    const bgDir = path.resolve(__dirname, '..', '..', 'backgrounds');
    fs.mkdirSync(bgDir, { recursive: true });

    const safeName = `bg_${Date.now()}.${ext}`;
    const destPath = path.join(bgDir, safeName);
    const { pipeline } = require('stream/promises');
    await pipeline(data.file, fs.createWriteStream(destPath));

    db.prepare("INSERT INTO settings (key, value) VALUES ('background_video', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(`/backgrounds/${safeName}`);
    audit(request.user.id, 'background_upload', { filename: safeName }, request.ip);
    return reply.code(201).send({ url: `/backgrounds/${safeName}` });
  });

  // ─── Audit Logs ───────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/logs', async (request) => {
    const limit = Math.min(200, parseInt(request.query.limit) || 50);
    const offset = Math.max(0, parseInt(request.query.offset) || 0);
    return db
      .prepare(
        `SELECT a.*, u.username FROM audit_logs a
         LEFT JOIN users u ON u.id = a.user_id
         ORDER BY a.created_at DESC LIMIT ? OFFSET ?`
      )
      .all(limit, offset);
  });

  // ─── Statistics ───────────────────────────────────────────────────────────

  fastify.get('/api/v1/admin/stats', async () => {
    const totalUsers = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
    const totalServers = db.prepare('SELECT COUNT(*) AS c FROM servers').get().c;
    const runningServers = db.prepare("SELECT COUNT(*) AS c FROM servers WHERE status = 'running'").get().c;
    const totalCoins = db.prepare('SELECT SUM(coins) AS s FROM users').get().s || 0;
    const recentRegistrations = db
      .prepare(
        `SELECT DATE(created_at, 'unixepoch') AS day, COUNT(*) AS count
         FROM users GROUP BY day ORDER BY day DESC LIMIT 7`
      )
      .all();
    return { totalUsers, totalServers, runningServers, totalCoins, recentRegistrations };
  });

  // ─── API Key management (admin) ────────────────────────────────────────────

  fastify.get('/api/v1/admin/api-keys', async () => {
    return db
      .prepare(
        `SELECT ak.id, ak.key_prefix, ak.permissions, ak.created_at, ak.last_used_at, u.username
         FROM api_keys ak JOIN users u ON u.id = ak.user_id ORDER BY ak.created_at DESC`
      )
      .all();
  });

  fastify.delete('/api/v1/admin/api-keys/:id', async (request) => {
    db.prepare('DELETE FROM api_keys WHERE id = ?').run(request.params.id);
    return { message: 'API key revoked.' };
  });
}

module.exports = adminRoutes;

'use strict';

const db = require('../../database/db');
const systemStats = require('../../services/systemStats');
const processManager = require('../../services/processManager');

async function statsRoutes(fastify) {
  fastify.addHook('preHandler', fastify.authenticate);

  fastify.get('/api/v1/stats/system', async () => {
    return systemStats.snapshot();
  });

  fastify.get('/api/v1/stats/servers/:id', async (request, reply) => {
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });
    return processManager.getStats(server.uuid);
  });

  fastify.get('/api/v1/announcements', async () => {
    return db
      .prepare('SELECT * FROM announcements ORDER BY created_at DESC LIMIT 10')
      .all();
  });

  fastify.get('/api/v1/ads/active', async (request) => {
    const type = request.query.type;
    let query = 'SELECT * FROM ads WHERE enabled = 1';
    const params = [];
    if (type) {
      query += ' AND type = ?';
      params.push(type);
    }
    query += ' ORDER BY created_at DESC';
    return db.prepare(query).all(...params);
  });

  fastify.post('/api/v1/ads/:id/click', async (request) => {
    db.prepare('UPDATE ads SET clicks = clicks + 1 WHERE id = ?').run(request.params.id);
    return { message: 'Click recorded.' };
  });
}

module.exports = statsRoutes;

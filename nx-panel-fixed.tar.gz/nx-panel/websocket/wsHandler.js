'use strict';

const db = require('../database/db');
const { verifyAccessToken } = require('../auth/tokens');
const processManager = require('../services/processManager');
const systemStats = require('../services/systemStats');

/**
 * Each WebSocket client can subscribe to channels:
 *  - "console:<serverUuid>"   → live console output for a server
 *  - "stats:<serverUuid>"     → live server stats (TPS, players, etc.)
 *  - "system"                 → host CPU / RAM / disk snapshots
 *  - "notifications"          → personal notifications push
 *
 * Authentication: clients send { type: "auth", token: "<jwt>" } as the
 * first message. The connection is dropped if not authenticated within 5s.
 */

const clients = new Map(); // ws -> { user, subscriptions: Set<string> }

function broadcast(channel, payload) {
  const msg = JSON.stringify({ channel, ...payload });
  for (const [ws, meta] of clients.entries()) {
    if (meta.subscriptions.has(channel) && ws.readyState === 1) {
      ws.send(msg);
    }
  }
}

function broadcastToUser(userId, payload) {
  const msg = JSON.stringify(payload);
  for (const [ws, meta] of clients.entries()) {
    if (meta.user && meta.user.id === userId && ws.readyState === 1) {
      ws.send(msg);
    }
  }
}

// Forward process-manager events to subscribers
processManager.on('console', ({ uuid, line }) => {
  broadcast(`console:${uuid}`, { type: 'console', line });
});

processManager.on('status', ({ uuid, status }) => {
  broadcast(`stats:${uuid}`, { type: 'status', status });
  // Update DB status
  db.prepare('UPDATE servers SET status = ? WHERE uuid = ?').run(status, uuid);
});

// Periodic system-stats broadcasts (every 5s)
let systemStatsInterval = null;

function startSystemStatsBroadcast() {
  if (systemStatsInterval) return;
  systemStatsInterval = setInterval(() => {
    let hasSubscribers = false;
    for (const meta of clients.values()) {
      if (meta.subscriptions.has('system')) { hasSubscribers = true; break; }
    }
    if (!hasSubscribers) return;
    const snap = systemStats.snapshot();
    broadcast('system', { type: 'system_stats', data: snap });
  }, 5000);
}

// Periodic server-stats broadcasts (every 3s) for subscribed servers
let serverStatsInterval = null;

function startServerStatsBroadcast() {
  if (serverStatsInterval) return;
  serverStatsInterval = setInterval(() => {
    const activeUuids = new Set();
    for (const meta of clients.values()) {
      for (const sub of meta.subscriptions) {
        if (sub.startsWith('stats:')) activeUuids.add(sub.slice(6));
      }
    }
    for (const uuid of activeUuids) {
      const stats = processManager.getStats(uuid);
      broadcast(`stats:${uuid}`, { type: 'server_stats', data: stats });
    }
  }, 3000);
}

startSystemStatsBroadcast();
startServerStatsBroadcast();

function ownsServer(user, uuid) {
  if (user.role === 'admin') return true;
  const server = db
    .prepare('SELECT id FROM servers WHERE uuid = ? AND owner_id = ?')
    .get(uuid, user.id);
  return !!server;
}

function wsHandler(connection, request) {
  const ws = connection.socket;
  const AUTH_TIMEOUT_MS = 5000;

  const clientMeta = { user: null, subscriptions: new Set() };
  clients.set(ws, clientMeta);

  const authTimeout = setTimeout(() => {
    if (!clientMeta.user) {
      ws.send(JSON.stringify({ type: 'error', message: 'Authentication timeout.' }));
      ws.close();
    }
  }, AUTH_TIMEOUT_MS);

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      ws.send(JSON.stringify({ type: 'error', message: 'Invalid JSON.' }));
      return;
    }

    if (!clientMeta.user) {
      if (msg.type !== 'auth') {
        ws.send(JSON.stringify({ type: 'error', message: 'Send auth message first.' }));
        return;
      }
      try {
        const payload = verifyAccessToken(msg.token);
        const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
        if (!user || user.suspended) throw new Error('Unauthorized');
        clearTimeout(authTimeout);
        clientMeta.user = user;
        ws.send(JSON.stringify({ type: 'auth_ok', username: user.username, role: user.role }));
      } catch {
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid token.' }));
        ws.close();
      }
      return;
    }

    const user = clientMeta.user;

    if (msg.type === 'subscribe') {
      const channel = msg.channel;
      if (typeof channel !== 'string') return;

      if (channel === 'system' || channel === 'notifications') {
        clientMeta.subscriptions.add(channel);
        ws.send(JSON.stringify({ type: 'subscribed', channel }));
        return;
      }

      const [prefix, uuid] = channel.split(':');
      if (!uuid || !['console', 'stats'].includes(prefix)) {
        ws.send(JSON.stringify({ type: 'error', message: `Unknown channel: ${channel}` }));
        return;
      }

      if (!ownsServer(user, uuid)) {
        ws.send(JSON.stringify({ type: 'error', message: 'Access denied to this server.' }));
        return;
      }

      clientMeta.subscriptions.add(channel);
      ws.send(JSON.stringify({ type: 'subscribed', channel }));

      if (prefix === 'console') {
        const logs = processManager.getRecentLogs(uuid);
        if (logs) ws.send(JSON.stringify({ channel, type: 'console', line: logs }));
      }
      return;
    }

    if (msg.type === 'unsubscribe') {
      clientMeta.subscriptions.delete(msg.channel);
      ws.send(JSON.stringify({ type: 'unsubscribed', channel: msg.channel }));
      return;
    }

    if (msg.type === 'command') {
      const { uuid, command } = msg;
      if (!uuid || !command || typeof command !== 'string' || command.length > 256) {
        ws.send(JSON.stringify({ type: 'error', message: 'Invalid command payload.' }));
        return;
      }
      if (!ownsServer(user, uuid)) {
        ws.send(JSON.stringify({ type: 'error', message: 'Access denied.' }));
        return;
      }
      try {
        processManager.sendCommand(uuid, command);
      } catch (err) {
        ws.send(JSON.stringify({ type: 'error', message: err.message }));
      }
      return;
    }

    ws.send(JSON.stringify({ type: 'error', message: `Unknown message type: ${msg.type}` }));
  });

  ws.on('close', () => {
    clients.delete(ws);
  });

  ws.on('error', () => {
    clients.delete(ws);
  });
}

module.exports = { wsHandler, broadcastToUser };

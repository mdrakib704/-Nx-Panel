'use strict';

const { verifyAccessToken } = require('./tokens');
const db = require('../database/db');
const fp = require('fastify-plugin');

async function authPlugin(fastify) {
  fastify.decorate('authenticate', authenticate);
  fastify.decorate('requireAdmin', requireAdmin);
}

async function authenticate(request, reply) {
  const header = request.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return reply.code(401).send({ error: 'Missing authorization token.' });
  }
  const token = header.slice(7);
  try {
    const payload = verifyAccessToken(token);
    const user = db
      .prepare(
        'SELECT id, username, email, role, coins, suspended, server_slots FROM users WHERE id = ?'
      )
      .get(payload.sub);
    if (!user) {
      return reply.code(401).send({ error: 'User no longer exists.' });
    }
    if (user.suspended) {
      return reply.code(403).send({ error: 'Account suspended.' });
    }
    request.user = user;
  } catch {
    return reply.code(401).send({ error: 'Invalid or expired token.' });
  }
}

async function requireAdmin(request, reply) {
  if (!request.user || request.user.role !== 'admin') {
    return reply.code(403).send({ error: 'Admin privileges required.' });
  }
}

module.exports = fp(authPlugin);

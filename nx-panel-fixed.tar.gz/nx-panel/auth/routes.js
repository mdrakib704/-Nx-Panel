'use strict';

const bcrypt = require('bcrypt');
const crypto = require('crypto');
const db = require('../database/db');
const config = require('../config.json');
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  createSession,
  findSessionByToken,
  deleteSessionByToken,
  deleteAllSessionsForUser
} = require('./tokens');
const {
  isValidUsername,
  isValidEmail,
  isValidPassword
} = require('../utils/validate');
const { audit } = require('../utils/audit');

async function authRoutes(fastify) {
  fastify.post(
    '/api/v1/auth/register',
    { config: { rateLimit: { max: 10, timeWindow: '10 minutes' } } },
    async (request, reply) => {
      const { username, email, password, referralCode } = request.body || {};

      if (!isValidUsername(username)) {
        return reply.code(400).send({
          error: 'Invalid username. Use 3-20 alphanumeric characters or underscores.'
        });
      }
      if (!isValidEmail(email)) {
        return reply.code(400).send({ error: 'Invalid email address.' });
      }
      if (!isValidPassword(password)) {
        return reply
          .code(400)
          .send({ error: 'Password must be at least 8 characters.' });
      }

      const existing = db
        .prepare('SELECT id FROM users WHERE username = ? OR email = ?')
        .get(username, email);
      if (existing) {
        return reply
          .code(409)
          .send({ error: 'Username or email already in use.' });
      }

      let referredBy = null;
      if (referralCode) {
        const refUser = db
          .prepare('SELECT id FROM users WHERE referral_code = ?')
          .get(referralCode);
        if (refUser) referredBy = refUser.id;
      }

      const hash = await bcrypt.hash(password, config.bcryptRounds);
      const newReferralCode = crypto.randomBytes(6).toString('hex');

      const result = db
        .prepare(
          `INSERT INTO users (username, email, password_hash, referral_code, referred_by)
           VALUES (?, ?, ?, ?, ?)`
        )
        .run(username, email, hash, newReferralCode, referredBy);

      if (referredBy) {
        const rewardCoins = parseInt(
          db
            .prepare("SELECT value FROM settings WHERE key = 'referral_reward_coins'")
            .get().value,
          10
        );
        db.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').run(
          rewardCoins,
          referredBy
        );
        db.prepare(
          'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)'
        ).run(referredBy, rewardCoins, 'referral', `Referred user ${username}`);
      }

      audit(result.lastInsertRowid, 'register', { username }, request.ip);

      return reply.code(201).send({ message: 'Account created successfully.' });
    }
  );

  fastify.post(
    '/api/v1/auth/login',
    { config: { rateLimit: { max: 10, timeWindow: '5 minutes' } } },
    async (request, reply) => {
      const { username, password, rememberMe } = request.body || {};
      if (!username || !password) {
        return reply.code(400).send({ error: 'Username and password are required.' });
      }

      const user = db
        .prepare('SELECT * FROM users WHERE username = ? OR email = ?')
        .get(username, username);

      if (!user) {
        return reply.code(401).send({ error: 'Invalid credentials.' });
      }

      const match = await bcrypt.compare(password, user.password_hash);
      if (!match) {
        audit(user.id, 'login_failed', {}, request.ip);
        return reply.code(401).send({ error: 'Invalid credentials.' });
      }

      if (user.suspended) {
        return reply.code(403).send({ error: 'This account has been suspended.' });
      }

      const accessToken = signAccessToken(user);
      const refreshToken = signRefreshToken(user, !!rememberMe);
      createSession(
        user,
        refreshToken,
        request.headers['user-agent'],
        request.ip,
        !!rememberMe
      );

      db.prepare('UPDATE users SET last_login_at = strftime(\'%s\',\'now\') WHERE id = ?').run(
        user.id
      );

      reply.setCookie('nx_refresh', refreshToken, {
        path: '/',
        httpOnly: true,
        sameSite: 'strict',
        maxAge: rememberMe ? 7 * 24 * 3600 : 24 * 3600
      });

      audit(user.id, 'login_success', {}, request.ip);

      return reply.send({
        accessToken,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
          coins: user.coins
        }
      });
    }
  );

  fastify.post('/api/v1/auth/refresh', async (request, reply) => {
    const refreshToken = request.cookies.nx_refresh;
    if (!refreshToken) {
      return reply.code(401).send({ error: 'No refresh token provided.' });
    }

    let payload;
    try {
      payload = verifyRefreshToken(refreshToken);
    } catch {
      return reply.code(401).send({ error: 'Invalid or expired refresh token.' });
    }

    const session = findSessionByToken(refreshToken);
    if (!session || session.expires_at < Math.floor(Date.now() / 1000)) {
      return reply.code(401).send({ error: 'Session expired.' });
    }

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
    if (!user || user.suspended) {
      return reply.code(401).send({ error: 'Account unavailable.' });
    }

    const accessToken = signAccessToken(user);
    return reply.send({ accessToken });
  });

  fastify.post('/api/v1/auth/logout', async (request, reply) => {
    const refreshToken = request.cookies.nx_refresh;
    if (refreshToken) {
      deleteSessionByToken(refreshToken);
    }
    reply.clearCookie('nx_refresh', { path: '/' });
    return reply.send({ message: 'Logged out.' });
  });

  fastify.post('/api/v1/auth/forgot-password', async (request, reply) => {
    const { email } = request.body || {};
    if (!isValidEmail(email)) {
      return reply.code(400).send({ error: 'Invalid email address.' });
    }
    const user = db.prepare('SELECT id FROM users WHERE email = ?').get(email);

    if (user) {
      const token = crypto.randomBytes(32).toString('hex');
      const expires = Math.floor(Date.now() / 1000) + 3600;
      db.prepare(
        'UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?'
      ).run(token, expires, user.id);
      // In production, email this token to the user. For self-hosted panels
      // without SMTP configured, the token is logged server-side instead.
      console.log(`[NX Panel] Password reset token for ${email}: ${token}`);
    }

    return reply.send({
      message: 'If that email exists, a reset link has been generated.'
    });
  });

  fastify.post('/api/v1/auth/reset-password', async (request, reply) => {
    const { token, newPassword } = request.body || {};
    if (!token || !isValidPassword(newPassword)) {
      return reply.code(400).send({ error: 'Invalid request.' });
    }

    const user = db
      .prepare(
        'SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > ?'
      )
      .get(token, Math.floor(Date.now() / 1000));

    if (!user) {
      return reply.code(400).send({ error: 'Invalid or expired reset token.' });
    }

    const hash = await bcrypt.hash(newPassword, config.bcryptRounds);
    db.prepare(
      'UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?'
    ).run(hash, user.id);

    deleteAllSessionsForUser(user.id);
    audit(user.id, 'password_reset', {}, request.ip);

    return reply.send({ message: 'Password updated successfully. Please log in.' });
  });
}

module.exports = authRoutes;
